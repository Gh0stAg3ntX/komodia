#if !defined(AFX_HTTPHELPER_H__87050638_77A9_4F61_AEE1_1006C40A407D__INCLUDED_)
#define AFX_HTTPHELPER_H__87050638_77A9_4F61_AEE1_1006C40A407D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "PCProxyDefs.h"

#include <map>
#include <string>

class CHTTPHelper  
{
public:
	//Add a HTTP header to filter out
	void FilterHTTPHeader(const std::string& rHeader);

	//Add a change
	void ChangeHTTPHeader(const std::string& rHeader,
						  const std::string& rNew);

	//Add field to insert every request (don't add \r\n)
	void InsertSpecialField(const std::string& rField,
							const std::string& rData);

	//Get the final structure
	OutgoingDataManipulations GetFinalStruct(bool bOverideProxy=false,
											 bool bOveridGlobal=false)const;

	//Ctor and Dtor
	CHTTPHelper();
	virtual ~CHTTPHelper();
private:
	//Our map of headers
	typedef std::map<std::string,std::string> HTTPMap;
private:
	//Build a char data from the map
	char** ConvertMap(const HTTPMap& rMap)const;

	//Fields to filter
	HTTPMap m_aFilter;

	//Fields to change
	HTTPMap m_aChange;

	//Fields to add
	HTTPMap m_aAdd;
};

#endif // !defined(AFX_HTTPHELPER_H__87050638_77A9_4F61_AEE1_1006C40A407D__INCLUDED_)
