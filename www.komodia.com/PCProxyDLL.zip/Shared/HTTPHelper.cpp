#include "stdafx.h"
#include "HTTPHelper.h"

CHTTPHelper::CHTTPHelper()
{
}

CHTTPHelper::~CHTTPHelper()
{
}

void CHTTPHelper::FilterHTTPHeader(const std::string& rHeader)
{
	m_aFilter[rHeader]="";
}

void CHTTPHelper::ChangeHTTPHeader(const std::string& rHeader, 
								   const std::string& rNew)
{
	m_aChange[rHeader]=rNew;
}

void CHTTPHelper::InsertSpecialField(const std::string& rField, 
									 const std::string& rData)
{
	m_aAdd[rField]=rData;
}

OutgoingDataManipulations CHTTPHelper::GetFinalStruct(bool bOverideProxy,
													  bool bOveridGlobal)const
{
	//Build the final struct
	OutgoingDataManipulations aStruct;

	//Set booleans
	aStruct.bOverideProxyFilter=bOverideProxy;
	aStruct.bOverideGlobalFilter=bOveridGlobal;

	//Headers to remove
	aStruct.ulHeadersToRemove=m_aFilter.size();
	aStruct.ppHeadersToRemove=ConvertMap(m_aFilter);

	//Headers to add
	aStruct.ulHeadersToAdd=m_aAdd.size();
	aStruct.ppHeadersToAdd=ConvertMap(m_aAdd);

	//Headers to change
	aStruct.ulHeadersToChange=m_aChange.size();
	aStruct.ppHeadersToChange=ConvertMap(m_aChange);

	//Set we have a filter
	aStruct.bUseFilter=true;

	//Done
	return aStruct;
}

char** CHTTPHelper::ConvertMap(const HTTPMap& rMap)const
{
	//Do we have data?
	if (rMap.empty())
		return NULL;

	//First allocate the master array
	char** ppData;
	ppData=new char*[rMap.size()*2];

	//The counter
	DWORD dwCounter=0;

	//Start to build the map
	for (HTTPMap::const_iterator aIterator=rMap.begin();
		 aIterator!=rMap.end();
		 ++aIterator)
	{
		//Allocate the first string
		ppData[dwCounter*2]=new char[aIterator->first.size()+1];
		memcpy(ppData[dwCounter*2],
			   aIterator->first.c_str(),
			   aIterator->first.size()+1);

		//Second string
		ppData[dwCounter*2+1]=new char[aIterator->second.size()+1];
		memcpy(ppData[dwCounter*2+1],
			   aIterator->second.c_str(),
			   aIterator->second.size()+1);

		//Next pos
		++dwCounter;
	}

	//Done
	return ppData;
}