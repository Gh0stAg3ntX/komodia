#if !defined(AFX_HTTPFILTER_H__F2329D65_4650_4AAD_AF9E_2E56ABD0E294__INCLUDED_)
#define AFX_HTTPFILTER_H__F2329D65_4650_4AAD_AF9E_2E56ABD0E294__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <set>
#include <string>
#include <map>
#include <vector>

class CHTTPFilter  
{
public:
	//The following three methods are used to remove data that was already added
	void RemoveFilterHTTPHeader(const std::string& rHeader);
	void RemoveChangeHTTPHeaderField(const std::string& rHeader);
	void RemoveInsertSpecialField(const std::string& rField);

	//Supplement a cookie, if cookie don't exist, it will create it
	void SupplementCookie(const std::string& rCookieData);

	//Clear the filter
	void Clear();

	//Set proxy prefix
	void SetProxyPrefix(const std::string& rProxyPrefix);

	//Are we an empty filter?
	bool IsEmpty()const;

	//Are we in HTTP?
	bool IsInHTTP()const;

	//Add a HTTP header to filter out
	void FilterHTTPHeader(const std::string& rHeader);
	
	//Add a change
	void ChangeHTTPHeader(const std::string& rHeader,
						  const std::string& rNew);

	//Add a change of HTTP headers (e.g. Connection to Proxy-Connection)
	void ChangeHTTPHeaderField(const std::string& rHeader,
							   const std::string& rNewHeader);

	//Add field to insert every request (don't add \r\n)
	void InsertSpecialField(const std::string& rField,
							const std::string& rData,
							bool bPreserveCase=false);

	//Process data to give to Redirector
	bool ProcessData(const char* pData,
					 DWORD dwDataSize,
					 char** pNewBuffer,
					 DWORD& rNewDataSize);

	//Ctor and Dtor
	CHTTPFilter();
	virtual ~CHTTPFilter();
private:
	//Our map of HTTP headers to filter or modify
	typedef std::map<std::string,std::string> HTTPMap;

	//Our vector of outgoing data
	typedef std::vector<char> DataVector;
private:
	//Convert a string to lower
	static std::string ConvertToLower(const std::string& rString);

	//Extract the header out of the string
	static std::string ExtractHeader(const std::string& rString,
									 std::string& rData);

	//The headers to filter
	HTTPMap m_aFilter;

	//Are we currently in header
	bool m_bIsInHeader;

	//Our rolling dequq
	DataVector m_aData;

	//Empty \r\n
	bool m_bEmptyRN;

	//Vector of special fields
	HTTPMap m_aSpecialFields;

	//HTTP map for current session
	HTTPMap m_aSpecialFieldsRemoved;

	//HTTP for header switches
	HTTPMap m_aHeaderSwitch;

	//Our proxy prefix
	std::string m_sProxyPrefix;

	//Is first header to process
	bool bFirstHeader;

	//Cookie supplement
	std::string m_sCookieDataSupp;

	//Did we had a cookie
	bool m_bCookie;

	//Is it bad divider
	bool m_bBadDivider;
};

#endif // !defined(AFX_HTTPFILTER_H__F2329D65_4650_4AAD_AF9E_2E56ABD0E294__INCLUDED_)
