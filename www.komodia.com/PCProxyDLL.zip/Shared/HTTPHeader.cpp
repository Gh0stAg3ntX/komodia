#include "stdafx.h"

#include <winsock2.h>
#include <windows.h>

#pragma warning(disable:4800)
#pragma warning(disable:4101)
#pragma warning(disable:4267)
#pragma warning(disable:4244)
#pragma warning(disable:4786)

#include "HTTPHeader.h"

#include "HTTPCommon.h"

#if !defined PCPROXYDLL_EXPORTS
#include "HTTPData.h"
#endif

// ----------------------------- CFastVector start ---------------------

CFastVector::CFastVector() : m_dwTotalSize(0)
{
}

CFastVector::CFastVector(const CFastVector& rVector) : m_dwTotalSize(rVector.m_dwTotalSize)
{
	//Get the data
	DataVector aTmp;
	rVector.GetData(aTmp);

	//Do we have data?
	if (!aTmp.empty())
		//Give it to the vector
		AddDataV(&aTmp[0],
				 aTmp.size());
}

CFastVector::~CFastVector()
{
	//Clear the data
	Clear();
}

bool CFastVector::Empty()const
{
	return m_dwTotalSize==0;
}

CFastVector& CFastVector::operator=(const CFastVector& rVector)
{
	//Clear ourselves
	Clear();

	//Get the data
	DataVector aTmp;
	rVector.GetData(aTmp);

	//Do we have data?
	if (!aTmp.empty())
		//Give it to the vector
		AddDataV(&aTmp[0],
				 aTmp.size());

	//Copy data size
	m_dwTotalSize=rVector.m_dwTotalSize;

	//Done
	return *this;
}

void CFastVector::AddDataV(const char* pData,
						   DWORD dwSize)
{
	//Sanity
	if (!pData ||
		!dwSize)
		return;

	//Copy the data
	VectorData aTmp;
	aTmp.dwSize=dwSize;
	aTmp.pData=new char[dwSize];
	memcpy(aTmp.pData,
		   pData,
		   dwSize);

	//Add it
	m_aVector.push_back(aTmp);

	//Add the size
	m_dwTotalSize+=dwSize;
}

void CFastVector::GetData(DataVector& rVector)const
{
	//Create the array
	DataVector aTmp;
	rVector.resize(m_dwTotalSize);

	//Current pos
	DWORD dwCurrentPos=0;

	//Start to copy
	for (size_t iCount=0;
		 iCount<m_aVector.size();
		 ++iCount)
	{
		//Copy
		memcpy(&rVector[dwCurrentPos],
			   m_aVector[iCount].pData,
			   m_aVector[iCount].dwSize);

		//Increase pos
		dwCurrentPos+=m_aVector[iCount].dwSize;
	}
}

void CFastVector::Clear()
{
	m_dwTotalSize=0;
	while (!m_aVector.empty())
	{
		//Delete the mem
		delete [] m_aVector.back().pData;
		m_aVector.pop_back();
	}
}

// ----------------------------- CFastVector end ---------------------

char* lstrinstr(const char *String, const char *Pattern, const char* pEnd)
{
      char *pptr, *sptr, *start;

      for (start = (char *)String; start<pEnd && *start != NULL; start++)
      {
            /* find start of pattern in string */
            for ( ; start<pEnd && (*start!=NULL) && (toupper(*start) != toupper(*Pattern)); start++)
                  ;
            if (start>=pEnd)
                  return NULL;

            pptr = (char *)Pattern;
            sptr = (char *)start;

            while (sptr<pEnd && toupper(*sptr) == toupper(*pptr))
            {
                  sptr++;
                  pptr++;

                  /* if end of pattern then pattern was found */

                  if (NULL == *pptr)
                        return (start);
            }
      }
      return NULL;
}

template<class A>
void ClearVectorInternal(A& rVector)
{
	A aTmp;
	aTmp.swap(rVector);
}

#define RESERVE_SIZE 4096

CHTTPHeader::CHTTPHeader(bool bParsePost,
						 bool bRecursedHeader) : m_bParsed(false),
												 m_bVersion11(false),
												 m_usResponseCode(0),
												 m_bParsePost(bParsePost),
												 m_bSSL(false),
												 m_bHTTP100(false),
												 m_pHTTP100Data(NULL),
												 m_dwHeaderEnd(0),
												 m_bBadHeader(false),
												 m_bNoMoreLSPFeeds(false),
												 m_dwSentPos(0),
												 m_bPostParsed(false),
												 m_bPostChunked(false),
												 m_bFirstPost(true),
												 m_bPostComplete(false),
												 m_bRecursed(bRecursedHeader),
												 m_dwLastMemPos(0),
												 m_bProxyStyle(false),
												 m_dwID(1),
												 m_bBadHeader2(false)
{
	//Reserve size
	m_aData.reserve(RESERVE_SIZE);

	//Save the capacity
	m_dwCapacity=m_aData.capacity();

}

CHTTPHeader::CHTTPHeader(const CHTTPHeader& rHeader)
{
	//Copy the vars
	m_bBadHeader2=rHeader.m_bBadHeader2;
	m_dwCapacity=rHeader.m_dwCapacity;
	m_aData=rHeader.m_aData;
	m_bParsed=rHeader.m_bParsed;
	m_bVersion11=rHeader.m_bVersion11;
	m_aBreakedHeader=rHeader.m_aBreakedHeader;
	m_aBreakedHeaderCase=rHeader.m_aBreakedHeaderCase;
	m_aCookies=rHeader.m_aCookies;
	m_aAuth=rHeader.m_aAuth;
	m_usResponseCode=rHeader.m_usResponseCode;
	m_sRequestType=rHeader.m_sRequestType;
	m_sURL=rHeader.m_sURL;
	m_sFullURL=rHeader.m_sFullURL;
	m_bParsePost=rHeader.m_bParsePost;
	m_bSSL=rHeader.m_bSSL;
	m_sHost=rHeader.m_sHost;
	m_aPostVector=rHeader.m_aPostVector;
	m_dwHeaderEnd=rHeader.m_dwHeaderEnd;
	m_bHTTP100=rHeader.m_bHTTP100;
	m_bBadHeader=rHeader.m_bBadHeader;
	m_bNoMoreLSPFeeds=rHeader.m_bNoMoreLSPFeeds;
	m_dwSentPos=rHeader.m_dwSentPos;
	m_bPostParsed=rHeader.m_bPostParsed;
	m_sPostLength=rHeader.m_sPostLength;
	m_bPostChunked=rHeader.m_bPostChunked;
	m_bFirstPost=rHeader.m_bFirstPost;
	m_bPostComplete=rHeader.m_bPostComplete;
	m_bRecursed=rHeader.m_bRecursed;
	m_sCreationTime=rHeader.m_sCreationTime;
	//m_aFastVector=rHeader.m_aFastVector;
	m_dwLastMemPos=rHeader.m_dwLastMemPos;
	m_bProxyStyle=rHeader.m_bProxyStyle;
	m_dwID=rHeader.m_dwID;

#if !defined NONIFSLSP_EXPORTS && !defined PCPROXYDLL_EXPORTS
	//Do we have the HTTP 100 data?
	if (rHeader.m_pHTTP100Data)
		m_pHTTP100Data=new CHTTPData(*rHeader.m_pHTTP100Data);
	else
		m_pHTTP100Data=NULL;
#endif
}

CHTTPHeader::~CHTTPHeader()
{
#if !defined NONIFSLSP_EXPORTS && !defined PCPROXYDLL_EXPORTS
	delete m_pHTTP100Data;
	m_pHTTP100Data=NULL;
#endif
}

CHTTPHeader& CHTTPHeader::operator=(const CHTTPHeader& rHeader)
{
	//Sanity check?
	if (this==&rHeader)
		return *this;

#if !defined NONIFSLSP_EXPORTS && !defined PCPROXYDLL_EXPORTS
	//Delete the old data
	delete m_pHTTP100Data;
#endif

	//Copy the vars
	m_bBadHeader2=rHeader.m_bBadHeader2;
	m_dwCapacity=rHeader.m_dwCapacity;
	m_bNoMoreLSPFeeds=rHeader.m_bNoMoreLSPFeeds;
	m_aData=rHeader.m_aData;
	m_bParsed=rHeader.m_bParsed;
	m_bVersion11=rHeader.m_bVersion11;
	m_aBreakedHeader=rHeader.m_aBreakedHeader;
	m_aBreakedHeaderCase=rHeader.m_aBreakedHeaderCase;
	m_aCookies=rHeader.m_aCookies;
	m_aAuth=rHeader.m_aAuth;
	m_usResponseCode=rHeader.m_usResponseCode;
	m_sRequestType=rHeader.m_sRequestType;
	m_sURL=rHeader.m_sURL;
	m_sFullURL=rHeader.m_sFullURL;
	m_bParsePost=rHeader.m_bParsePost;
	m_bSSL=rHeader.m_bSSL;
	m_sHost=rHeader.m_sHost;
	m_aPostVector=rHeader.m_aPostVector;
	m_dwHeaderEnd=rHeader.m_dwHeaderEnd;
	m_bHTTP100=rHeader.m_bHTTP100;
	m_bBadHeader=rHeader.m_bBadHeader;
	m_dwSentPos=rHeader.m_dwSentPos;
	m_bPostParsed=rHeader.m_bPostParsed;
	m_sPostLength=rHeader.m_sPostLength;
	m_bPostChunked=rHeader.m_bPostChunked;
	m_bFirstPost=rHeader.m_bFirstPost;
	m_bPostComplete=rHeader.m_bPostComplete;
	m_bRecursed=rHeader.m_bRecursed;
	m_sCreationTime=rHeader.m_sCreationTime;
	//m_aFastVector=rHeader.m_aFastVector;
	m_dwLastMemPos=rHeader.m_dwLastMemPos;
	m_bProxyStyle=rHeader.m_bProxyStyle;
	m_dwID=rHeader.m_dwID;

#if !defined NONIFSLSP_EXPORTS && !defined PCPROXYDLL_EXPORTS
	//Do we have the HTTP 100 data?
	if (rHeader.m_pHTTP100Data)
		m_pHTTP100Data=new CHTTPData(*rHeader.m_pHTTP100Data);
	else
		m_pHTTP100Data=NULL;
#endif

	//Done
	return *this;
}

bool CHTTPHeader::ForceFeed(const char* pData,
						    unsigned long ulSize)
{
	//Clear the data first
	Clear();

	//Now feed
	return Feed(pData,
				ulSize);
}

bool CHTTPHeader::Feed(LPWSABUF pBuf,
					   DWORD dwBufCount)
{
	//Sanity
	if (!pBuf ||
		!dwBufCount ||
		m_bNoMoreLSPFeeds)
		return false;

	//Start to add the buffers
	for (DWORD dwCount=0;
		 dwCount<dwBufCount;
		++dwCount)
		if (pBuf[dwCount].buf &&
			pBuf[dwCount].len)
			if (Feed(pBuf[dwCount].buf,
					 pBuf[dwCount].len))
				//Done
				return true;
			else if (!GetIncompleteHost().empty())
			{
				//We have it
				m_bNoMoreLSPFeeds=true;
				return true;
			}

	//Nothing
	return false;
}

bool CHTTPHeader::Feed(const char* pData,
					   unsigned long ulSize,
					   bool bCommit)
{
	//Do we need to take the data?
	if (!m_bParsed)
	{
		//Get the date (if needed)
		if (m_sCreationTime.empty())
			m_sCreationTime=GetDateFormated();

		//Check the size
		//Experimental - removed
		/*if (!m_aFastVector.Empty() ||
			(m_aData.empty() && ulSize>512))
			m_aFastVector.AddData(pData,
								  ulSize);
		else*/
			//Take it
			for (DWORD dwCount=0;
				 dwCount<ulSize;
				++dwCount)
				m_aData.push_back(pData[dwCount]);

		//Do we commit it?
		if (bCommit)
			AddToSentPos(ulSize);

		//Try to parse it
		bool bResult=BreakHeader(ulSize);

		//Did we manage?
		/*if (bResult)
			//Clear the vector
			m_aFastVector.Clear();*/

		//Done
		return bResult;
	}
	else
		return false;
}

void CHTTPHeader::Rollback(LPWSABUF pBuf,
						   DWORD dwBufCount)
{
	//Sanity
	if (!pBuf ||
		!dwBufCount ||
		m_bParsed ||
		m_bNoMoreLSPFeeds)
		return;

	//Start to add the buffers
	for (DWORD dwCount=0;
		 dwCount<dwBufCount;
		++dwCount)
		if (pBuf[dwCount].buf &&
			pBuf[dwCount].len)
			for (DWORD dwCountI=0;
				 dwCountI<pBuf[dwCount].len;
				 ++dwCountI)
				if (!m_aData.empty())
					m_aData.pop_back();
}

bool CHTTPHeader::FeedGetChange(const char* pData,
							    unsigned long ulSize,
							    unsigned long& rChange)
{
	//Set to no change
	rChange=0;

	//Do we need to take the data?
	if (!m_bParsed)
	{
		//Get the date (if needed)
		if (m_sCreationTime.empty())
			m_sCreationTime=GetDateFormated();

		//Are we complete?
		bool bComplete=false;

		//Take it
		for (DWORD dwCount=0;
			 dwCount<ulSize;
			++dwCount)
		{
			//Add the data
			m_aData.push_back(pData[dwCount]);

			//Check if it's OK
			if (m_aData.size()>10)
				if ((!(m_aData[m_aData.size()-1]!='\n' ||
					   m_aData[m_aData.size()-2]!='\r' ||
				   	   m_aData[m_aData.size()-3]!='\n' ||
					   m_aData[m_aData.size()-4]!='\r')) ||
					(!(m_aData[m_aData.size()-1]!='\n' ||
					   m_aData[m_aData.size()-2]!='\n')) ||
					(!(m_aData[m_aData.size()-1]!='\n' ||
					   m_aData[m_aData.size()-2]!='\r' ||
				   	   m_aData[m_aData.size()-3]!='\n')))
				{
					//We have a complete header
					bComplete=true;

					//Set the data	
					rChange=dwCount+1;

					//Done
					break;
				}
		}

		//Are we complete?
		if (bComplete)
			//Parse the header
			bComplete=BreakHeader(ulSize);

		//Done
		return bComplete;
	}
	else
		return false;
}

bool CHTTPHeader::BreakHeader(DWORD dwLastFedSize)
{
	//Do we need to take the header?
	/*if (!m_aFastVector.Empty())
		m_aFastVector.GetData(m_aData);*/

	//Add the 0
	m_aData.push_back(0);

	//Can we break it?
	char* pPos=NULL;
	char* pPos1=NULL;
	char* pPos2=NULL;

	//Try to find a bad header
	pPos2=strstr(&m_aData[0],
				 "\n\r\n");

	//Do we have it?
	if (pPos2 &&
		!strstr(&m_aData[0],
				"\r\n\r\n"))
		m_bBadHeader2=true;

	//Do we have a ready pos?
	if (m_dwLastMemPos)
		pPos=&m_aData[0]+m_dwLastMemPos;
	if (!m_bBadHeader2 &&
		!(pPos=strstr(&m_aData[0],
				      "\r\n\r\n")) &&
		!(pPos1=strstr(&m_aData[0],
					   "\n\n")))
	{
		//Remove the 0
		m_aData.pop_back();

		//Should we clear the vector?
		/*if (!m_aFastVector.Empty())
			m_aData.clear();*/

		//Nothing for us
		return false;
	}
	else
	{
		//Which header is it?
		if (pPos1)
		{
			//This is a bad header
			m_bBadHeader=true;

			//Set the pos
			pPos=pPos1;
		}
		else if (!pPos)
			//Set the pos
			pPos=pPos2;

#if !defined NONIFSLSP_EXPORTS && !defined PCPROXYDLL_EXPORTS
		if (m_bParsePost ||
			(m_bFirstPost && !m_bRecursed))
		{
			//Need to save the pos
			if (!m_dwLastMemPos)
				m_dwLastMemPos=pPos-&m_aData[0];

			//No longer first
			m_bFirstPost=false;

			//Is it a post?
			if (!_strnicmp(&m_aData[0],
						   "POST",
						   4) ||
				!_strnicmp(&m_aData[0],
						   "PUT",
						   3) ||
				!_strnicmp(&m_aData[0],
						   "OPTIONS",
						   7) ||
				!_strnicmp(&m_aData[0],
						   "PROPFIND",
						   8) ||
				!_strnicmp(&m_aData[0],
						   "LOCK",
						   4) ||
				!_strnicmp(&m_aData[0],
						   "SEARCH",
						   6) ||
				!_strnicmp(&m_aData[0],
						   "REPORT",
						   6))						   
			{
				//Do we have the data?
				if (!m_bPostParsed)
				{
					//We need to get the content length
					CHTTPHeader aHeader(false,
										true);
					if (aHeader.Feed(&m_aData[0],
									 m_aData.size()))
					{
						//Set as parsed
						m_bPostParsed=true;

						//Get the data
						m_sPostLength=aHeader.GetHeaderString("content-length");
						m_bPostChunked=(aHeader.GetHeaderString("transfer-encoding")==std::string("chunked"));

						//Check if we excpect HTTP100?
						m_bHTTP100=(aHeader.GetHeaderString("expect")==std::string("100-continue"));
					}
				}

				//Do we have it?
				if (!m_sPostLength.empty())
				{
					//Get the length
					DWORD dwLen=S2DWORD(m_sPostLength);			

					//What's the length we want
					DWORD dwCheckLength=4;
					
					//Do we have this length?
					if ((m_aData.size()-1)!=(pPos+dwCheckLength-&m_aData[0]+dwLen))
					{
						//Are we in parse post mode?
						if (m_bParsePost)
						{
							//Remove the 0
							m_aData.pop_back();
						
							//Nothing for us
							return false;
						}
					}
					else
						//We have a parse
						m_bPostComplete=true;
				}
				else if (m_bPostChunked)
				{
					//Remove the 0
					m_aData.pop_back();

					//Are we fed
					bool bFed=false;

					//Need to create a HTTPData parser
					if (!m_pHTTP100Data)
					{
						//Create it
						m_pHTTP100Data=new CHTTPData(false,
													 true);

						//Feed it what we have so far
						bFed=m_pHTTP100Data->Feed(&m_aData[0],
												  m_aData.size());
					}
					else
						//Feed the difference
						bFed=m_pHTTP100Data->Feed(&m_aData[m_aData.size()-dwLastFedSize],
												  dwLastFedSize);

					//Do we have a feed?
					if (!bFed)
						if (m_bParsePost)
							return false;
						else
							;
					else
					{
						//Add back the 0
						m_aData.push_back(0);

						//Take the data into the post vector
						char* pTmp=NULL;
						DWORD dwSize;
						m_pHTTP100Data->BuildData(&pTmp,
												  dwSize,
												  true);

						//Delete the 100 data
						delete m_pHTTP100Data;
						m_pHTTP100Data=NULL;

						//Do we have the data?
						if (dwSize &&
							pTmp)
						{
							//Save the buffer
							char* pBackupTmp=pTmp;

							//Add it to the vector
							while (dwSize)
							{
								//Add it
								m_aPostVector.push_back(*pTmp);

								//Advance
								++pTmp;
								--dwSize;
							}

							//Delete the buffer
							delete [] pBackupTmp;
						}

						//We have a parse
						m_bPostComplete=true;
					}
				}
				else if (m_bParsePost)
				{
					//Remove the 0
					m_aData.pop_back();

					//No post yet
					return false;
				}
			}
		}
#endif
	}

	//Check if it's a HTTP-100 continue
	if (!m_bHTTP100 &&
		m_aData.size()>17 &&
		!_strnicmp(&m_aData[0],
				   "HTTP/1.1 100",
				   12))
	{
		//This is not a parsed request
		//We need to adjust it
		//Pop the last 3 items
		for (int iCount=0;
			 iCount<3;
			 ++iCount)
			m_aData.pop_back();

		//Set we have HTTP 100
		m_bHTTP100=true;

		//Exit
		return false;
	}

	//Set as parsed
	m_bParsed=true;

	//Extract the response code
	ExtractHTTPResponse();

	//Extract the request type
	ExtractRequestType();

	//First if it's version 1.1
	if (strstr(&m_aData[0],
			   "HTTP/1.1"))
		m_bVersion11=true;

	//Our index string
	std::string sIndex;
	
	//Our data string
	std::string sData;

	//Our data for cookie
	std::string sCookie;

	//Did we have a shift
	bool bShift=false;

	//Is it first line
	bool bFirstLine=true;

	//Iterate the header
	DataVector::const_iterator aIterator;
	aIterator=m_aData.begin();
	while (aIterator!=m_aData.end())
	{
		//Check it's not the end
		if ((!m_bBadHeader &&
			 *aIterator=='\r' &&
			 (aIterator+1)!=m_aData.end() &&
			 *(aIterator+1)=='\n') ||
			(m_bBadHeader &&
			 *aIterator=='\n') ||
			(m_bBadHeader2 &&
			 *aIterator=='\n' &&
			 aIterator!=m_aData.begin() &&
			 *(aIterator-1)!='\r'))
		{
			//Not first line
			bFirstLine=false;

			//Did we had a shift?
			if (bShift)
			{
				//Add the string
				m_aBreakedHeader[sIndex]=sData;

				//Add the case sensitive string
				m_aBreakedHeaderCase[sIndex]=sCookie;

				//Is it cookie?
				if (sIndex=="set-cookie" ||
					sIndex=="cookie")
					//Add the cookie
					m_aCookies.push_back(sCookie);
				else if (sIndex=="www-authenticate")
					m_aAuth.push_back(sCookie);
			}
			else if (sIndex.empty() &&
					 sData.empty())
				//Done
				break;
			
			//Only if not bad header
			if (!m_bBadHeader)
				//Skip one
				++aIterator;

			//Reset data
			sIndex="";
			sData="";
			sCookie="";
			bShift=false;
		}
		else if (!bShift)
			//Is it a :
			if (*aIterator==':' &&
				!bFirstLine)
			{
				//Shift time
				bShift=true;

				//Next
				++aIterator;

				//Iterate for spaces
				while (aIterator!=m_aData.end() &&
					   *aIterator==' ')
					//Next
					++aIterator;

				//Just go with the loop
				continue;
			}
			else
				//Add to the index
				sIndex+=C2L(*aIterator);
		else
		{
			//Add
			sData+=C2L(*aIterator);
			sCookie+=*aIterator;
		}

		//Next
		++aIterator;
	}

	//Extract the URL
	ExtractURL();

	if (aIterator!=m_aData.end() &&
		(aIterator+1)!=m_aData.end() &&
		(aIterator+2)!=m_aData.end())
	{
		//Advance it
		++aIterator;
		++aIterator;
	}

	//Calculate header end (only if needed)
	if (!m_aPostVector.empty())
		m_dwHeaderEnd=aIterator-m_aData.begin();

	//Should we copy?
	if ((!m_bHTTP100 || m_aPostVector.empty()) &&
		m_aData.size()>3 &&
		(!_strnicmp(&m_aData[0],
				    "POST",
				    4) ||
		 !_strnicmp(&m_aData[0],
				    "PUT",
				    3)) ||
		 !_strnicmp(&m_aData[0],
				    "OPTIONS",
				    7) ||
		 !_strnicmp(&m_aData[0],
				    "PROPFIND",
				    8) ||
		 !_strnicmp(&m_aData[0],
				    "LOCK",
				    4) ||
		 !_strnicmp(&m_aData[0],
				    "SEARCH",
				    6) ||
		 !_strnicmp(&m_aData[0],
				    "REPORT",
				    6))
	{
		//Calculate header end
		m_dwHeaderEnd=aIterator-m_aData.begin();

		//Build the post vector
		while (aIterator!=m_aData.end())
		{
			//Add it
			m_aPostVector.push_back(*aIterator);

			//Next
			++aIterator;
		}

		//Remove the last char
		if (!m_aPostVector.empty())
			m_aPostVector.pop_back();
	}

	//We have something
	return true;
}

char CHTTPHeader::C2L(char cChar)
{
	if (cChar>='A' &&
		cChar<='Z')
		return cChar+32;
	else
		return cChar;
}

std::string CHTTPHeader::GetHeaderString(const std::string& rStringToFind)const
{
	//Try to find the string
	BreakedMap::const_iterator aIterator;
	aIterator=m_aBreakedHeader.find(rStringToFind);

	//Did we get it?
	if (aIterator!=m_aBreakedHeader.end())
		return aIterator->second;
	else
		return "";
}

std::string CHTTPHeader::GetHeaderStringCase(const std::string& rStringToFind)const
{
	//Try to find the string
	BreakedMap::const_iterator aIterator;
	aIterator=m_aBreakedHeaderCase.find(rStringToFind);

	//Did we get it?
	if (aIterator!=m_aBreakedHeaderCase.end())
		return aIterator->second;
	else
		return "";
}

std::string CHTTPHeader::GetFirstCookie()const
{
	//Do we have cookies?
	if (m_aCookies.empty())
		return "";
	else
		return m_aCookies[0];
}

const CHTTPHeader::CookieVector& CHTTPHeader::GetCookies()const
{
	return m_aCookies;
}

void CHTTPHeader::Clear(bool bDontClearSecure)
{
	//Clear all
	m_bBadHeader2=false;
	m_dwSentPos=0;
	m_bNoMoreLSPFeeds=false;
	m_bParsed=false;
	m_bVersion11=false;
	m_usResponseCode=0;
	m_sRequestType="";
	m_sURL="";
	m_sFullURL="";
	m_bHTTP100=false;
	m_dwHeaderEnd=0;
	m_bBadHeader=false;
	m_bPostParsed=false;
	m_sPostLength="";
	m_bPostChunked=false;
	m_bFirstPost=true;
	m_bPostComplete=false;
	m_sCreationTime="";
	m_dwLastMemPos=0;
	m_bProxyStyle=false;
	m_sHost="";
	++m_dwID;

	//Can we clear SSL
	if (!bDontClearSecure)
		m_bSSL=false;

	//Clear the buffers
	//This was the old way, the new way will clear the memory
	/*m_aBreakedHeader.clear();
	m_aBreakedHeaderCase.clear();
	m_aCookies.clear();
	m_aAuth.clear();
	m_aData.clear();
	m_aPostVector.clear();*/

	//New way
	ClearVectorInternal(m_aBreakedHeader);
	ClearVectorInternal(m_aBreakedHeaderCase);
	ClearVectorInternal(m_aCookies);
	ClearVectorInternal(m_aAuth);
	ClearVectorInternal(m_aPostVector);
	//m_aFastVector.Clear();

	//How should we clear the vector?
	if (m_aData.capacity()>m_dwCapacity)
	{
		//Clear it
		ClearVectorInternal(m_aData);
	
		//Reserve size
		m_aData.reserve(RESERVE_SIZE);
	}
	else
		//Normal clear
		m_aData.clear();
	
#if !defined NONIFSLSP_EXPORTS && !defined PCPROXYDLL_EXPORTS
	//Delete the 100 parse
	delete m_pHTTP100Data;
	m_pHTTP100Data=NULL;
#endif
}

std::string CHTTPHeader::GetIncompleteFullAddress()const
{
	//Try to get the hose
	std::string sHost=GetIncompleteHost();

	//Do we have it?
	if (sHost.empty())
		return "";

	//Try to get the URL
	//Do we have header?
	if (m_aData.empty())
		return "";

	//Make sure it's a reply
	if (!_strnicmp(&m_aData[0],
				   "HTTP",
				   4))
		return "";

	//Our URL
	std::string sURL;

	//Try to parse the response
	DataVector::const_iterator aIterator;
	aIterator=m_aData.begin();

	//Find first space
	while (aIterator!=m_aData.end() &&
		   *aIterator!=' ')
		//Next
		++aIterator;

	//Skip spaces
	while (aIterator!=m_aData.end() &&
		   *aIterator==' ')
		//Next
		++aIterator;

	//Now get the data
	while (aIterator!=m_aData.end() &&
		   *aIterator!=' ')
	{
		//Get the URL
		sURL+=*aIterator;

		//Next
		++aIterator;
	}

	//Check the URL type
	if (!_strnicmp(m_sURL.c_str(),
				   "http",
				   4))
		//Done
		return sURL;
	else
	{
		//Need to build the full URL
		std::string sTmp;
		sTmp="http://";

		//Add the hos
		sTmp+=sHost;

		//Add the URL
		sTmp+=sURL;

		//Done
		return sURL;
	}
}

std::string CHTTPHeader::GetIncompleteHost()const
{
	//Add the 0
	m_aData.push_back(0);

	//Do we clean the 0?
	bool bClean=true;

	//The host
	std::string sHost;

	//The terminator
	std::string sTerminator(GetTerminator());

	//Do we have the host?
	char* pPos;
	if ((pPos=stristr(&m_aData[0],
					  "host:")))
		if (strstr(pPos,
				   sTerminator.c_str()))
		{
			//We have the host
			//Parse it
			pPos+=5;
			while (*pPos==' ')
				++pPos;

			//Get the host
			while (*pPos!=sTerminator[0] &&
				   *pPos!=' ')
			{
				//Add it
				sHost+=*pPos;

				//Next
				++pPos;
			}
		}

	//Clean
	m_aData.pop_back();

	//Done
	return sHost;
}

bool CHTTPHeader::DoesContainFullCookie()const
{
	//Add the 0
	m_aData.push_back(0);

	//Do we have it?
	char* pCookie;
	pCookie=stristr(&m_aData[0],
					"cookie:");

	//Do we have it?
	if (pCookie)
		pCookie=strstr(pCookie,
					   GetTerminator().c_str());

	//remove the 0
	m_aData.pop_back();

	//Done
	return pCookie!=NULL;
}

bool CHTTPHeader::DoesContainCookie()const
{
	//Add the 0
	m_aData.push_back(0);

	//Do we have it?
	bool bCookie;
	bCookie=stristr(&m_aData[0],
					"cookie:");

	//remove the 0
	m_aData.pop_back();

	//Done
	return bCookie;
}

bool CHTTPHeader::IsParsed()const
{
	return m_bParsed;
}

void CHTTPHeader::DeleteHeader(const std::string& rHeader)
{
	//Are we parsed?
	if (!m_bParsed ||
		m_aData.empty())
		return;

	//Do we have this header?
	char* pHeader;
	pHeader=lstrinstr(&m_aData[0],
					  (std::string("\n")+rHeader+':').c_str(),
					  &m_aData[0]+m_aData.size());

	//Did we get it?
	if (pHeader)
	{
		//Advance it
		++pHeader;

		//Start to copy some data
		DataVector aTmp;
		DWORD dwCount;
		for (dwCount=0;
			 dwCount<(DWORD)(pHeader-&m_aData[0]);
			 ++dwCount)
			//Add the data
			aTmp.push_back(m_aData[dwCount]);

		//Advance the ptr to the \r\n
		pHeader=lstrinstr(pHeader,
						  GetTerminator().c_str(),
						  &m_aData[0]+m_aData.size());

		//Do we have it?
		if (!pHeader)
			return;

		//Advance it to skip the \r\n
		pHeader+=GetTerminator().size();

		//Now add rest of the header
		for (dwCount=(pHeader-&m_aData[0]);
			 dwCount<m_aData.size();
			 ++dwCount)
			aTmp.push_back(m_aData[dwCount]);

		//Replace it
		aTmp.swap(m_aData);
	}
}

void CHTTPHeader::SetHeader(const std::string& rHeader,
							const std::string& rData)
{
	//Are we parsed?
	if (!m_bParsed ||
		m_aData.empty())
		return;

	//Save the size
	int iSize=m_aData.size();

	//Do we have this header?
	char* pHeader;
	pHeader=lstrinstr(&m_aData[0],
					  (std::string("\n")+rHeader+':').c_str(),
					  &m_aData[0]+m_aData.size());

	//Did we get it?
	if (pHeader)
	{
		//Move one forward
		++pHeader;

		//Start to copy some data
		DataVector aTmp;
		DWORD dwCount;
		for (dwCount=0;
			 dwCount<(DWORD)(pHeader-&m_aData[0]);
			 ++dwCount)
			//Add the data
			aTmp.push_back(m_aData[dwCount]);

		//Build our header
		std::string sHeader(rHeader);
		sHeader+=": ";
		sHeader+=rData;
		
		//Now add our header
		for (dwCount=0;
			 dwCount<sHeader.size();
			 ++dwCount)
			//Add the data
			aTmp.push_back(sHeader[dwCount]);

		//Advance the ptr to the \r\n
		pHeader=lstrinstr(pHeader,
						  GetTerminator().c_str(),
						  &m_aData[0]+m_aData.size());

		//Now add rest of the header
		for (dwCount=(pHeader-&m_aData[0]);
			 dwCount<m_aData.size();
			 ++dwCount)
			aTmp.push_back(m_aData[dwCount]);

		//Replace it
		aTmp.swap(m_aData);
	}
	else
	{
		//Build the search
		std::string sSearch(GetTerminator());
		sSearch+=sSearch;

		//Search for the \r\n\r\n
		pHeader=lstrinstr(&m_aData[0],
						  sSearch.c_str(),
						  &m_aData[0]+m_aData.size());

		//Do we have it?
		if (pHeader)
		{
			//Need to copy at least one \r\n
			pHeader+=GetTerminator().size();

			//Start to copy some data
			DataVector aTmp;
			DWORD dwCount;
			for (dwCount=0;
				 dwCount<(DWORD)(pHeader-&m_aData[0]);
				 ++dwCount)
				//Add the data
				aTmp.push_back(m_aData[dwCount]);

			//Build our header
			std::string sHeader(rHeader);
			sHeader+=": ";
			sHeader+=rData;
			sHeader+=sSearch;

			//Now add our header
			for (dwCount=0;
				 dwCount<sHeader.size();
				 ++dwCount)
				//Add the data
				aTmp.push_back(sHeader[dwCount]);

			//Advance the ptr to exclude the \r\n
			pHeader+=GetTerminator().size();

			//Now add rest of the header
			for (dwCount=(pHeader-&m_aData[0]);
				 dwCount<m_aData.size();
				 ++dwCount)
				aTmp.push_back(m_aData[dwCount]);

			//Replace it
			aTmp.swap(m_aData);
		}
	}

	//Do we need to adjust the size?
	if (m_aData.size()!=iSize &&
		m_dwHeaderEnd)
	{
		//Adjust the size
		int iHeaderEnd=m_dwHeaderEnd;
		iHeaderEnd+=m_aData.size()-iSize;
		m_dwHeaderEnd=iHeaderEnd;
	}
}

std::string CHTTPHeader::GetHeaderDataString(DWORD dwStart)const
{
	//Our data
	DataVector aTmp;

	//Delegate
	aTmp=GetHeaderData(dwStart);

	//The string
	std::string sTmp;

	//Build it
	for (size_t iCount=0;
		 iCount<aTmp.size();
		 ++iCount)
		sTmp+=aTmp[iCount];

	//Done
	return sTmp;
}

std::string CHTTPHeader::GetHeaderDataStringNoPost(DWORD dwStart)const
{
	//Our data
	DataVector aTmp;

	//Delegate
	aTmp=GetHeaderData(dwStart,
					   true);

	//The string
	std::string sTmp;

	//Build it
	for (size_t iCount=0;
		 iCount<aTmp.size();
		 ++iCount)
		sTmp+=aTmp[iCount];

	//Done
	return sTmp;
}

void CHTTPHeader::MoveData()const
{
	/*if (!m_aFastVector.Empty())
	{
		m_aFastVector.GetData(m_aData);
		m_aFastVector.Clear();
	}*/
}

CHTTPHeader::DataVector CHTTPHeader::GetHeaderData(DWORD dwStart,
												   bool bNoPost)const
{
	//Move the data
	MoveData();

	//Our data
	DataVector aTmp;

	//Do we have post data?
	if (m_aPostVector.empty() ||
		dwStart ||
		bNoPost)
	{
		//Copy the data
		for (DWORD dwCount=dwStart;
			 dwCount<m_aData.size();
			 ++dwCount)
			//Add the data
			aTmp.push_back(m_aData[dwCount]);

		//Are we parsed?
		if (m_bParsed &&
			!aTmp.empty() &&
			aTmp[aTmp.size()-1]==0)
			aTmp.pop_back();
	}
	else
	{
		//Copy the data
		DWORD dwCount;
		for (dwCount=0;
			 dwCount<m_dwHeaderEnd;
			 ++dwCount)
			//Add the data
			aTmp.push_back(m_aData[dwCount]);

		//Now add the post data
		for (dwCount=0;
			 dwCount<m_aPostVector.size();
			 ++dwCount)
			//Add the data
			aTmp.push_back(m_aPostVector[dwCount]);
	}

	//Done
	return aTmp;
}

bool CHTTPHeader::DoesContainData()const
{
	return !m_aData.empty();
}

CHTTPHeader::DataVector CHTTPHeader::GetStrippedRequest()const
{
	//First check if we are complete and we have proxy info
	if (!m_bParsed ||
		m_aData.empty() ||
		!DoesContainProxyInfo())
		//Give it what we have
		return m_aData;

	//Start to build our data
	DataVector aTmp;

	//First scan the buffer
	DataVector::const_iterator aIterator;
	aIterator=m_aData.begin();

	//Get to the space
	while (aIterator!=m_aData.end() &&
		   *aIterator!=' ')
	{
		//Add it
		aTmp.push_back(*aIterator);
		++aIterator;
	}

	//Clear all spaces now
	while (aIterator!=m_aData.end() &&
		   *aIterator==' ')
	{
		//Add it
		aTmp.push_back(*aIterator);
		++aIterator;
	}

	//Now skip to the first 3rd /
	int iCount=3;
	while (aIterator!=m_aData.end() &&
		   iCount)
	{
		//Is it /
		if (*aIterator=='/')
			--iCount;

		//Next
		++aIterator;
	}

	//Are we legit?
	if (iCount)
		//Wierd, return what we have
		return m_aData;

	//Add the missing /
	aTmp.push_back('/');

	//And add all
	while (aIterator!=m_aData.end())
	{
		//Add it
		aTmp.push_back(*aIterator);
		++aIterator;
	}

	//Look for proxy connection
	char* pTmp;
	if ((pTmp=lstrinstr(&aTmp[0],
					    "proxy-connection:",
						&aTmp[0]+aTmp.size())))
	{
		//The location
		DWORD dwLoc;
		dwLoc=pTmp-&aTmp[0];

		//Need to trim the first 6 letters of it
		DWORD dwCount;
		for (dwCount=dwLoc;
			 dwCount<(aTmp.size()-6);
			 ++dwCount)
			//Copy the data
			aTmp[dwCount]=aTmp[dwCount+6];

		//Remove last 6 bytes
		for (dwCount=0;
			 dwCount<6;
			 ++dwCount)
			aTmp.pop_back();
	}

	//Remove last 0
	aTmp.pop_back();

	//Done
	return aTmp;
}

bool CHTTPHeader::DoesContainProxyInfo()const
{
	//First scan the buffer
	DataVector::const_iterator aIterator;
	aIterator=m_aData.begin();

	//Get to the space
	while (aIterator!=m_aData.end() &&
		   *aIterator!=' ')
		++aIterator;

	//Clear all spaces now
	while (aIterator!=m_aData.end() &&
		   *aIterator==' ')
		++aIterator;

	//Is it proxy?
	bool bProxy=true;

	//Now need to check if it's HTTP
	std::string sTmp="HTTP://";
	std::string::const_iterator aIterator2=sTmp.begin();
	while (aIterator!=m_aData.end() &&
		   aIterator2!=sTmp.end())
		if (C2L(*aIterator)!=C2L(*aIterator2))
		{
			//Not proxy
			bProxy=false;
			break;
		}
		else
		{
			//Next
			++aIterator;
			++aIterator2;
		}

	//What we got?
	return bProxy;
}

bool CHTTPHeader::IsHTTP11()const
{
	return m_bVersion11;
}

void CHTTPHeader::ExtractHTTPResponse()
{
	//Do we have header?
	if (m_aData.empty())
		return;

	//Make sure it's a reply
	if (_strnicmp(&m_aData[0],
				  "HTTP",
				  4))
		return;

	//Try to parse the response
	DataVector::const_iterator aIterator;
	aIterator=m_aData.begin();

	//Check if we have a HTTP 100
	if (m_bHTTP100)
	{
		//Need to parse second line
		while (aIterator!=m_aData.end() &&
			   *aIterator!='\r' && 
			   *aIterator!='\n')
			++aIterator;

		//Can we go next?
		if (aIterator!=m_aData.end() &&
			(aIterator+1)!=m_aData.end())
		{
			//Go next twice
			++aIterator;
			++aIterator;
		}
		else
		{
			//Set it to 100
			m_usResponseCode=100;

			//Exit
			return;
		}
	}

	//Find first space
	while (aIterator!=m_aData.end() &&
		   *aIterator!=' ')
		//Next
		++aIterator;

	//Skip spaces
	while (aIterator!=m_aData.end() &&
		   *aIterator==' ')
		//Next
		++aIterator;

	//Now get the number
	unsigned short usNumber=0;
	while (aIterator!=m_aData.end() &&
		   *aIterator>='0' &&
		   *aIterator<='9')
	{
		//Get the number
		usNumber=usNumber*10+*aIterator-'0';

		//Next
		++aIterator;
	}

	//We got the number
	m_usResponseCode=usNumber;
}

unsigned short CHTTPHeader::GetResponseCode()const
{
	return m_usResponseCode;
}

void CHTTPHeader::ExtractRequestType()
{
	//Do we have header?
	if (m_aData.empty())
		return;

	//Make sure it's a request
	if (!_strnicmp(&m_aData[0],
				   "HTTP",
				   4))
		return;

	//Try to parse the request
	DataVector::const_iterator aIterator;
	aIterator=m_aData.begin();

	//Find first space
	while (aIterator!=m_aData.end() &&
		   *aIterator!=' ')
	{
		//Add to the request
		m_sRequestType+=*aIterator;

		//Next
		++aIterator;
	}
}

void CHTTPHeader::ExtractURL()
{
	//Do we have header?
	if (m_aData.empty())
		return;

	//Make sure it's a reply
	if (!_strnicmp(&m_aData[0],
				   "HTTP",
				   4))
		return;

	//Try to parse the response
	DataVector::const_iterator aIterator;
	aIterator=m_aData.begin();

	//Find first space
	while (aIterator!=m_aData.end() &&
		   *aIterator!=' ')
		//Next
		++aIterator;

	//Skip spaces
	while (aIterator!=m_aData.end() &&
		   *aIterator==' ')
		//Next
		++aIterator;

	//Now get the data
	while (aIterator!=m_aData.end() &&
		   *aIterator!=' ')
	{
		//Get the URL
		m_sURL+=*aIterator;

		//Next
		++aIterator;
	}

	//Check the URL type
	if (!_strnicmp(m_sURL.c_str(),
				   "http",
				   4))
	{
		//Set this is a proxy style
		m_bProxyStyle=true;

		//Give it to the full URL
		m_sFullURL=m_sURL;

		//And trim it
		m_sURL="";

		//Get it again
		//First scan the buffer
		aIterator=m_aData.begin();

		//Get to the space
		while (aIterator!=m_aData.end() &&
			   *aIterator!=' ')
			//Next			
			++aIterator;

		//Clear all spaces now
		while (aIterator!=m_aData.end() &&
			   *aIterator==' ')
			//Next
			++aIterator;

		//Now skip to the first 3rd /
		int iCount=3;
		while (aIterator!=m_aData.end() &&
			   iCount)
		{
			//Is it /
			if (*aIterator=='/')
				--iCount;

			//Next
			++aIterator;
		}

		//Are we legit?
		if (iCount)
			//Wierd, return what we have
			return;

		//Add the missing /
		m_sURL='/';

		//And add all
		while (aIterator!=m_aData.end() &&
			   *aIterator!=' ')
		{
			//Add it
			m_sURL+=*aIterator;
			++aIterator;
		}
	}
	else
	{
		//Need to build the full URL
		std::string sTmp;
		if (m_bSSL)
			sTmp="https://";
		else
			sTmp="http://";

		//Get the host
		if (m_sHost.empty())
			m_sHost=GetHeaderString("host");

		//Do we have a host?
		if (m_sHost.empty())
			return;

		//Add the hos
		sTmp+=m_sHost;

		//Add the URL
		sTmp+=m_sURL;

		//Save it
		m_sFullURL=sTmp;
	}
}

bool CHTTPHeader::IsRequest()const
{
	return !m_sRequestType.empty();
}

const std::string& CHTTPHeader::GetURL()const
{
	return m_sURL;
}

const std::string& CHTTPHeader::GetFullAddress()const
{
	return m_sFullURL;
}

void CHTTPHeader::SetSecure()
{
	m_bSSL=true;
}

bool CHTTPHeader::ReplaceAll(const char* pData,
						 	 unsigned long ulSize,
							 bool bReparse)
{
	//Do we reparse?
	if (bReparse)
	{
		//Clear the data
		Clear();

		//Try to parse it
		return ForceFeed(pData,
						 ulSize);
	}
	else
	{
		//Just replace the buffers
		m_aData.clear();
		for (DWORD dwCount=0;
			 dwCount<ulSize;
			 ++dwCount)
			m_aData.push_back(pData[dwCount]);

		//Add the zero
		m_aData.push_back(0);

		//Done
		return true;
	}
}

bool CHTTPHeader::IsPost()const
{
	//Check the raw data
	if (m_aData.size()>4 &&
		(!strnicmp(&m_aData[0],
			       "post",
				   4) ||
		 !strnicmp(&m_aData[0],
			      "put",
				  3) ||
		 !_strnicmp(&m_aData[0],
				    "OPTIONS",
				    7) ||
		 !_strnicmp(&m_aData[0],
				    "PROPFIND",
				    8) ||
		 !_strnicmp(&m_aData[0],
				    "LOCK",
				    4) ||
		 !_strnicmp(&m_aData[0],
				    "SEARCH",
				    6) ||
		 !_strnicmp(&m_aData[0],
				    "REPORT",
				    6)))
		return true;
	else
		return false;
}

const std::string& CHTTPHeader::GetVerb()const
{
	return m_sRequestType;
}

const CHTTPHeader::DataVector& CHTTPHeader::GetPostVector()const
{
	return m_aPostVector;
}

bool CHTTPHeader::IsHTTP100()const
{
	return m_bHTTP100;
}

bool CHTTPHeader::IsBadHeader()const
{
	return m_bBadHeader;
}

std::string CHTTPHeader::GetTerminator()const
{
	if (!m_bBadHeader)
		return "\r\n";
	else
		return "\n";
}

bool CHTTPHeader::IsEmpty()const
{
	return m_aData.empty();
}

void CHTTPHeader::AddToSentPos(DWORD dwPos)
{
	m_dwSentPos+=dwPos;
}

DWORD CHTTPHeader::GetSentPos()const
{
	return m_dwSentPos;
}

void CHTTPHeader::CommitAll()
{
	if (m_bParsed)
		m_dwSentPos=m_aData.size()-1;
	else
		m_dwSentPos=m_aData.size();
}

std::string CHTTPHeader::GetPage()const
{
	//Iterate the data
	DataVector::const_iterator aIterator;
	aIterator=m_aData.begin();
	
	//Look for space
	while (aIterator!=m_aData.end() &&
		   *aIterator!=' ')
		++aIterator;

	//Clear the spaces
	while (aIterator!=m_aData.end() &&
		   *aIterator==' ')
		++aIterator;

	//Get the data
	std::string sData;
	while (aIterator!=m_aData.end() &&
		   *aIterator!=' ')
	{
		//Add the data
		sData+=*aIterator;
		++aIterator;
	}

	//Done
	return sData;
}

void CHTTPHeader::DisablePost()
{
	m_bParsePost=false;
}

bool CHTTPHeader::IsPostParseComplete()const
{
	return m_bPostComplete;
}

std::string CHTTPHeader::GetDateFormated(bool bUTC)
{
	//Get the time
	SYSTEMTIME aTime;

	if (!bUTC)
		GetLocalTime(&aTime);
	else
		GetSystemTime(&aTime);

	//Final data
	std::string sData;

	//Buffer
	char aBuffer[128];

	//First format the date
	if (!GetDateFormat(MAKELCID(MAKELANGID(LANG_ENGLISH,
										   SUBLANG_NEUTRAL),
								SORT_DEFAULT),
					   0,
					   &aTime,
					   "dd/MM/yyyy",
					   aBuffer,
					   sizeof(aBuffer)))
		return "";

	//Add to the data
	sData+=aBuffer;

	//Now format the time
	//First format the date
	if (!GetTimeFormat(MAKELCID(MAKELANGID(LANG_ENGLISH,
										   SUBLANG_NEUTRAL),
								SORT_DEFAULT),
					   0,
					   &aTime,
					   "HH:mm:ss",
					   aBuffer,
					   sizeof(aBuffer)))
		return "";

	//Add to the buffer
	sData+=' ';
	sData+=aBuffer;

	//Done
	return sData;
}

const std::string CHTTPHeader::GetCreationDate()const
{
	return m_sCreationTime;
}

bool CHTTPHeader::IsPartialPostParse()const
{
	return !m_bFirstPost && m_dwLastMemPos>0;
}

CHTTPHeader CHTTPHeader::CreatePostTear()const
{
	//Our tmp header
	CHTTPHeader aHeader;

	//Disable the post
	aHeader.DisablePost();

	//Do we have data?
	if (m_aData.empty())
		return aHeader;

	//What is the size increase
	DWORD dwInc=4;
	if (m_bBadHeader)
		dwInc=2;

	//Now give it our data
	aHeader.Feed(&m_aData[0],
				 m_dwLastMemPos+dwInc);

	//Done
	return aHeader;
}

bool CHTTPHeader::CompareHost(const std::string& rHost)const
{
	//Get the host
	std::string sHost=GetHost();

	//Sanity
	if (sHost.empty() ||
		rHost.size()>sHost.size())
		return false;

	//Convert to lowercase
	sHost=ConvertToLower(sHost);
	std::string sTmpHost=ConvertToLower(rHost);

	//Compare
	for (size_t iCount=0;
		 iCount<sTmpHost.size();
		 ++iCount)
		if (sTmpHost[sTmpHost.size()-iCount-1]!=sHost[sHost.size()-iCount-1])
			return false;

	//We are OK
	return true;
}

std::string CHTTPHeader::GetHost()const
{
	//Are we parsed?
	if (m_bParsed)
		//Get it from the headers
		return GetHeaderString("host");
	else
		return "";
}

void CHTTPHeader::SetNewURL(const std::string& rNewURL)
{
	//Check we are parsed
	if (!m_bParsed ||
		m_aData.empty())
		return;

	//Save the size
	int iSize=m_aData.size();

	//The first line
	std::string sFirstLine=GetVerb();
	sFirstLine+=' ';

	//Build the URL
	if (m_bSSL)
		m_sFullURL="https://";
	else
		//Add the HTTP
		m_sFullURL="http://";
	
	//Add the host
	m_sFullURL+=m_sHost;

	//Add the new url
	m_sFullURL+=rNewURL;

	//Now update the other info
	m_sURL=rNewURL;

	//Is it proxy style?
	if (m_bProxyStyle)
		//Add to the line
		sFirstLine+=m_sFullURL;
	else
		//Add to the line
		sFirstLine+=rNewURL;

	//Add the HTTP version
	sFirstLine+=" HTTP/1.";
	if (IsHTTP11())
		sFirstLine+='1';
	else
		sFirstLine+='0';

	//Our data
	DataVector aTmp;

	//Add the string
	size_t iCount=0;
	for (iCount=0;
		 iCount<sFirstLine.size();
		 ++iCount)
		//Add it
		aTmp.push_back(sFirstLine[iCount]);

	//Find the first line in the original
	char *pPos=lstrinstr(&m_aData[0],
						 GetTerminator().c_str(),
						 &m_aData[0]+m_aData.size());

	//Start to copy from there
	for (iCount=pPos-&m_aData[0];
		 iCount<m_aData.size();
		 ++iCount)
		aTmp.push_back(m_aData[iCount]);

	//Replace them
	aTmp.swap(m_aData);

	//Do we need to adjust the size?
	if (m_aData.size()!=iSize &&
		m_dwHeaderEnd)
	{
		//Adjust the size
		int iHeaderEnd=m_dwHeaderEnd;
		iHeaderEnd+=m_aData.size()-iSize;
		m_dwHeaderEnd=iHeaderEnd;
	}
}

std::string CHTTPHeader::GetFullAddressNoHTTP()const
{
	//Sanity
	if (!(m_sFullURL.size()>8 ||
		  (m_sFullURL.size()>7 && !m_bSSL)))
		return "";

	//What are we
	if (m_bSSL)
		return m_sFullURL.c_str()+8;
	else
		return m_sFullURL.c_str()+7;
}

bool CHTTPHeader::IsHTML()const
{
	if (!m_bParsed)
		return false;

	//Try to get the content type
	std::string sContentType(GetHeaderString("content-type"));

	//Check what we have
	if (!sContentType.empty() &&
		strstr(sContentType.c_str(),
			   "html"))
		return true;
	else
		return false;
}

bool CHTTPHeader::IsImage()const
{
	if (!m_bParsed)
		return false;

	//Try to get the content type
	std::string sContentType(GetHeaderString("content-type"));

	//Check what we have
	if (!sContentType.empty() &&
		strstr(sContentType.c_str(),
			   "image"))
		return true;
	else
		return false;
}

bool CHTTPHeader::IsVideo()const
{
	if (!m_bParsed)
		return false;

	//Try to get the content type
	std::string sContentType(GetHeaderString("content-type"));

	//Check what we have
	if (!sContentType.empty() &&
		strstr(sContentType.c_str(),
			   "video"))
		return true;
	else
		return false;
}

bool CHTTPHeader::IsApplication()const
{
	if (!m_bParsed)
		return false;

	//Try to get the content type
	std::string sContentType(GetHeaderString("content-type"));

	//Check what we have
	if (!sContentType.empty() &&
		strstr(sContentType.c_str(),
			   "application"))
		return true;
	else
		return false;
}

std::string CHTTPHeader::GetReferer()const
{
	return GetHeaderString("referer");
}

DWORD CHTTPHeader::GetID()const
{
	return m_dwID;
}

std::string CHTTPHeader::ConvertToLower(const std::string& rString)
{
	if (!rString.empty())
	{
		//Clone the string
		char* pTmp;
		pTmp=new char[rString.size()+1];
		memcpy(pTmp,
			   rString.c_str(),
			   rString.size()+1);

		//Convert
		strlwr((LPSTR)pTmp);

		//Our string
		std::string sTmp((LPSTR)pTmp);

		//Delete our old data
		delete [] pTmp;

		//Done
		return sTmp;
	}
	else
		return rString;
}

bool CHTTPHeader::CheckFirstLine(const std::string& rData)const
{
	//Do we have data
	if (m_aData.empty() ||
		m_aData.size()<rData.size())
		return false;

	//Compare the data
	return !strnicmp(&m_aData[0],
					 rData.c_str(),
					 rData.size());
}