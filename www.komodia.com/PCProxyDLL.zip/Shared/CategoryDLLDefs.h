#ifndef _CategoryDLLDefs_H_
#define _CategoryDLLDefs_H_

//Language enum
typedef enum _DLLLanguageID
{
	dliEnglish=0
} DLLLanguageID;

//Answer from the category server
typedef enum _CategoryResponse
{
	crGotAnswer=0,
	crError,
	crTryLater
} CategoryResponse;

//Master categories
typedef enum _MasterCategories
{
	mcAdult=0,
	mcInfo,
	mcEntertainment,
	mcMisc,
	mcSecurity,
	mcSystem,
	mcGeneral,
	mcParanoid,
	mcCheckAgainLater
} MasterCategories;

typedef DWORD CategoryIDDLL;

//What is the status of 
#endif
