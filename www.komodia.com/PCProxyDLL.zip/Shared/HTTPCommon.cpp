#include "stdafx.h"
#include "HTTPCommon.h"

char* stristr(const char *String, const char *Pattern)
{
      char *pptr, *sptr, *start;

      for (start = (char *)String; *start != NULL; start++)
      {
            /* find start of pattern in string */
            for ( ; ((*start!=NULL) && (toupper(*start) != toupper(*Pattern))); start++)
                  ;
            if (NULL == *start)
                  return NULL;

            pptr = (char *)Pattern;
            sptr = (char *)start;

            while (toupper(*sptr) == toupper(*pptr))
            {
                  sptr++;
                  pptr++;

                  /* if end of pattern then pattern was found */

                  if (NULL == *pptr)
                        return (start);
            }
      }
      return NULL;
}

std::string DWORD2S(DWORD dwVal)
{
	//Convert it
	char aTmp[12];
	itoa(dwVal,
		 aTmp,
		 10);

	//Done
	return aTmp;
}

std::string GetPath(const std::string& rPath)
{
	//Our string
	std::string sOurString;

	//Reverse iterate the path
	std::string::const_reverse_iterator aIterator;
	aIterator=rPath.rbegin();

	//Search for '\'
	while (aIterator!=rPath.rend() &&
		   *aIterator!='\\')
		++aIterator;

	//Is it the end?
	if (aIterator==rPath.rend())
		return sOurString;

	//Ignore the '\'
	++aIterator;

	//Copy the string
	while (aIterator!=rPath.rend())
	{
		//Copy it
		sOurString=*aIterator+sOurString;

		//Next
		++aIterator;
	}

	//Done
	return sOurString;
}

bool IsConnectProxy(const char* pData,
					DWORD dwSize)
{
	return dwSize>10 &&
		   !_strnicmp(pData,
					  "CONNECT",
					  7);
}

bool IsHTTP(const char* pData,
			DWORD dwSize)
{
	if (dwSize>10)
		if (!_strnicmp(pData,
					  "GET",
					  3) ||
			!_strnicmp(pData,
					  "POST",
					  4) ||
			!_strnicmp(pData,
					  "HEAD",
					  4) ||
			!_strnicmp(pData,
					  "PUT",
					  3) ||
			!_strnicmp(pData,
					  "DELETE",
					  6) ||
			!_strnicmp(pData,
					  "TRACE",
					  5) ||
			!_strnicmp(pData,
					  "OPTIONS",
					  7) ||
			!_strnicmp(pData,
					  "PROPFIND",
					  8) ||
			!_strnicmp(pData,
					  "PROPPATCH",
					  9) ||
			!_strnicmp(pData,
					  "SEARCH",
					  6) ||
			!_strnicmp(pData,
					  "MKCOL",
					  5) ||
			!_strnicmp(pData,
					  "COPY",
					  4) ||
			!_strnicmp(pData,
					  "MOVE",
					  4) ||
			!_strnicmp(pData,
					  "LOCK",
					  4) ||
			!_strnicmp(pData,
					  "UNLOCK",
					  6))
			return true;

	//Not HTTP
	return false;
}

std::string BuildHTML(const std::string& rBody,
					  bool bClose,
					  bool bNoCache,
					  bool bHTML)
{
	//Convert the size
	char aTmp[12];
	itoa(rBody.size(),
		 aTmp,
		 10);

	//HTML header
	std::string sHeader;
	sHeader="HTTP/1.1 200 OK\r\nContent-Type: text/";
	
	//Which type?
	if (bHTML)
		sHeader+="html\r\n";
	else
		sHeader+="plain\r\n";

	//Continue
	sHeader+="Content-Length: ";
	sHeader+=aTmp;
	sHeader+="\r\n";

	//Do we need to close
	if (bClose)
		sHeader+="Connection: close\r\n";
	else
		sHeader+="Connection: keep-alive\r\n";

	//Do we have no cache
	if (bNoCache)
		sHeader+="Cache-Control: no-cache,no-store\r\n";

	//Finalize the header
	sHeader+="\r\n";

	//Add the body
	sHeader+=rBody;

	//Done
	return sHeader;
}

std::string BuildRedirectReply(const std::string& rRedirectTo,
							   bool bClose,
							   bool bNoCache)
{
	//Our quote
	std::string sQuote;
	sQuote='"';

	//Build a new string
	std::string sTmp;
	sTmp+="<html><head><META HTTP-EQUIV="+sQuote+"Refresh"+sQuote+" CONTENT="+sQuote+"0;URL=";
	sTmp+=rRedirectTo;
	sTmp+=sQuote+"></head></html>";

	//Done
	return BuildHTML(sTmp,
					 bClose,
					 bNoCache);
}

DWORD CharToNumber(char c)
{
	if (c>='0' &&
		c<='9')
		return c-'0';
	else if (c>='a' &&
			 c<='f')
		return c-'a'+10;
	else if (c>='A' &&
			 c<='F')
		return c-'A'+10;
	else
		return 0;
}

DWORD S2DWORD(const std::string& rString)
{
	return atoi(rString.c_str());
}

std::string BuildHTTPRedirect(const std::string& rURL,
							  bool bClose)
{
	//HTML header
	std::string sHeader;
	sHeader="HTTP/1.1 302 FOUND\r\n";
	sHeader+="Location: ";
	sHeader+=rURL;
	sHeader+="\r\n";
	sHeader+="Cache-Control: no-cache, no-store\r\n";

	//Do we need to close
	if (bClose)
		sHeader+="Connection: close\r\n";

	//Finalize the header
	sHeader+="\r\n";

	//Done
	return sHeader;
}
