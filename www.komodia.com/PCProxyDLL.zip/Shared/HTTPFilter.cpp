#include "stdafx.h"
#include "HTTPFilter.h"

#include "DataManager.h"
#include "StrFunc.h"

CHTTPFilter::CHTTPFilter() : m_bIsInHeader(false),
							 m_bEmptyRN(false),
							 bFirstHeader(true),
							 m_bCookie(false),
							 m_bBadDivider(false)
{
}

CHTTPFilter::~CHTTPFilter()
{
}

bool CHTTPFilter::ProcessData(const char* pData,
							  DWORD dwDataSize,
							  char** pNewBuffer,
							  DWORD& rNewDataSize)
{
	//First need to check if we are in header or not
	if (!m_bIsInHeader)
	{
		//Clear the header
		m_bEmptyRN=false;
		bFirstHeader=true;
		m_bBadDivider=false;

		//Look for it
		if (dwDataSize>10)
			if ( !strncmp(pData,
						  "GET",
						  3) ||
				 !strncmp(pData,
						  "POST",
						  4) ||
				 !strncmp(pData,
						  "HEAD",
						  4) ||
				 !strncmp(pData,
						  "PUT",
						  3) ||
				 !strncmp(pData,
						  "DELETE",
						  6) ||
				 !strncmp(pData,
						  "TRACE",
						  5) ||
				 !strncmp(pData,
						  "OPTIONS",
						  7) ||
				 !strncmp(pData,
						  "CONNECT",
						  7) ||
				 !strncmp(pData,
						  "PROPFIND",
						  8) ||
				 !strncmp(pData,
						  "PROPPATCH",
						  9) ||
				 !strncmp(pData,
						  "MKCOL",
						  5) ||
				 !strncmp(pData,
						  "COPY",
						  4) ||
				 !strncmp(pData,
						  "MOVE",
						  4) ||
				 !strncmp(pData,
						  "LOCK",
						  4) ||
				 !strncmp(pData,
						  "UNLOCK",
						  6) ||
				 !strncmp(pData,
						  "HTTP/1.",
						  7))
			{
				//Set we are in header
				m_bIsInHeader=true;

				//Copy the headers
				m_aSpecialFieldsRemoved=m_aSpecialFields;

				//Clear cookie flag
				m_bCookie=false;
			}
	}
	
	//Are we in header?
	if (m_bIsInHeader)
	{
		//Did we had a change?
		bool bChange=false;

		//Do we have data?
		if (!m_aData.empty())
			bChange=true;

		//Insert all into the vector
		for (DWORD dwCounter=0;
			 dwCounter<dwDataSize;
			 ++dwCounter)
			m_aData.push_back(pData[dwCounter]);

		//Start to process the vector
		//This is the outgoing vector
		DataVector aOutgoing;

		//This is the tmp string
		std::string sTmp;
		
		//Check for bad divider
		if (!bChange)
		{
			//Iterate the first string
			DataVector::iterator aIterator=m_aData.begin();
			while (aIterator<m_aData.end() &&
				   *aIterator!='\n')
				++aIterator;

			//Check the data
			if (aIterator!=m_aData.end())
			{
				//Previous one
				--aIterator;

				//Check again
				if (aIterator!=m_aData.end() &&
					*aIterator!='\r')
					m_bBadDivider=true;
			}
		}

		//Start
		DataVector::iterator aIterator=m_aData.begin();
		while (aIterator<m_aData.end())
		{
			//Can we add to the string?
			if ((!m_bBadDivider && *aIterator=='\r') ||
				(m_bBadDivider && *aIterator=='\n'))
			{
				DataVector::iterator aTmp(aIterator);
				++aTmp;

				//Is it the last char?
				if ((aTmp!=m_aData.end() &&
					 *aTmp=='\n') ||
					m_bBadDivider)
				{
					//The header
					std::string sHeader;

					//Do we dump the string
					bool bDump=false;

					//Our data
					std::string sData;

					//Is it an empty \r\n?
					if (sTmp.empty())
					{
						//Set we have an empty RN
						m_bEmptyRN=true;

						//Advance the iterator
						++aIterator;

						//Now see if we can add the data
						if (!m_aSpecialFieldsRemoved.empty())
						{
							//Set we have a change
							bChange=true;

							//Add the data
							for (HTTPMap::iterator aIterator2=m_aSpecialFieldsRemoved.begin();
								 aIterator2!=m_aSpecialFieldsRemoved.end();
								 ++aIterator2)
								//Do we need to check for cookie?
								if (!m_bCookie &&
									!m_sCookieDataSupp.empty() &&
									ConvertToLower(aIterator2->first)==std::string("cookie"))
								{
									//Take the data
									std::string sData(aIterator2->second);

									//Is last data is ;?
									if (sData.empty() ||
										(*sData.rend())!=';')
										//Add the terminating ;
										sData+="; ";

									//Build the new cookie
									sTmp+=aIterator2->first;
									sTmp+=':';
									sTmp+=sData;
									sTmp+=m_sCookieDataSupp;

									if (!m_bBadDivider)
										sTmp+="\r\n";
									else
										sTmp+="\n";

									//Set we had a cookie
									m_bCookie=true;
								}
								else
								{
									//Add to existing
									sTmp+=aIterator2->first+": "+aIterator2->second;
									
									if (!m_bBadDivider)
										sTmp+="\r\n";
									else
										sTmp+="\n";
								}
						}
					}
					else
						//We can process the string
						sHeader=ExtractHeader(sTmp,sData);						

					//Do we have a header?
					if (!sHeader.empty() &&
						!bFirstHeader)
					{
						//Check if we need to replace the header?
						HTTPMap::const_iterator aFindSwitchIterator;
						aFindSwitchIterator=m_aHeaderSwitch.find(ConvertToLower(sHeader));
						if (aFindSwitchIterator!=m_aHeaderSwitch.end())
						{
							//Set a change
							bChange=true;

							//Need to replace it
							sHeader=aFindSwitchIterator->second;
							
							//Need to modify the string
							sTmp=sHeader;
							sTmp+=':';
							sTmp+=sData;
						}

						//Try to find it
						HTTPMap::const_iterator aFindIterator;
						aFindIterator=m_aFilter.find(ConvertToLower(sHeader));

						//Do we have it
						if (aFindIterator!=m_aFilter.end())
						{
							//What kind of command do we have?
							if (aFindIterator->second.empty())
								//Dump it
								bDump=true;
							else
							{
								//Need to modify the string
								sTmp=sHeader;
								sTmp+=':';
								sTmp+=aFindIterator->second;
							}

							//Set we had a change
							bChange=true;
						}
						else if (!m_sCookieDataSupp.empty() &&
								 ConvertToLower(sHeader)==std::string("cookie"))
						{
							//Need to modify the cookie
							//Is last data is ;?
							if (sData.empty() ||
								(*sData.rend())!=';')
								//Add the terminating ;
								sData+="; ";

							//Build the new cookie
							sTmp=sHeader;
							sTmp+=':';
							sTmp+=sData;
							sTmp+=m_sCookieDataSupp;

							//Set to change
							bChange=true;

							//Set we had a cookie
							m_bCookie=true;
						}

						//Remove this field, only if not delete
						if (!bDump)
							//Try to remove from the optional headers
							m_aSpecialFieldsRemoved.erase(ConvertToLower(sHeader));
					}
					else if (bFirstHeader &&
							 !m_sProxyPrefix.empty())
					{
						//Need to add proxy prefix
						std::string sNewTmp;

						//Another tmp to check if we are a proxy
						std::string sAnotherTmp(sTmp);

						//First scan the buffer
						std::string::const_iterator aIterator3;
						aIterator3=sTmp.begin();

						//Get to the space
						while (aIterator3!=sTmp.end() &&
							   *aIterator3!=' ')
						{
							//Add it
							sNewTmp+=*aIterator3;
							++aIterator3;

							//Trim the char
							sAnotherTmp=sAnotherTmp.substr(1,sAnotherTmp.size()-1);
						}

						//Clear all spaces now
						while (aIterator3!=sTmp.end() &&
							   *aIterator3==' ')
						{
							//Add it
							sNewTmp+=*aIterator3;
							++aIterator3;

							//Trim the char
							sAnotherTmp=sAnotherTmp.substr(1,sAnotherTmp.size()-1);
						}

						//Should we add the prefix?
						if (strnicmp(sAnotherTmp.c_str(),
									 "http://",
									 7) &&
							strnicmp(sAnotherTmp.c_str(),
									 "https://",
									 8))
						{
							//Now add the prefix
							sNewTmp+=m_sProxyPrefix;

							//Add the rest of the string
							//And add all
							while (aIterator3!=sTmp.end())
							{
								//Add it
								sNewTmp+=*aIterator3;
								++aIterator3;
							}

							//And switch
							sTmp=sNewTmp;

							//Set we had a change
							bChange=true;
						}
					}

					//Not first header
					bFirstHeader=false;

					//Advance the iterator
					if (!m_bBadDivider)
						++aIterator;

					//Can we add it?
					if (!bDump)
					{
						//Are we in final stages?
						if (m_bEmptyRN &&
							!m_bCookie &&
							!m_sCookieDataSupp.empty())
						{
							//Need to add the cookie
							sTmp+="Cookie: ";
							sTmp+=m_sCookieDataSupp;

							if (!m_bBadDivider)
								sTmp+="\r\n";
							else
								sTmp+="\n";

							//Set we had the cookie
							m_bCookie=true;

							//Set we had a change
							bChange=true;
						}

						//Was it OK?
						//Add the \r\n
						if (!m_bBadDivider)
							sTmp+="\r\n";
						else
							sTmp+="\n";

						//Add it to the outgoing data
						for (DWORD dwCounter=0;
							 dwCounter<sTmp.size();
							 ++dwCounter)
							aOutgoing.push_back(sTmp[dwCounter]);
					}

					//Do we need to continue?
					if (m_bEmptyRN)
					{
						//We need to copy rest of the data to the outgoing buffer
						while (aIterator<m_aData.end())
						{
							//Add the data
							aOutgoing.push_back(*aIterator);

							//Next
							++aIterator;
						}

						//Clear the string
						sTmp="";

						//Exit
						break;
					}

					//Clear the string
					sTmp="";
				}
				else
					//Add it to the string
					sTmp+=*aIterator;
			}
			else
				sTmp+=*aIterator;
		
			//Next
			++aIterator;
		}

		//Clear the old data
		m_aData.clear();

		//What we have to send now?
		//Do we have a loose string?
		if (!sTmp.empty())
		{
			//Add it to the new data
			for (DWORD dwCounter=0;
				 dwCounter<sTmp.size();
				 ++dwCounter)
				m_aData.push_back(sTmp[dwCounter]);

			//Set change
			bChange=true;
		}

		//Are we finished?
		if (m_bEmptyRN)
			//Set we are done
			m_bIsInHeader=false;

		//Did we had a change?
		if (bChange)
		{
			//Save the size
			rNewDataSize=aOutgoing.size();

			//Create a copy
			*pNewBuffer=new char[rNewDataSize];

			//Make sure we have data
			if (rNewDataSize)
				memcpy(*pNewBuffer,
					   &aOutgoing[0],
					   rNewDataSize);

			//Exit
			return true;
		}
		else
			return false;
	}
	else
		return false;
}

void CHTTPFilter::ChangeHTTPHeader(const std::string& rHeader,
								   const std::string& rNew)
{
	//And add to the set
	m_aFilter[ConvertToLower(rHeader)]=CloneString(rNew);
}

void CHTTPFilter::FilterHTTPHeader(const std::string& rHeader)
{
	//Convert to lower case
	//And add to the set
	m_aFilter[ConvertToLower(rHeader)]="";
}

std::string CHTTPFilter::ConvertToLower(const std::string& rString)
{
	if (!rString.empty())
	{
		//Clone the string
		char* pTmp;
		pTmp=new char[rString.size()+1];
		memcpy(pTmp,
			   rString.c_str(),
			   rString.size()+1);

		//Convert
		strlwr(pTmp);

		//Our string
		std::string sTmp((LPCSTR)pTmp);

		//Delete our old data
		delete [] pTmp;

		//Done
		return sTmp;
	}
	else
		return rString;
}

std::string CHTTPFilter::ExtractHeader(const std::string& rString,
									   std::string& rData)
{
	//Our header
	std::string sHeader;

	//Did we switch to data?
	bool bData=false;

	//Start to iterate
	for (DWORD dwCount=0;
		 dwCount<rString.size();
		 ++dwCount)
	{
		//Is it ':'
		if (rString[dwCount]==':')
			//Set we have data
			bData=true;
		else if (!bData)
			sHeader+=rString[dwCount];
		else
			rData+=rString[dwCount];
	}

	//Do we have it?
	if (bData)
		return sHeader;
	else
		//We don't have it
		return "";
}

bool CHTTPFilter::IsInHTTP()const
{
	return m_bIsInHeader;
}

void CHTTPFilter::InsertSpecialField(const std::string& rField,
									 const std::string& rData,
									 bool bPreserveCase)
{
	//Do we preserve case?
	if (!bPreserveCase)
		m_aSpecialFields[ConvertToLower(rField)]=CloneString(rData);
	else
		m_aSpecialFields[rField]=CloneString(rData);
}

void CHTTPFilter::SetProxyPrefix(const std::string& rProxyPrefix)
{
	m_sProxyPrefix=rProxyPrefix;
}

void CHTTPFilter::ChangeHTTPHeaderField(const std::string& rHeader,
										const std::string& rNewHeader)
{
	m_aHeaderSwitch[ConvertToLower(rHeader)]=CloneString(rNewHeader);
}

void CHTTPFilter::Clear()
{
	//Some vars
	m_bIsInHeader=false;
	m_bEmptyRN=false;
	bFirstHeader=true;
	m_bCookie=false;
	m_sProxyPrefix="";
	m_sCookieDataSupp="";
	m_bBadDivider=false;

	//The vectors
	//This was the old way, the new way will clear the memory
	/*m_aFilter.clear();
	m_aData.clear();
	m_aSpecialFields.clear();
	m_aSpecialFieldsRemoved.clear();
	m_aHeaderSwitch.clear();*/

	//New method
	ClearVector(m_aFilter);
	ClearVector(m_aData);
	ClearVector(m_aSpecialFields);
	ClearVector(m_aSpecialFieldsRemoved);
	ClearVector(m_aHeaderSwitch);
}

bool CHTTPFilter::IsEmpty()const
{
	return !(!m_sProxyPrefix.empty() ||
		     !m_aSpecialFields.empty() ||
		     !m_aHeaderSwitch.empty() ||
		     !m_aSpecialFieldsRemoved.empty() ||
		     !m_aFilter.empty() ||
			 !m_sCookieDataSupp.empty());
}

void CHTTPFilter::SupplementCookie(const std::string& rCookieData)
{
	//Set the supplement
	m_sCookieDataSupp=rCookieData;
}

void CHTTPFilter::RemoveFilterHTTPHeader(const std::string& rHeader)
{
	m_aFilter.erase(ConvertToLower(rHeader));
}

void CHTTPFilter::RemoveChangeHTTPHeaderField(const std::string& rHeader)
{
	m_aFilter.erase(ConvertToLower(rHeader));
}

void CHTTPFilter::RemoveInsertSpecialField(const std::string& rField)
{
	m_aSpecialFields.erase(ConvertToLower(rField));
}