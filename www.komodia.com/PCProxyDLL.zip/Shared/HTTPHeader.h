#if !defined(AFX_HTTPHEADER_H__014BE0CE_2E66_495C_934A_3F26F0BB1330__INCLUDED_)
#define AFX_HTTPHEADER_H__014BE0CE_2E66_495C_934A_3F26F0BB1330__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include <string>
#include <map>

class CHTTPData;

class CFastVector
{
public:
	typedef std::vector<char> DataVector;
public:
	//Are we empty
	bool Empty()const;

	//Clear the data
	void Clear();

	//Get the data (data is allocated)
	void GetData(DataVector& rVector)const;

	//Add the data
	void AddDataV(const char* pData,
				  DWORD dwSize);

	//Assigment operator
	CFastVector& operator=(const CFastVector& rVector);

	//Ctor and Dtor
	CFastVector();
	CFastVector(const CFastVector& rVector);
	virtual ~CFastVector();
private:
	//The data struct
	typedef struct VectorData
	{
		char*	pData;
		DWORD	dwSize;
	} VectorData;

	//Our vector of data
	typedef std::vector<VectorData> FastVector;
private:
	//Our vector
	FastVector m_aVector;

	//Total size
	DWORD m_dwTotalSize;
};

//This class is NOT thread safe
class CHTTPHeader  
{
public:
	//Vector of cookies
	typedef std::vector<std::string> CookieVector;

	//Our data stream
	typedef std::vector<char> DataVector;
public:
	//Get the ID
	DWORD GetID()const;

	//Get the refer
	std::string GetReferer()const;

	//Are we html (will check by content-type)
	bool IsHTML()const;

	//Are we image (will check by content-type)
	bool IsImage()const;

	//Are we video (will check by content-type)
	bool IsVideo()const;

	//Are we application (will check by content-type)
	bool IsApplication()const;

	//Set a new URL (will only replace what's after the /)
	void SetNewURL(const std::string& rNewURL);

	//Get the host
	std::string GetHost()const;

	//Compare host (excluding sub domains)
	bool CompareHost(const std::string& rHost)const;

	//Create a tear off of the post
	CHTTPHeader CreatePostTear()const;

	//Get the creation data
	const std::string GetCreationDate()const;

	//Do we have a partial post parse (only header, but no post yet)
	bool IsPartialPostParse()const;

	//Is post parse complete
	bool IsPostParseComplete()const;

	//Disable post
	void DisablePost();

	//Add to the sent position (means data was sent until this point)
	void AddToSentPos(DWORD dwPos);
	DWORD GetSentPos()const;
	void CommitAll();

	//Is it a bad header?
	bool IsBadHeader()const;

	//Is it HTTP 100
	bool IsHTTP100()const;

	//Get the post vector which is the actual body of the post
	//(only if header was parsed, and it's a post request, like POST / HTTP/1.1)
	const DataVector& GetPostVector()const;

	//Replace all the request with custom data
	bool ReplaceAll(const char* pData,
					unsigned long ulSize,
					bool bReparse=false);

	//Get the verb
	const std::string& GetVerb()const;

	//Get the URL
	const std::string& GetURL()const;

	//Get full web address (including http)
	const std::string& GetFullAddress()const;
	
	//Get full web address (exluding http)
	std::string GetFullAddressNoHTTP()const;

	//Get the incomplete full URL
	std::string GetIncompleteFullAddress()const;

	//Is this a request
	bool IsRequest()const;

	//Is it post
	bool IsPost()const;

	//Get the response code
	unsigned short GetResponseCode()const;

	//What version are we?
	bool IsHTTP11()const;

	//Does the header contain proxy information, e.g. GET http://
	bool DoesContainProxyInfo()const;

	//Get a striped version without proxy addition
	DataVector GetStrippedRequest()const;

	//Set a header (only for complete requests)
	//Will replace existing
	//Will add if not exists
	void SetHeader(const std::string& rHeader,
				   const std::string& rData);

	//Remove a header (only for complete requests)
	void DeleteHeader(const std::string& rHeader);

	//Is it a complete header?
	bool IsParsed()const;

	//Get host without having a complete header
	std::string GetIncompleteHost()const;

	//Check the first line
	bool CheckFirstLine(const std::string& rData)const;

	//Does it contain the cookie already?
	bool DoesContainCookie()const;

	//Does it contain the cookie already?
	//And is this cookie full? (includes \r\n)
	bool DoesContainFullCookie()const;

	//Does it contain data?
	bool DoesContainData()const;

	//Clear the data
	void Clear(bool bDontClearSecure=false);

	//Get the cookies
	const CookieVector& GetCookies()const;

	//Get the first cookie
	std::string GetFirstCookie()const;

	//Get a string from the header
	std::string GetHeaderString(const std::string& rStringToFind)const;

	//Get a string from the header (output is case sensitive)
	std::string GetHeaderStringCase(const std::string& rStringToFind)const;

	//Give it data
	bool Feed(const char* pData,
			  unsigned long ulSize,
			  bool bCommit=true);

	//Feed from LSP
	bool Feed(LPWSABUF pBuf,
			  DWORD dwBufCount);

	//Roll back a feed from LSP
	void Rollback(LPWSABUF pBuf,
				  DWORD dwBufCount);

	//Feed it from start (perform a clear)
	bool ForceFeed(const char* pData,
				   unsigned long ulSize);

	//Give it data and get the change (get the data not related to the header)
	bool FeedGetChange(const char* pData,
					   unsigned long ulSize,
					   unsigned long& rChange);

	//Get the header
	DataVector GetHeaderData(DWORD dwStart=0,
							 bool bNoPost=false)const;

	//Get the header as string
	std::string GetHeaderDataString(DWORD dwStart=0)const;
	std::string GetHeaderDataStringNoPost(DWORD dwStart=0)const;

	//Set this to be a secure (this is SSL)
	void SetSecure();

	//Is it empty?
	bool IsEmpty()const;

	//Get the page
	std::string GetPage()const;

	//Copy operator
	CHTTPHeader& operator=(const CHTTPHeader& rHeader);

	//Ctor and Dtor
	CHTTPHeader(bool bParsePost=true,
				bool bRecursedHeader=false);
	CHTTPHeader(const CHTTPHeader& rHeader);
	virtual ~CHTTPHeader();
private:
	//Header breaked
	typedef std::map<std::string,std::string> BreakedMap;

	//Vector of WWW-Authenticate
	typedef std::vector<std::string> AuthVector;
private:
	//Convert string to lower case
	static std::string ConvertToLower(const std::string& rString);

	//Try to break the header
	bool BreakHeader(DWORD dwLastFedSize);

	//Extract the response code
	void ExtractHTTPResponse();

	//Extract the request
	void ExtractRequestType();

	//Extract the URL
	void ExtractURL();

	//Move the data
	void MoveData()const;

	//Get the date
	std::string GetDateFormated(bool bUTC=false);

	//Get \r\n or \n
	std::string GetTerminator()const;

	//Convert the case
	static char C2L(char cChar);

	//The data
	mutable DataVector m_aData;

	//Have we parsed the header
	bool m_bParsed;

	//HTTP version
	bool m_bVersion11;

	//Our breaked header
	BreakedMap m_aBreakedHeader;

	//Our breaked header (case sensitive)
	BreakedMap m_aBreakedHeaderCase;

	//Our cookies
	CookieVector m_aCookies;

	//Our authentications
	AuthVector m_aAuth;

	//The response code
	unsigned short m_usResponseCode;

	//The request type
	std::string m_sRequestType;

	//The URL
	std::string m_sURL;

	//The full URL
	std::string m_sFullURL;

	//Do we parse post
	bool m_bParsePost;

	//Is it SSL
	bool m_bSSL;

	//The host (will persist)
	std::string m_sHost;

	//Post vector
	DataVector m_aPostVector;

	//Do we have HTTP 100?
	bool m_bHTTP100;

	//Our tmp HTTP100 data
	CHTTPData* m_pHTTP100Data;

	//Where does the header ends
	DWORD m_dwHeaderEnd;

	//Is it a bad header (servers using only \n)
	bool m_bBadHeader;

	//Bad header 2 (servers terminating with \r\n\r
	bool m_bBadHeader2;

	//Not accepting LSP feeds
	bool m_bNoMoreLSPFeeds;

	//Commit sent pos
	DWORD m_dwSentPos;

	//Post info
	bool m_bFirstPost;
	bool m_bPostParsed;
	std::string m_sPostLength;
	bool m_bPostChunked;
	bool m_bPostComplete;

	//Recursed header flag
	bool m_bRecursed;

	//Creation time
	std::string m_sCreationTime;

	//Fast vector for big size data
	//mutable CFastVector m_aFastVector;

	//Last memory position of \r\n
	DWORD m_dwLastMemPos;

	//Is it proxy style?
	bool m_bProxyStyle;

	//Vector capacity
	DWORD m_dwCapacity;

	//Our ID
	DWORD m_dwID;
};

#endif // !defined(AFX_HTTPHEADER_H__014BE0CE_2E66_495C_934A_3F26F0BB1330__INCLUDED_)
