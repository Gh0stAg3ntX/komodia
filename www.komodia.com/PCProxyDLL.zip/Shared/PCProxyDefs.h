#ifndef _PCProxyDefs_H_
#define _PCProxyDefs_H_

#pragma pack(push)
#pragma pack(4)

#ifndef _WIN64
typedef DWORD ContextDWORD;
#else
typedef long long ContextDWORD;
#endif

//Proxy type
typedef enum _DLLProxyType
{
	dptHTTP,
	dptHTTPConnect,
	dptHTTPConnectSSL,
	dptHTTPHybrid,
	dptHTTPHybridSSL,
	dptSocks4,
	dptSocks5,
	dptHTTPSSL,
	dptSocks5TCPUDP,
	dptRedirect,
	dptRedirectBypass,
	dptSSLSubst,
	dptSocks5UDP,
	dptNoDecrypt,
	dptBypassConnection
} DLLProxyType;

//How do we process HTTP
typedef enum _DLLHTTPResult
{
	dhrNothing=0,
	dhrBlock,
	dhrRedirect,
	dhrModify,
	dhrReturnHTML,
	dhrReturnHTMLAndHeader,
	dhrDontDoParental,
	dhrDontProcessPost,
	dhrDontDoParentalAndDontProcessPost,
	dhrSkip,
	dhrModifyBodySDKAdjustHeader,
	dhrModifyDontProcessPostPayload,
	dhrDontDoParentalAndDontProcessPostModify,
	dhrBuildButDontAggregate,
	dhrDefer,
	dhrWaitForCategory,
	dhrDontDoParentalAndModify,
	dhrStartInject,
	dhrPayloadInjected,
	dhrPayloadInjectedBuildButDontAggregate
} DLLHTTPResult;

//Structure of the proxy information
typedef struct _ProxyInformation
{
	bool			bUsingProxy;
	DLLProxyType	aProxyType;
	char*			pUsername;
	char*			pPassword;
	unsigned long	ulIP;
	unsigned short	usPort;
} ProxyInformation;

//Information of the process
typedef struct _ProcessInformation
{
	unsigned long	ulPID;
	unsigned short*	pProcessName;
	unsigned short*	pDomain;
	unsigned short*	pUsername;
	_ProcessInformation() : ulPID(0),
							pProcessName(NULL),
							pDomain(NULL),
							pUsername(NULL)
	{
	}
} ProcessInformation;

//Information for header manipulation for outgoing data
typedef struct _OutgoingDataManipulations
{
	//Do we even want to control the filter (the reason is we can have an empty filter, but it will overide
	//the existing filters)
	bool			bUseFilter;

	//These booleans control the interaction of the filter and the global filter
	bool			bOverideProxyFilter;	//Set this to true to overide the proxy filter (not recommended)
	bool			bOverideGlobalFilter;	//Set this to true to overide the global filter (which you set in the console)

	//This part deals with headers to remove from the HTTP header
	unsigned long	ulHeadersToRemove;
	char**			ppHeadersToRemove;

	//This part is for headers to add
	unsigned long	ulHeadersToAdd;
	char**			ppHeadersToAdd;

	//This part is for headers to change
	unsigned long	ulHeadersToChange;
	char**			ppHeadersToChange;
} OutgoingDataManipulations;

//Return value of get flag
#define GET_FLAG_BUFFER_OVERFLOW -1
#define GET_FLAG_NO_RESULT 0
#define GET_FLAG_OK_RESULT 1

//Flag manipulation functions
typedef int (_stdcall *PGetFlagInformation)(const wchar_t* pIndex,
											wchar_t* pValue,
											DWORD dwValueStringSize);

typedef void (_stdcall *PSetFlagInformation)(const wchar_t* pIndex,
										 	 const wchar_t* pValue);

typedef void (_stdcall *PSaveInformation)();

//Set a callback method
typedef bool (_stdcall *PSetCallback)(DWORD dwCallbackID,
									  LPVOID lpCallback);

//Callbacks ID
#define CALLBACK_FIREFOX 1

//Our callbacks
typedef void (_stdcall *PCallbackFirefox)(const unsigned short* pPath);

//Classification methods
typedef int (_stdcall *PClassifyText)(const char* pData,
									  DWORD dwDataSize,
									  char* pResult,
									  DWORD dwResultSize);

//Return types
#define PP_CLASS_NOT_SUPPORTED 0
#define PP_CLASS_NOT_INITIALIZED -1
#define PP_CLASS_STRING_TOO_SMALL -2
#define PP_CLASS_BAD_ARGS -3

//Structure with Redirector specific functions
typedef struct _FunctionsStruct
{
	DWORD				dwFunctionCount;
	PGetFlagInformation	pGetFlagInformation;
	PSetFlagInformation pSetFlagInformation;
	PSaveInformation	pSaveInformation;
	PSetCallback		pSetCallback;
	PClassifyText		pClassifyText;
} FunctionsStruct;

//UDP structure data
//Packet information
typedef struct _PacketData
{
	DWORD			dwSourceIP;
	unsigned short	usSourcePort;
	DWORD			dwDestinationIP;
	unsigned short	usDestinationPort;
	bool			bOutgoing;
	bool			bTCP;
	bool			bServerSocket;
	DWORD			dwSocketID;
} PacketData;

//Global data
typedef struct _GlobalData
{
	PacketData	aData;
	DWORD		dwTimeStamp;
	DWORD		dwPID;
} GlobalData;

#pragma pack(pop) 

#endif
