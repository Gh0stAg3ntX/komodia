#ifndef _HTTPCommon_H_
#define _HTTPCommon_H_

#include <string>

//No case str str
char* stristr(const char *String, const char *Pattern);

//Convert DWORD to string
std::string DWORD2S(DWORD dwVal);

//Convert string to DWORD
DWORD S2DWORD(const std::string& rString);

//Extract the path
std::string GetPath(const std::string& rPath);

//Check if a buffer is HTTP
bool IsHTTP(const char* pData,
			DWORD dwSize);

//Check if a buffer is HTTP connect
bool IsConnectProxy(const char* pData,
					DWORD dwSize);

//Build a redirect string
std::string BuildRedirectReply(const std::string& rRedirectTo,
							   bool bClose=false,
							   bool bNoCache=false);

//Build a general HTML and header
std::string BuildHTML(const std::string& rBody,
					  bool bClose=false,
					  bool bNoCache=false,
					  bool bHTML=true);

//Build a general HTML and header
std::string BuildHTTPRedirect(const std::string& rURL,
							  bool bClose=false);

//Convert a char to number
DWORD CharToNumber(char c);

#endif
