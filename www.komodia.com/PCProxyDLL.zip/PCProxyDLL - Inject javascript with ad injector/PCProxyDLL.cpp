// PCProxyDLL.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include <string>
#include <map>

#include "PCProxyDefs.h"
#include "HTTPCommon.h"
#include "HTTPHelper.h"
#include "HTTPHeader.h"

extern "C"
{

inline char ltoupper(char c)
{
	if (c>='a' &&
		c<='z')
		return c-32;
	else
		return c;
}

}

char* strinstre(const char *String, const char *Pattern, const char* pEnd)
{
	  //Sanity
	  if (!String ||
		  !Pattern ||
		  !pEnd ||
		  !strlen(Pattern))
	    return NULL;

      char *pptr, *sptr;
	  register char *start;

	  //Clone the pattern
	  char* nptr=new char[strlen(Pattern)+1];
	  strcpy(nptr,
			 Pattern);
	  strupr(nptr);

	  //More optimizations
	  register char c=nptr[0];

      for (start = (char *)String; start<pEnd && *start != NULL; start++)
      {
            /* find start of pattern in string */
            for ( ; start<pEnd && *start && (ltoupper(*start) != c); start++)
                  ;
            if (start>=pEnd)
			{
				delete [] nptr;
                return NULL;
			}

            pptr = (char *)nptr;
            sptr = (char *)start;

            while (sptr<pEnd)
            {
				//Can we compare?
				if (ltoupper(*sptr) == *pptr)
				{
                  sptr++;
                  pptr++;
				}
				else if (*sptr==13 ||
						 *sptr==10 ||
						 *sptr==9 ||
						 *sptr==32)
				{
					++sptr;

					//Do we need to advance current?
					if (*pptr==13 ||
						*pptr==10 ||
						*pptr==9 ||
						*pptr==32)
						++pptr;
				}
				else
					break;

                  /* if end of pattern then pattern was found */

                  if (NULL == *pptr)
				  {
						delete [] nptr;
                        return (start);
				  }
            }
      }

	  delete [] nptr;
      return NULL;
}

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

//The structure that holds our data (this is the struct you change to hold your session specific data)
typedef struct _ContextData
{
	DWORD		dwReserved; //This must be here to avoid any issues modifying SDK structures
	std::string sHost;

	_ContextData() : dwReserved(0)
	{
	}
} ContextData;

//This function is called after DLL is loaded
//All initialization of user specific data should be done here
//And not inside DLLMain
//Return value: True - Continue to process this DLL
bool _stdcall PCInitialize()
{
	return true;
}

//This function is called before the DLL is unloaded
//All uninitializations should be done here
void _stdcall PCUninitialize()
{
}

//This function is used to communicate with the DLL
char* _stdcall DLLQueryData(const char* pData)
{
	//Nothing
	return NULL;
}

//This method is called when a new connection is made
//Read documentation for parameters explanation
bool _stdcall NewConnection(ContextDWORD& rContext,
							bool bFromEncryption,
							unsigned long usListeningPort,
							unsigned long& rIP,
							unsigned short& rPort,
							const ProcessInformation& pPInformation,
							bool& rEnableSSL,
							bool& rSSLSwitch,
							bool& bFreezeReceive,
							const char* pPeekData,
							unsigned long ulPeekDataSize,
							unsigned long& rWaitMoreData,
							ProxyInformation& rProxyInformation,
							const char* pDNSEntry)
{
	//The context
	ContextData* pData=(ContextData*)rContext;

	//Are we new
	bool bNew=false;

	if (!rContext)
	{
		//Create it
		pData=new ContextData;

		//Set new
		bNew=true;
	}
	else
	{
		//Check if it's SDK context
		if (pData->dwReserved)
		{
			//This is SDK context, can be a string or structure, shouldn't modify it
			//Code to manipulate the special context goes here
			
			//At this stage we can create our context
			pData=new ContextData;

			//Set new
			bNew=true;
		}		
	}

	//Do we save the context?
	if (bNew)
		//Save the context
		rContext=(ContextDWORD)pData;

	//Accept the connection
	return true;
}

//This method is called incase there's a connection to a proxy using HTTP connect
//Here there's an option to modify the connect string
//Input and output are strings so they must end with \0
bool _stdcall HandleProxyHTTPConnect(const char* pConnectString,
									 char** ppNewString,
									 ContextDWORD dwContext)
{
	//Don't modify
	return false;
}

//This method is called before data is sent back to the application
//Read documentation for parameters explanation
bool _stdcall DataBeforeReceive(const char* pData,
								DWORD dwDataSize,
								char** pNewBuffer,
								DWORD& rNewDataSize,
								bool& rTerminateSession,
								bool& rThawReceiveFreeze,
								bool& rEnableSSL,
								bool bServerClosed,
								ContextDWORD dwContext)
{
	//Do we have a context?
	ContextData* pContext;
	pContext=(ContextData*)dwContext;

	//Do nothing
	return false;
}

//This method is called before data is sent to to the application
//Read documentation for parameters explanation
//Return value: false - Data wasn't changed, true - data was changed
bool _stdcall DataBeforeSend(const char* pData,
							 DWORD dwDataSize,
							 char** pNewBuffer, 
							 DWORD& rNewDataSize,
							 bool& rTerminateSession,
							 bool& rNewBufferToReceive,
							 OutgoingDataManipulations& rManipulations,
							 ContextDWORD dwContext)
{
	//Take the context
	ContextData* pContext;
	pContext=(ContextData*)dwContext;

	//Done
	return false;
}

//This method is called if parental control is enabled, and the product supports it
//This will process the send before it's finished
//This is only relevant when the parental control module is working
DLLHTTPResult _stdcall HTTPRequestBeforeSend(const char* pHeader,
											 DWORD dwHeaderSize,
											 char** ppNewHeader,
											 DWORD& rNewHeaderSize,
											 bool bPartialPost,
											 ContextDWORD dwContext)
{
	//Take the context
	ContextData* pData;
	pData=(ContextData*)dwContext;

	//At this stage we have a complete header
	//It's easiest to work with the supplied class
	//For header parsing
	//Give it to the header
	CHTTPHeader aHeader;
	if (aHeader.Feed(pHeader,
					 dwHeaderSize))
	{
		//We can get some usefull information at this stage
		//Host
		std::string sHost(aHeader.GetHost());

		//URI
		std::string sURI(aHeader.GetURL());

		//The full address
		std::string sFullAddress(aHeader.GetFullAddress());

		//Save the host in the session data
		if (pData &&
			pData->sHost.empty())
			pData->sHost=sHost;

		//Lets say we want to build a redirect based on the request
		//We need to make sure that we are not redirecting over and over
		//The site we are redirecting to
		//This code performs it
		if (stristr(sHost.c_str(),
				    "google.co")) //Google can be in many languages
			return dhrDontProcessPost;
		else
			return dhrDontDoParentalAndDontProcessPost;
	}

	//Done
	return dhrDontDoParentalAndDontProcessPost;
}

//This will process the receive before it's finished
//This is only relevant when the parental control module is working
DLLHTTPResult _stdcall HTTPRequestBeforeReceive(const char* pHeader,
											    DWORD dwHeaderSize,
											    char** ppNewHeader,
											    DWORD& rNewHeaderSize,
												const char* pData,
												DWORD dwDataSize,
												char** ppNewData,
												DWORD& rNewDataSize,
												bool bHeaderCheck,
												ContextDWORD dwContext)
{
	//Take the context
	ContextData* pContext;
	pContext=(ContextData*)dwContext;

	//If we are here, it means we got a Google page, check the content type
	//At this stage we have a complete header
	//It's easiest to work with the supplied class
	//For header parsing
	//Give it to the header
	CHTTPHeader aHeader;
	if (aHeader.Feed(pHeader,
					 dwHeaderSize))
	{
		//Get the content type
		std::string sContent=aHeader.GetHeaderString("content-type");

		//Check that it's HTML
		if (!sContent.empty() &&
			strstr(sContent.c_str(),"html"))
		{
			//Can we do something?
			if (bHeaderCheck)
			{
				//We want to use the ad injector
				//Do we have data?
				if (!pData ||
					!dwDataSize)
					return dhrStartInject;
				else
				{
					//If we are here, it means we can check the partial data
					//Our string to inject
					std::string sInject="123injectedstring123";

					//We can modify the data, search for </head>
					char* pTmp=strinstre(pData,
										 "</head",
										 pData+dwDataSize);

					//Do we have it?
					if (pTmp)
					{
						//Build the injected data
						//Adjust size
						rNewDataSize=dwDataSize+sInject.size();

						//Build new data
						*ppNewData=new char[dwDataSize+sInject.size()];

						//The cutoff location
						DWORD dwLoc=pTmp-pData;

						//Copy the data
						memcpy(*ppNewData,
							   pData,
							   dwLoc);

						memcpy(*ppNewData+dwLoc,
							   sInject.c_str(),
							   sInject.size());

						memcpy(*ppNewData+dwLoc+sInject.size(),
							   pData+dwLoc,
							   dwDataSize-dwLoc);

						//Tell SDK to modify
						return dhrPayloadInjected;
					}
					else
						//Wait for more data
						return dhrStartInject;
				}
			}
			else
			{
				//If we are here, it means we have the complete page and we will inject normally
				//Our string to inject
				std::string sInject="123injectedstring123";

				//We can modify the data, search for </head>
				char* pTmp=strinstre(pData,
									 "</head",
									 pData+dwDataSize);

				//Do we have it?
				if (pTmp)
				{
					//Adjust size
					rNewDataSize=dwDataSize+sInject.size();

					//Build new data
					*ppNewData=new char[dwDataSize+sInject.size()];

					//The cutoff location
					DWORD dwLoc=pTmp-pData;

					//Copy the data
					memcpy(*ppNewData,
						   pData,
						   dwLoc);

					memcpy(*ppNewData+dwLoc,
						   sInject.c_str(),
						   sInject.size());

					memcpy(*ppNewData+dwLoc+sInject.size(),
						   pData+dwLoc,
						   dwDataSize-dwLoc);

					//Tell SDK to modify
					return dhrModifyBodySDKAdjustHeader;
				}
			}
		}
	}

	//Done
	return dhrDontDoParental;
}

//This method is called when the connection was closed
//This is time to delete the context data
void _stdcall ConnectionClosed(bool bError,
							   ContextDWORD dwContext)
{
	//Did we had a context?
	if (dwContext)
	{
		//Take it
		ContextData* pData;
		pData=(ContextData*)dwContext;

		//Delete it
		delete pData;
	}
}

//This function is used to deallocate data allocated in this DLL
//Because the deallocator inside the service might not match the one inside the DLL
void _stdcall Deallocate(char* pData)
{
	delete [] pData;
}