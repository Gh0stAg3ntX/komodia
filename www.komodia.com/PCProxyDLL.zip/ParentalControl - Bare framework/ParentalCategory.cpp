// ParentalCategory.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include "CategoryDLLDefs.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

bool _stdcall DLLInitialize()
{
	return true;
}

void _stdcall DLLUninitialize()
{
}

//Will return the size if buffer is too small
int _stdcall DLLGetCategories(DLLLanguageID aLanguage,
							  char* pBuffer,
							  DWORD dwSize)
{
	return 0;
}

//Request a category
CategoryResponse _stdcall DLLGetSiteCategory(const char* pSite,
											 char* pCategories,
											 DWORD dwCategoriesSize)
{
	return crGotAnswer;
}