// PCProxyDLL.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include <string>
#include <map>

#include "PCProxyDefs.h"
#include "HTTPCommon.h"
#include "HTTPHelper.h"
#include "HTTPHeader.h"

std::string ConvertToLower(const std::string& rString)
{
	if (!rString.empty())
	{
		//Clone the string
		char* pTmp;
		pTmp=new char[rString.size()+1];
		memcpy(pTmp,
			   rString.c_str(),
			   rString.size()+1);

		//Convert
		strlwr((LPSTR)pTmp);

		//Our string
		std::string sTmp((LPSTR)pTmp);

		//Delete our old data
		delete [] pTmp;

		//Done
		return sTmp;
	}
	else
		return rString;
}

std::string BuildNewSafeRequest(const char* pRequest,
								DWORD dwSize)
{
	//First build the string
	std::string sTmp;
	for (DWORD dwCount=0;
		 dwCount<dwSize;
		 ++dwCount)
		sTmp+=pRequest[dwCount];

	//Now search if we have safe search
	if (stristr(sTmp.c_str(),
				"safe=strict") ||
		!stristr(sTmp.c_str(),
				 "&"))
		//Will not replace
		return "";

	//Ok we can add the request
	std::string sNewRequest;
	size_t iPos=0;
	while (sTmp[iPos]!=' ' &&
		   iPos<=dwSize)
	{
		//Copy it
		sNewRequest+=sTmp[iPos];
		++iPos;
	}

	while (sTmp[iPos]==' ' &&
		   iPos<=dwSize)
	{
		//Copy it
		sNewRequest+=sTmp[iPos];
		++iPos;
	}

	while (sTmp[iPos]!=' ' &&
		   iPos<=dwSize)
	{
		//Copy it
		sNewRequest+=sTmp[iPos];
		++iPos;
	}

	//Now add the safe request
	sNewRequest+="&safe=strict";

	//Add the rest of the request
	while (iPos<=dwSize)
	{
		//Copy it
		sNewRequest+=sTmp[iPos];
		++iPos;
	}

	//Done
	return sNewRequest;
}

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

//Vector of out request
typedef std::vector<char> RequestData;

//The structure that holds our data (this is the struct you change to hold your session specific data)
typedef struct _ContextData
{
	bool		bNewRequest;
	std::string sHost;
	bool		bHTTP;
	RequestData	aData;
	bool		bSSL;
	bool		bPost;
	bool		bPostParsed;
	bool		bFirstAnalyze;
	bool		bWasHTTP;
} ContextData;

//This function is called after DLL is loaded
//All initialization of user specific data should be done here
//And not inside DLLMain
//Return value: True - Continue to process this DLL
bool _stdcall PCInitialize()
{
	return true;
}

//This function is called before the DLL is unloaded
//All uninitializations should be done here
void _stdcall PCUninitialize()
{
}

//This function is used to communicate with the DLL
char* _stdcall DLLQueryData(const char* pData)
{
	//Nothing
	return NULL;
}

//This method is called when a new connection is made
//Read documentation for parameters explanation
bool _stdcall NewConnection(ContextDWORD& rContext,
							bool bFromEncryption,
							unsigned long usListeningPort,
							unsigned long& rIP,
							unsigned short& rPort,
							const ProcessInformation& pPInformation,
							bool& rEnableSSL,
							bool& rSSLSwitch,
							bool& bFreezeReceive,
							const char* pPeekData,
							unsigned long ulPeekDataSize,
							unsigned long& rWaitMoreData,
							ProxyInformation& rProxyInformation,
							const char* pDNSEntry)
{
	//The context
	ContextData* pData=(ContextData*)rContext;

	//Are we new
	bool bNew=false;

	if (!rContext)
	{
		//Create it
		pData=new ContextData;

		//Set new
		bNew=true;
	}
	else
	{
		//Check if it's SDK context
		if (pData->dwReserved)
		{
			//This is SDK context, can be a string or structure, shouldn't modify it
			//Code to manipulate the special context goes here
			
			//At this stage we can create our context
			pData=new ContextData;

			//Set new
			bNew=true;
		}		
	}

	//Do we save the context?
	if (bNew)
	{
		//Save the context
		rContext=(ContextDWORD)pData;

		//Reset the data
		pData->bNewRequest=false;
		pData->bHTTP=false;
		pData->bSSL=bFromEncryption;
		pData->bPost=false;
		pData->bFirstAnalyze=true;
		pData->bPostParsed=false;
		pData->bWasHTTP=false;
	}

	//Accept the connection
	return true;
}

//This method is called incase there's a connection to a proxy using HTTP connect
//Here there's an option to modify the connect string
//Input and output are strings so they must end with \0
bool _stdcall HandleProxyHTTPConnect(const char* pConnectString,
									 char** ppNewString,
									 ContextDWORD dwContext)
{
	//Don't modify
	return false;
}

//This method is called before data is sent back to the application
//Read documentation for parameters explanation
bool _stdcall DataBeforeReceive(const char* pData,
								DWORD dwDataSize,
								char** pNewBuffer,
								DWORD& rNewDataSize,
								bool& rTerminateSession,
								bool& rThawReceiveFreeze,
								bool& rEnableSSL,
								bool bServerClosed,
								ContextDWORD dwContext)
{
	//Take the context
	ContextData* pContext;
	pContext=(ContextData*)dwContext;

	//When we arrive here
	//Incase of HTTP, we know that the next time DataBeforeSend will be invoked
	//It means it's a new request, so set accordingly
	if (pContext &&
		pContext->bWasHTTP)
	{
		pContext->bNewRequest=true;
		pContext->bPost=false;
		pContext->bPostParsed=false;
		pContext->aData.clear();
		pContext->bFirstAnalyze=true;
		pContext->bHTTP=false;
	}

	return false;
}

//This method is called before data is sent to to the application
//Read documentation for parameters explanation
//Return value: false - Data wasn't changed, true - data was changed
bool _stdcall DataBeforeSend(const char* pData,
							 DWORD dwDataSize,
							 char** pNewBuffer, 
							 DWORD& rNewDataSize,
							 bool& rTerminateSession,
							 bool& rNewBufferToReceive,
							 OutgoingDataManipulations& rManipulations,
							 ContextDWORD dwContext)
{
	//Do we have a context?
	ContextData* pContext;
	pContext=(ContextData*)dwContext;

	//The request can fragment and we don't want to be here per fragment, but per request
	pContext->bNewRequest=false;

	//Should we check if it's http?
	if (pContext->bFirstAnalyze)
	{
		//Reset it
		pContext->bFirstAnalyze=false;

		//Check the size
		if (pData &&
			dwDataSize>10)
			if (!strnicmp(pData,
						  "get",
						  3) ||
				!strnicmp(pData,
						  "post",
						  4) ||
				!strnicmp(pData,
						  "head",
						  4))
			{
				//Is it post?
				if (!strnicmp(pData,
							  "post",
							  4))
					//Set it for post
					pContext->bPost=true;
				else
					pContext->bPost=false;

				//Set as HTTP
				pContext->bHTTP=true;
				pContext->bWasHTTP=true;
			}
	}

	if (pContext->bHTTP)
	{
		//Is it post?
		if (pContext->bPost)
			if (!pContext->bPostParsed)
			{
				//Put the data in the vector
				for (DWORD dwCount=0;
					 dwCount<dwDataSize;
					 ++dwCount)
					pContext->aData.push_back(pData[dwCount]);

				//Check post header here
				CHTTPHeader aHeader;
				if (aHeader.Feed(&(pContext->aData[0]),
								 pContext->aData.size()))
				{
					//Set we are parsed
					pContext->bPostParsed=true;

					//At this point the original data can be either at pData
					//or at pContext->aData, if bFed is true then use pContext->aData
					//Get information about the session
					std::string sHost;
					sHost=aHeader.GetHost();

					//Get the resource
					std::string sResource;
					sResource=aHeader.GetFullAddress();

					//Should we send a redirect?
					if (stristr(sHost.c_str(),
								"cnn.com") ||
						stristr(sHost.c_str(),
								"amazon.com"))
					{
						//Build a redirect
						std::string sRedirect;
						
						//Is it a SSL redirect?
						if (!pContext->bSSL)
							sRedirect=BuildRedirectReply("http://www.google.com",true,true);
						else
							sRedirect=BuildRedirectReply("https://gmail.google.com",true,true);

						//Send it back to the user
						*pNewBuffer=new char[sRedirect.size()];
						memcpy(*pNewBuffer,
							   sRedirect.c_str(),
							   sRedirect.size());
						rNewDataSize=sRedirect.size();
						rNewBufferToReceive=true;
						rTerminateSession=true;

						//Done
						return true;
					}
				}
			}
			else
				;
		else
		{
			//Our HTTP header
			//Get the information about the request
			CHTTPHeader aHeader;

			//Are we fed?
			bool bFed=false;

			//Do we have previous data?
			if (pContext &&
				!pContext->aData.empty())
				//Feed it
				bFed=aHeader.Feed(&(pContext->aData[0]),
								  pContext->aData.size());

			//This code adds HTTP manipulations
			//This code also make sure to set the filter once per request, because a request can come in many times
			//Because it is fragmented
			//Is this HTTP?
			if (bFed ||
				(pContext && //This checks that we are inside a new request, and not inside an existing request
				 pContext->aData.empty() && 
				 aHeader.Feed(pData,
							  dwDataSize)))
			{
				//At this point the original data can be either at pData
				//or at pContext->aData, if bFed is true then use pContext->aData
				//Get information about the session
				std::string sHost;
				sHost=aHeader.GetHost();

				//Get the resource
				std::string sResource;
				sResource=aHeader.GetFullAddress();

				//Should we send a redirect?
				if (stristr(sHost.c_str(),
							"cnn.com") ||
					stristr(sHost.c_str(),
							"amazon.com"))
				{
					//Build a redirect
					std::string sRedirect;
					
					//Is it a SSL redirect?
					if (!pContext->bSSL)
						sRedirect=BuildRedirectReply("http://www.google.com",true,true);
					else
						sRedirect=BuildRedirectReply("https://gmail.google.com",true,true);

					//Send it back to the user
					*pNewBuffer=new char[sRedirect.size()];
					memcpy(*pNewBuffer,
						   sRedirect.c_str(),
						   sRedirect.size());
					rNewDataSize=sRedirect.size();
					rNewBufferToReceive=true;
					rTerminateSession=true;

					//Done
					return true;
				}
			
				//Lets say we want to modify the outgoing request and not redirect it (this is another feature
				//which is not related to the redirect code)
				if (stristr(sHost.c_str(),
							"google.com"))
				{
					//Lets add a safe strict option
					std::string sNewRequest;

					//Which params are we parsing?
					if (bFed)
						sNewRequest=BuildNewSafeRequest(&(pContext->aData[0]),
														pContext->aData.size());
					else
						sNewRequest=BuildNewSafeRequest(pData,
														dwDataSize);

					//Did we get a request
					if (!sNewRequest.empty())
					{
						//Replace it
						//Send it back to the user
						*pNewBuffer=new char[sNewRequest.size()];
						memcpy(*pNewBuffer,
							   sNewRequest.c_str(),
							   sNewRequest.size());
						rNewDataSize=sNewRequest.size();
						
						//Done
						return true;
					}
				}

				//Check if we need to release the data queued (if we queued it)
				if (bFed)
				{
					//Copy the data
					*pNewBuffer=new char[pContext->aData.size()];
					memcpy(*pNewBuffer,
						   &(pContext->aData[0]),
						   pContext->aData.size());
					rNewDataSize=pContext->aData.size();

					//Set we have a change
					return true;
				}
				else
					//Done
					return false;
			}
			else if (pContext)
			{
				//Add the data
				for (DWORD dwCount=0;
					 dwCount<dwDataSize;
					 ++dwCount)
					pContext->aData.push_back(pData[dwCount]);

				//And don't send out the data
				*pNewBuffer=new char[0];
				rNewDataSize=0;

				//Set we have a data change
				return true;
			}
		}
	}

	//Done
	return false;
}

//This method is called when the connection was closed
//This is time to delete the context data
void _stdcall ConnectionClosed(bool bError,
							   ContextDWORD dwContext)
{
	//Did we had a context?
	if (dwContext)
	{
		//Take it
		ContextData* pData;
		pData=(ContextData*)dwContext;

		//Delete it
		delete pData;
	}
}

//This function is used to deallocate data allocated in this DLL
//Because the deallocator inside the service might not match the one inside the DLL
void _stdcall Deallocate(char* pData)
{
	delete [] pData;
}