using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
namespace ModifyTraffic
{

	public class ParentalImp : PCProxyLib.IParentalControl
	{


		private MainForm TheForm;
		public void SetForm(MainForm _TheForm)
		{
			TheForm = _TheForm;
		}

		public void ConnectionClosed(int lConnectionID, int lError, string bStringToStore)
		{
			string sMessage = null;
			sMessage = "Connection ID: " + lConnectionID + " closed";

			TheForm.AddItem(ref sMessage);
		}

		public PCProxyLib._DataActionType DataBeforeReceive(int lConnectionID, ref PCProxyLib.DataContainer pData, ref int lTerminateSession, int lServerClosed, ref string bStringToStore)
		{
			string sMessage = null;

			if (lServerClosed == 0) {
				//Build the connection string
				sMessage = "Connection ID: " + lConnectionID + " received " + pData.GetSize() + " bytes, showing first 128 bytes: ";

				//Build the data
				int iSize = 0;
				if ((pData.GetSize() < 128)) {
					iSize = pData.GetSize();
				} else {
					iSize = 128;
				}

				int iCount = 0;

				//Get the string to a tmp one becaues every call goes to the main process
				string bTmpString = null;
				bTmpString = pData.RequestString(0, iSize);

				for (iCount = 0; iCount < iSize; iCount++) {
                    if (bTmpString[iCount] != 7)
                    {
                        sMessage = sMessage + bTmpString[iCount];
					}
				}
			} else {
				//Build the connection string
				sMessage = "Connection ID: " + lConnectionID + " server close";
			}

			TheForm.AddItem(ref sMessage);

			return PCProxyLib._DataActionType.naAllowData;
		}

		public PCProxyLib._DataActionType DataBeforeSend(int lConnectionID, ref PCProxyLib.DataContainer pData, ref int lTerminateSession, ref int lNewBufferToReceive, ref string bStringToStore)
		{
			//Build the connection string
			string sMessage = null;
			sMessage = "Connection ID: " + " sent " + pData.GetSize() + " bytes, showing first 128 bytes: ";

			//Build the data
			int iSize = 0;
			if ((pData.GetSize() < 128)) {
				iSize = pData.GetSize();
			} else {
				iSize = 128;
			}

			int iCount = 0;

			//Get the string to a tmp one becuase every call goes to the main process
			string bTmpString = null;
			bTmpString = pData.RequestString(0, iSize);

			for (iCount = 1; iCount <= iSize; iCount++) {
                if (bTmpString[iCount] != 7)
                {
                    sMessage = sMessage + bTmpString[iCount];
				}
			}

			TheForm.AddItem(ref sMessage);

			return PCProxyLib._DataActionType.naAllowData;
		}

		public int NewConnection(int lConnectionID, int lFromEncryption, int lPID, string bProcessName, string bUsername, string bDomain, string bIPString, ref int lIP, ref int lPort, ref int lSSL,
		ref int lProxyModified, ref PCProxyLib._IProxyType lProxyType, ref int lProxyIP, ref int lProxyPort, ref string pUsername, ref string pPassword, string bDNSEntry, ref PCProxyLib._FilteringType pFilteringType, ref string bStringToStore)
		{
			int functionReturnValue = 0;
			bStringToStore = "barak";

			//Build the connection string
			string sMessage = null;
			if (lFromEncryption == 1) {
				sMessage = "New SSL connection ID: ";
			} else {
				sMessage = "New connection ID: ";
			}

			sMessage = sMessage + lConnectionID + " to: " + bIPString + ":" + lPort;

			TheForm.AddItem(ref sMessage);
			functionReturnValue = 1;

			//This same needs the parental

			//Which filtering
			if (TheForm.MonitorRadio.Checked == true) {
				pFilteringType = PCProxyLib._FilteringType.ftDataOnly;
			} else {
				pFilteringType = PCProxyLib._FilteringType.ftParentalOnly;
			}
			return functionReturnValue;
		}

		public PCProxyLib._ActionType NewReply(int lConnectionID, string bRequestHeader, string bFullRequestURL, string bReplyHeader, string bContentType, int lReplyOnly, ref PCProxyLib.DataContainer pReplyHeader, ref PCProxyLib.DataContainer pReplyBody, ref string bRedirectTo, ref string bStringToStore)
		{
			PCProxyLib._ActionType functionReturnValue = default(PCProxyLib._ActionType);
			//Skip tells Redirector to do default processing (will build html but not other files)
			//We may change it ahead
			functionReturnValue = PCProxyLib._ActionType.atSkip;

			//Build the connection string
			string sMessage = null;
			sMessage = "Connection ID: " + lConnectionID + " new reply for url: " + bFullRequestURL + " with header: " + bReplyHeader;

			TheForm.AddItem(ref sMessage);

			//Can only search text
			if (bContentType.IndexOf("text") > 0) {
				//Get the string
				string sData = null;
				sData = pReplyBody.RequestString(0, pReplyBody.GetSize());

				//Search it
				if (sData.IndexOf(TheForm.KeywordText.Text) > 0) {
					//Need to redirect it
					//We can query the redirector to get data about a connection
					PCProxyLib.DataController dt = default(PCProxyLib.DataController);
					dt = TheForm.GetController();

					//All the info we can get
					int lPID;
					string bApplication;
					string bUsername;
					string bDomain;
					int lIP;
					string bStringIP;
					int lPort;
					int lSSL;

				    dt.GetConnectionInfo(lConnectionID, out lPID, out bApplication,
				        out bUsername, out bDomain, out lIP, out bStringIP, out lPort,
				        out lSSL);

					//Which prefix
					string sPrefix = null;
					if (lSSL != 0) {
						sPrefix = "https://";
					} else {
						sPrefix = "http://";
					}

					//Check if we need to add HTTP?
					if (Strings.Left(TheForm.RedirectTo.Text, sPrefix.Length) != sPrefix) {
						bRedirectTo = sPrefix + TheForm.RedirectTo.Text;
					} else {
						bRedirectTo = TheForm.RedirectTo.Text;
					}

					functionReturnValue = PCProxyLib._ActionType.atRedirect;

					sMessage = "Connection ID: " + lConnectionID + " reply redirected: " + bRequestHeader;

					TheForm.AddItem(ref sMessage);
				}
			}
			return functionReturnValue;
		}

		public PCProxyLib._ActionType NewRequest(int lConnectionID, ref PCProxyLib.DataContainer pHeader, string bHeaderNoPost, string bHost, string bURL, string bFullRequest, int lPartialPost, ref string bRedirectTo, ref string bStringToStore)
		{
			PCProxyLib._ActionType functionReturnValue = default(PCProxyLib._ActionType);
			//Skip tells Redirector to do default processing (will build html but not other files)
			//We may change it ahead
			functionReturnValue = PCProxyLib._ActionType.atSkip;

			//Build the connection string
			string sMessage = null;
			sMessage = "Connection ID: " + lConnectionID + " new request : " + bFullRequest;

			TheForm.AddItem(ref sMessage);

			//Check the request
			//Which string to inspect
			string sData = null;
			if (TheForm.HTTPRadio.Checked) {
				sData = bHeaderNoPost;
			} else {
				sData = bFullRequest;
			}

			if ((sData.IndexOf(TheForm.KeywordText.Text) > 0)) {
				//Need to redirect it
				//We can query the redirector to get data about a connection
				PCProxyLib.DataController dt = default(PCProxyLib.DataController);
				dt = TheForm.GetController();

				//All the info we can get
                int lPID;
                string bApplication;
                string bUsername;
                string bDomain;
                int lIP;
                string bStringIP;
                int lPort;
                int lSSL;

                dt.GetConnectionInfo(lConnectionID, out lPID, out bApplication,
                    out bUsername, out bDomain, out lIP, out bStringIP, out lPort,
                    out lSSL);

				//Which prefix
				string sPrefix = null;
				if (lSSL != 0) {
					sPrefix = "https://";
				} else {
					sPrefix = "http://";
				}

				//Check if we need to add HTTP?
				if (Strings.Left(TheForm.RedirectTo.Text, sPrefix.Length) != sPrefix) {
					bRedirectTo = sPrefix + TheForm.RedirectTo.Text;
				} else {
					bRedirectTo = TheForm.RedirectTo.Text;
				}

				functionReturnValue = PCProxyLib._ActionType.atRedirect;

				sMessage = "Connection ID: " + lConnectionID + " request redirected: " + bFullRequest;

				TheForm.AddItem(ref sMessage);
			}
			return functionReturnValue;
		}
	}
}
