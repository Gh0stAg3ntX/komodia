using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
namespace ModifyTraffic
{
	[Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
	partial class MainForm : System.Windows.Forms.Form
	{

		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]
		protected override void Dispose(bool disposing)
		{
			try {
				if (disposing && components != null) {
					components.Dispose();
				}
			} finally {
				base.Dispose(disposing);
			}
		}

		//Required by the Windows Form Designer

		private System.ComponentModel.IContainer components;
		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.ScenarioBox = new System.Windows.Forms.GroupBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.MonitorRadio = new System.Windows.Forms.RadioButton();
            this.Label9 = new System.Windows.Forms.Label();
            this.TestRadio = new System.Windows.Forms.RadioButton();
            this.Label8 = new System.Windows.Forms.Label();
            this.URLRRadio = new System.Windows.Forms.RadioButton();
            this.Label7 = new System.Windows.Forms.Label();
            this.SSLRadio = new System.Windows.Forms.RadioButton();
            this.Label1 = new System.Windows.Forms.Label();
            this.ContentInspectionRadio = new System.Windows.Forms.RadioButton();
            this.RulesGroup = new System.Windows.Forms.GroupBox();
            this.DisPanel = new System.Windows.Forms.Panel();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.URLRadio = new System.Windows.Forms.RadioButton();
            this.HTTPRadio = new System.Windows.Forms.RadioButton();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.BrowsersRadio = new System.Windows.Forms.RadioButton();
            this.RedirectTo = new System.Windows.Forms.TextBox();
            this.TrafficAllRadio = new System.Windows.Forms.RadioButton();
            this.Label11 = new System.Windows.Forms.Label();
            this.KeywordText = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.Button3 = new System.Windows.Forms.Button();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.MainList = new System.Windows.Forms.ListBox();
            this.PollTimer = new System.Windows.Forms.Timer(this.components);
            this.ScenarioBox.SuspendLayout();
            this.RulesGroup.SuspendLayout();
            this.DisPanel.SuspendLayout();
            this.Panel2.SuspendLayout();
            this.GroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // ScenarioBox
            // 
            this.ScenarioBox.Controls.Add(this.Label13);
            this.ScenarioBox.Controls.Add(this.MonitorRadio);
            this.ScenarioBox.Controls.Add(this.Label9);
            this.ScenarioBox.Controls.Add(this.TestRadio);
            this.ScenarioBox.Controls.Add(this.Label8);
            this.ScenarioBox.Controls.Add(this.URLRRadio);
            this.ScenarioBox.Controls.Add(this.Label7);
            this.ScenarioBox.Controls.Add(this.SSLRadio);
            this.ScenarioBox.Controls.Add(this.Label1);
            this.ScenarioBox.Controls.Add(this.ContentInspectionRadio);
            this.ScenarioBox.Location = new System.Drawing.Point(16, 19);
            this.ScenarioBox.Name = "ScenarioBox";
            this.ScenarioBox.Size = new System.Drawing.Size(492, 196);
            this.ScenarioBox.TabIndex = 18;
            this.ScenarioBox.TabStop = false;
            this.ScenarioBox.Text = "Scenarios";
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Label13.Location = new System.Drawing.Point(149, 124);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(116, 14);
            this.Label13.TabIndex = 9;
            this.Label13.Text = "View HTTP traffic only";
            // 
            // MonitorRadio
            // 
            this.MonitorRadio.AutoSize = true;
            this.MonitorRadio.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.MonitorRadio.Location = new System.Drawing.Point(15, 118);
            this.MonitorRadio.Name = "MonitorRadio";
            this.MonitorRadio.Size = new System.Drawing.Size(138, 23);
            this.MonitorRadio.TabIndex = 6;
            this.MonitorRadio.Text = "Monitor traffic:";
            this.MonitorRadio.UseVisualStyleBackColor = true;
            this.MonitorRadio.CheckedChanged += new System.EventHandler(this.MonitorRadio_CheckedChanged);
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Label9.Location = new System.Drawing.Point(163, 168);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(131, 14);
            this.Label9.TabIndex = 7;
            this.Label9.Text = "Set the rules as you wish";
            // 
            // TestRadio
            // 
            this.TestRadio.AutoSize = true;
            this.TestRadio.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.TestRadio.Location = new System.Drawing.Point(15, 162);
            this.TestRadio.Name = "TestRadio";
            this.TestRadio.Size = new System.Drawing.Size(145, 23);
            this.TestRadio.TabIndex = 8;
            this.TestRadio.Text = "Test it yourself:";
            this.TestRadio.UseVisualStyleBackColor = true;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Label8.Location = new System.Drawing.Point(163, 81);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(287, 14);
            this.Label8.TabIndex = 5;
            this.Label8.Text = "Site prevention ame Send all visitors at *CNN* to FoxNews";
            // 
            // URLRRadio
            // 
            this.URLRRadio.AutoSize = true;
            this.URLRRadio.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.URLRRadio.Location = new System.Drawing.Point(15, 75);
            this.URLRRadio.Name = "URLRRadio";
            this.URLRRadio.Size = new System.Drawing.Size(151, 23);
            this.URLRRadio.TabIndex = 4;
            this.URLRRadio.Text = "URL Redirector:";
            this.URLRRadio.UseVisualStyleBackColor = true;
            this.URLRRadio.CheckedChanged += new System.EventHandler(this.URLRRadio_CheckedChanged);
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Label7.Location = new System.Drawing.Point(136, 54);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(294, 14);
            this.Label7.TabIndex = 3;
            this.Label7.Text = "Find Confidential inside encrypted SSL stream and intercept";
            // 
            // SSLRadio
            // 
            this.SSLRadio.AutoSize = true;
            this.SSLRadio.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.SSLRadio.Location = new System.Drawing.Point(15, 48);
            this.SSLRadio.Name = "SSLRadio";
            this.SSLRadio.Size = new System.Drawing.Size(125, 23);
            this.SSLRadio.TabIndex = 2;
            this.SSLRadio.Text = "Inspect SSL:";
            this.SSLRadio.UseVisualStyleBackColor = true;
            this.SSLRadio.CheckedChanged += new System.EventHandler(this.SSLRadio_CheckedChanged);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Label1.Location = new System.Drawing.Point(188, 28);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(281, 14);
            this.Label1.TabIndex = 1;
            this.Label1.Text = "Prevent access to any content that has the word PORN  ";
            // 
            // ContentInspectionRadio
            // 
            this.ContentInspectionRadio.AutoSize = true;
            this.ContentInspectionRadio.Checked = true;
            this.ContentInspectionRadio.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ContentInspectionRadio.Location = new System.Drawing.Point(15, 22);
            this.ContentInspectionRadio.Name = "ContentInspectionRadio";
            this.ContentInspectionRadio.Size = new System.Drawing.Size(182, 23);
            this.ContentInspectionRadio.TabIndex = 0;
            this.ContentInspectionRadio.TabStop = true;
            this.ContentInspectionRadio.Text = "Content Inspection: ";
            this.ContentInspectionRadio.UseVisualStyleBackColor = true;
            this.ContentInspectionRadio.CheckedChanged += new System.EventHandler(this.ContentInspectionRadio_CheckedChanged);
            // 
            // RulesGroup
            // 
            this.RulesGroup.Controls.Add(this.DisPanel);
            this.RulesGroup.Controls.Add(this.Button3);
            this.RulesGroup.Location = new System.Drawing.Point(18, 221);
            this.RulesGroup.Name = "RulesGroup";
            this.RulesGroup.Size = new System.Drawing.Size(490, 151);
            this.RulesGroup.TabIndex = 19;
            this.RulesGroup.TabStop = false;
            this.RulesGroup.Text = "Rules";
            // 
            // DisPanel
            // 
            this.DisPanel.Controls.Add(this.Panel2);
            this.DisPanel.Controls.Add(this.Label14);
            this.DisPanel.Controls.Add(this.Label12);
            this.DisPanel.Controls.Add(this.BrowsersRadio);
            this.DisPanel.Controls.Add(this.RedirectTo);
            this.DisPanel.Controls.Add(this.TrafficAllRadio);
            this.DisPanel.Controls.Add(this.Label11);
            this.DisPanel.Controls.Add(this.KeywordText);
            this.DisPanel.Controls.Add(this.Label10);
            this.DisPanel.Location = new System.Drawing.Point(4, 19);
            this.DisPanel.Name = "DisPanel";
            this.DisPanel.Size = new System.Drawing.Size(364, 123);
            this.DisPanel.TabIndex = 21;
            // 
            // Panel2
            // 
            this.Panel2.Controls.Add(this.URLRadio);
            this.Panel2.Controls.Add(this.HTTPRadio);
            this.Panel2.Location = new System.Drawing.Point(71, 45);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(186, 27);
            this.Panel2.TabIndex = 30;
            // 
            // URLRadio
            // 
            this.URLRadio.AutoSize = true;
            this.URLRadio.Location = new System.Drawing.Point(102, 7);
            this.URLRadio.Name = "URLRadio";
            this.URLRadio.Size = new System.Drawing.Size(69, 17);
            this.URLRadio.TabIndex = 21;
            this.URLRadio.Text = "URL only";
            this.URLRadio.UseVisualStyleBackColor = true;
            // 
            // HTTPRadio
            // 
            this.HTTPRadio.AutoSize = true;
            this.HTTPRadio.Checked = true;
            this.HTTPRadio.Location = new System.Drawing.Point(3, 7);
            this.HTTPRadio.Name = "HTTPRadio";
            this.HTTPRadio.Size = new System.Drawing.Size(93, 17);
            this.HTTPRadio.TabIndex = 20;
            this.HTTPRadio.TabStop = true;
            this.HTTPRadio.Text = "HTTP streams";
            this.HTTPRadio.UseVisualStyleBackColor = true;
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(7, 84);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(62, 13);
            this.Label14.TabIndex = 29;
            this.Label14.Text = "Redirect to:";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Location = new System.Drawing.Point(7, 56);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(20, 13);
            this.Label12.TabIndex = 28;
            this.Label12.Text = "At:";
            // 
            // BrowsersRadio
            // 
            this.BrowsersRadio.AutoSize = true;
            this.BrowsersRadio.Checked = true;
            this.BrowsersRadio.Location = new System.Drawing.Point(74, 29);
            this.BrowsersRadio.Name = "BrowsersRadio";
            this.BrowsersRadio.Size = new System.Drawing.Size(90, 17);
            this.BrowsersRadio.TabIndex = 27;
            this.BrowsersRadio.TabStop = true;
            this.BrowsersRadio.Text = "Browsers only";
            this.BrowsersRadio.UseVisualStyleBackColor = true;
            // 
            // RedirectTo
            // 
            this.RedirectTo.Location = new System.Drawing.Point(75, 77);
            this.RedirectTo.Name = "RedirectTo";
            this.RedirectTo.Size = new System.Drawing.Size(166, 20);
            this.RedirectTo.TabIndex = 23;
            this.RedirectTo.Text = "www.disney.com";
            // 
            // TrafficAllRadio
            // 
            this.TrafficAllRadio.AutoSize = true;
            this.TrafficAllRadio.Location = new System.Drawing.Point(173, 29);
            this.TrafficAllRadio.Name = "TrafficAllRadio";
            this.TrafficAllRadio.Size = new System.Drawing.Size(184, 17);
            this.TrafficAllRadio.TabIndex = 26;
            this.TrafficAllRadio.Text = "All traffic (all network applications)";
            this.TrafficAllRadio.UseVisualStyleBackColor = true;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Location = new System.Drawing.Point(7, 33);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(46, 13);
            this.Label11.TabIndex = 25;
            this.Label11.Text = "Used in:";
            // 
            // KeywordText
            // 
            this.KeywordText.Location = new System.Drawing.Point(75, 3);
            this.KeywordText.Name = "KeywordText";
            this.KeywordText.Size = new System.Drawing.Size(164, 20);
            this.KeywordText.TabIndex = 24;
            this.KeywordText.Text = "porn";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(7, 10);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(30, 13);
            this.Label10.TabIndex = 22;
            this.Label10.Text = "Find:";
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(395, 116);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(88, 27);
            this.Button3.TabIndex = 20;
            this.Button3.Text = "Run test";
            this.Button3.UseVisualStyleBackColor = true;
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.MainList);
            this.GroupBox3.Location = new System.Drawing.Point(18, 378);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(490, 188);
            this.GroupBox3.TabIndex = 21;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Under The Hood";
            // 
            // MainList
            // 
            this.MainList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.MainList.FormattingEnabled = true;
            this.MainList.HorizontalScrollbar = true;
            this.MainList.Location = new System.Drawing.Point(6, 19);
            this.MainList.Name = "MainList";
            this.MainList.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.MainList.Size = new System.Drawing.Size(478, 156);
            this.MainList.TabIndex = 4;
            // 
            // PollTimer
            // 
            this.PollTimer.Interval = 1000;
            this.PollTimer.Tick += new System.EventHandler(this.PollTimer_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(523, 578);
            this.Controls.Add(this.GroupBox3);
            this.Controls.Add(this.RulesGroup);
            this.Controls.Add(this.ScenarioBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Komodia\'s Redirector Showcase for C#";
            this.ScenarioBox.ResumeLayout(false);
            this.ScenarioBox.PerformLayout();
            this.RulesGroup.ResumeLayout(false);
            this.DisPanel.ResumeLayout(false);
            this.DisPanel.PerformLayout();
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            this.GroupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		internal System.Windows.Forms.GroupBox ScenarioBox;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.RadioButton ContentInspectionRadio;
		internal System.Windows.Forms.Label Label7;
	    internal System.Windows.Forms.RadioButton SSLRadio;
		internal System.Windows.Forms.Label Label8;
	    internal System.Windows.Forms.RadioButton URLRRadio;
		internal System.Windows.Forms.Label Label9;
		internal System.Windows.Forms.RadioButton TestRadio;
		internal System.Windows.Forms.GroupBox RulesGroup;
		internal System.Windows.Forms.Label Label13;
	    internal System.Windows.Forms.RadioButton MonitorRadio;
	    internal System.Windows.Forms.Button Button3;
		internal System.Windows.Forms.GroupBox GroupBox3;
		internal System.Windows.Forms.ListBox MainList;
		internal System.Windows.Forms.Panel DisPanel;
		internal System.Windows.Forms.Panel Panel2;
		internal System.Windows.Forms.RadioButton URLRadio;
		internal System.Windows.Forms.RadioButton HTTPRadio;
		internal System.Windows.Forms.Label Label14;
		internal System.Windows.Forms.Label Label12;
		internal System.Windows.Forms.RadioButton BrowsersRadio;
		internal System.Windows.Forms.TextBox RedirectTo;
		internal System.Windows.Forms.RadioButton TrafficAllRadio;
		internal System.Windows.Forms.Label Label11;
		internal System.Windows.Forms.TextBox KeywordText;
		internal System.Windows.Forms.Label Label10;
	    internal System.Windows.Forms.Timer PollTimer;
		public MainForm()
		{
			Disposed += MainForm_Disposed;
			InitializeComponent();
		}
	}
}
