using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
namespace ModifyTraffic
{
	public partial class MainForm
	{

		private ParentalImp ParentalClass;
		public delegate void addItemDelegate(string item);


		private bool bStop = false;

		private string sPollString;
		public PCProxyLib.DataController GetController()
		{
			return new PCProxyLib.DataController();
		}

		private void AddItemToList(string s)
		{
			MainList.Items.Add(s);
		}

		public void AddItem(ref string s)
		{
			if (MainList.InvokeRequired) {
				addItemDelegate del = new addItemDelegate(AddItemToList);
				MainList.Invoke(del, new object[] { s });
			} else {
				MainList.Items.Add(s);
			}
		}


		private void Button1_Click_1(System.Object sender, System.EventArgs e)
		{
		}

		private void Button2_Click(System.Object sender, System.EventArgs e)
		{
			PCProxyLib.DataController dt = GetController();

		}

		private void Button3_Click(System.Object sender, System.EventArgs e)
		{
			if (!bStop) {
				//Get the controller
				PCProxyLib.DataController dt = GetController();

				//Clear all the rules
				dt.Clear();

                //Check if we are WFP
                int bWFP;
                bWFP = dt.DoesSupportWFP();

				//Check the interception rules
				if (BrowsersRadio.Checked) {
					//Get the application table
					PCProxyLib.DataTable tb = dt.GetTable(PCProxyLib._Tables.dtApplication);

					tb.AddString("iexplore.exe");
					tb.AddString("firefox.exe");
					tb.AddString("chrome.exe");
					tb.AddString("safari.exe");
					tb.AddString("opera.exe");

					//Commit it
					tb.Commit();
				} else {
					//All traffic
					PCProxyLib.DataTable tb = dt.GetTable(PCProxyLib._Tables.dtFlags);

					//Will inverse the applications flag, this will get all applications
					tb.AddStringIdx("appinv", "1");

					//Commit it
					tb.Commit();
				}

                if (bWFP==1)
                    //Save the settings
                    dt.Save();
                else
				    //Propagate rules immediately
				    dt.BroadcastChange(2);
                

				//Now connect our filter
				ParentalClass = new ParentalImp();
				ParentalClass.SetForm(this);

				//The two boolean flags are important to understand
				//First one means you will only get new connections and not existing ones
				//Second one means that the SDK will remove your interface in case of an error
				dt.SetParentalInterface(ParentalClass, 1, 1);

				//Which mode are we?
				if (ContentInspectionRadio.Checked) {
					//Alert user
					Interaction.MsgBox("Will now open your browser and search for porn on google", MsgBoxStyle.OkOnly, "Content inspection");

					//Open the browser
					if (!BrowserExec.LaunchNewBrowser("http://www.google.com/search?q=porn")) {
						Interaction.MsgBox("Failed to open your default browser, please open it and browse to: http://www.google.com/search?q=porn", MsgBoxStyle.OkOnly, "Content inspection");
					}
				} else if (SSLRadio.Checked) {
					//Alert user
					Interaction.MsgBox("Will now open your browser and search for porn on google encrypted with SSL", MsgBoxStyle.OkOnly, "Inspect SSL");

					//Open the browser
					if (!BrowserExec.LaunchNewBrowser("https://encrypted.google.com/search?q=porn")) {
						Interaction.MsgBox("Failed to open your default browser, please open it and browse to: https://encrypted.google.com/search?q=porn", MsgBoxStyle.OkOnly, "Inspect SSL");
					}
				} else if (URLRRadio.Checked) {
					//Alert user
					Interaction.MsgBox("Will now open your browser and goto CNN.com", MsgBoxStyle.OkOnly, "URL Redirection");

					//Open the browser
					if (!BrowserExec.LaunchNewBrowser("http://www.cnn.com")) {
						Interaction.MsgBox("Failed to open your default browser, please open it and browse to: http://www.cnn.com", MsgBoxStyle.OkOnly, "URL Redirection");
					}
				} else if (MonitorRadio.Checked) {
					//Alert user
                    Interaction.MsgBox("Now all traffic is intercepted", MsgBoxStyle.OkOnly, "Monitor traffic");
				} else {
					//Alert the user
					Interaction.MsgBox("You can now play with the rules, make sure you open a browser or other network application", MsgBoxStyle.OkOnly, "Test it yourself");
				}
			} else {
				//Clear the rules
				//Get the controller
				PCProxyLib.DataController dt = GetController();

				//Clear all the rules
				dt.Clear();

                //Check if we are WFP
                int bWFP;
                bWFP = dt.DoesSupportWFP();

                if (bWFP == 1)
                    //Save the settings
                    dt.Save();
                else
                    //Propagate rules immediately
                    dt.BroadcastChange(2);

				//Remove the interface
				dt.SetParentalInterface(null, 1, 1);
				ParentalClass = null;
			}

			if (bStop) {
				//Stop the timer
				PollTimer.Enabled = false;

				//Reset the string
				sPollString = "";

				ScenarioBox.Enabled = true;
				Button3.Text = "Run test";

				if (!TestRadio.Checked) {
					DisPanel.Enabled = true;
				}
			} else {
				//Start the timer
				PollTimer.Enabled = true;

				ScenarioBox.Enabled = false;
				Button3.Text = "Stop test";

				if (!TestRadio.Checked) {
					DisPanel.Enabled = false;
				}
			}

			bStop = !bStop;
		}

		private void MonitorRadio_CheckedChanged(System.Object sender, System.EventArgs e)
		{
			if (MonitorRadio.Checked) {
				TrafficAllRadio.Checked = true;
			}

			DisPanel.Enabled = !MonitorRadio.Checked;
		}

		private void ContentInspectionRadio_CheckedChanged(System.Object sender, System.EventArgs e)
		{
			if (ContentInspectionRadio.Checked) {
				KeywordText.Text = "porn";
				BrowsersRadio.Checked = true;
				HTTPRadio.Checked = true;
				RedirectTo.Text = "www.disney.com";
			}
		}

		private void SSLRadio_CheckedChanged(System.Object sender, System.EventArgs e)
		{
			if (SSLRadio.Checked) {
				KeywordText.Text = "porn";
				BrowsersRadio.Checked = true;
				HTTPRadio.Checked = true;
				RedirectTo.Text = "www.wellsfargo.com";
			}
		}

		private void URLRRadio_CheckedChanged(System.Object sender, System.EventArgs e)
		{
			if (URLRRadio.Checked) {
				KeywordText.Text = "cnn";
				BrowsersRadio.Checked = true;
				URLRadio.Checked = true;
				RedirectTo.Text = "www.foxnews.com";
			}
		}

		private void PollTimer_Tick(System.Object sender, System.EventArgs e)
		{
			//With the com object
			PCProxyLib.DataController dt = new PCProxyLib.DataController();

			//Get the com string
			string sTmp = null;
			dt.GetInstaceID(ref sTmp);

			//Do we need to store it
			if (string.IsNullOrEmpty(sPollString)) {
				sPollString = sTmp;
			} else if (sPollString != sTmp) {
				//Save the new string
				sPollString = sTmp;

				//Create new interface (this will be relevant in retail product)
				dt = GetController();

				//Need to reregister ourselves
				//The two boolean flags are important to understand
				//First one means you will only get new connections and not existing ones
				//Second one means that the SDK will remove your interface in case of an error
				dt.SetParentalInterface(ParentalClass, 1, 1);
			}
		}

        private void MainForm_Disposed(object sender, EventArgs e)
        {
            if (bStop)
            {
                Button3_Click(sender, e);
            }
        }
	}
}
