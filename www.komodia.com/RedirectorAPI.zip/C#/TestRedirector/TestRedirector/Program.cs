﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PCProxyLib;

namespace TestRedirector
{
    class Program
    {
        static void Main(string[] args)
        {
            'This code sets the DLL
            PCProxyLib.DataController dt=new PCProxyLib.DataController();
            PCProxyLib.DataTable flags = dt.GetTable(_Tables.dtFlags);
            flags.AddStringIdx("dlltoload", "mydll");
            flags.Commit();
            dt.Save();
        }
    }
}
