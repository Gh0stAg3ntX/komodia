using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

//kleinma
//www.vbforums.com
//2005
//this code will launch a URL that is passed to the function
//and open a new browser window each time



namespace ModifyTraffic
{

	static class BrowserExec
	{
		[DllImport("shell32.dll", EntryPoint = "FindExecutableA", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]

        public static extern int FindExecutable(string lpFile, string lpDirectory, [Out] StringBuilder lpResult);

		public static bool LaunchNewBrowser(string strUrl)
		{
			bool functionReturnValue = false;

			try {
				//CREATE SOME VARIABLES
                StringBuilder BrowserExecBuffer = new StringBuilder(255);
				string FileName = null;
				long RetVal = 0;
				int FileNumber = 0;
				StreamWriter SWriter = null;
				//CREATE A TEMP HTM FILE SO WE CAN FIND OUT WHAT BROWSER IS
				//THE DEFAULT ONE ON THE SYSTEM
                FileName = Application.StartupPath + "\\temp.htm";
				SWriter = File.CreateText(FileName);
				SWriter.Write("<html></html>");
				SWriter.Close();
				//CALL THE API TO FIND THE EXE ASSOCIATED WITH HTM FILES
                RetVal = FindExecutable(FileName, string.Empty, BrowserExecBuffer);
                string BrowserExec = BrowserExecBuffer.ToString().Trim();
				//IF WE GET ONE, LAUNCH THE URL IN THE NEW INSTANCE OF THE BROWSER
				if (RetVal <= 32 || BrowserExec == string.Empty) {
					functionReturnValue = false;
				} else {
                    Process.Start(BrowserExec, strUrl);
				}
				//DELETE THAT PESKY TEMP FILE
				File.Delete(FileName);
				functionReturnValue = true;
			} catch (Exception ex) {
				//IF ANYTHING GOES WRONG, LET PEOPLE KNOW WHO'S FAULT IT IS
				functionReturnValue = false;
			}
			return functionReturnValue;

		}
	}
}
