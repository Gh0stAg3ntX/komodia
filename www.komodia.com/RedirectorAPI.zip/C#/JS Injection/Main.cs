using System;
using System.Windows.Forms;

namespace ModifyTraffic
{
	static class MyApplication
	{
		[STAThread]
		public static void Main(string[] args)
		{
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new MainForm());
		}
	}
}
