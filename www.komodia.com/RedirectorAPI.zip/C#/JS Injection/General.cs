using Microsoft.VisualBasic;
using System;

namespace ModifyTraffic
{
	static class General
	{
		public static byte[] FromBase64(string base64)
		{
			if (base64 == null)
				throw new ArgumentNullException("base64");
			return Convert.FromBase64String(base64);
		}
	}
}
