using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
namespace ModifyTraffic
{
	[Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
	partial class MainForm : System.Windows.Forms.Form
	{

		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]
		protected override void Dispose(bool disposing)
		{
			try {
				if (disposing && components != null) {
					components.Dispose();
				}
			} finally {
				base.Dispose(disposing);
			}
		}

		//Required by the Windows Form Designer

		private System.ComponentModel.IContainer components;
		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.RulesGroup = new System.Windows.Forms.GroupBox();
            this.DisPanel = new System.Windows.Forms.Panel();
            this.Label14 = new System.Windows.Forms.Label();
            this.InjectText = new System.Windows.Forms.TextBox();
            this.SiteText = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.Button3 = new System.Windows.Forms.Button();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.MainList = new System.Windows.Forms.ListBox();
            this.PollTimer = new System.Windows.Forms.Timer(this.components);
            this.RulesGroup.SuspendLayout();
            this.DisPanel.SuspendLayout();
            this.GroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // RulesGroup
            // 
            this.RulesGroup.Controls.Add(this.DisPanel);
            this.RulesGroup.Controls.Add(this.Button3);
            this.RulesGroup.Location = new System.Drawing.Point(12, 12);
            this.RulesGroup.Name = "RulesGroup";
            this.RulesGroup.Size = new System.Drawing.Size(490, 92);
            this.RulesGroup.TabIndex = 19;
            this.RulesGroup.TabStop = false;
            this.RulesGroup.Text = "Where to inject";
            // 
            // DisPanel
            // 
            this.DisPanel.Controls.Add(this.Label14);
            this.DisPanel.Controls.Add(this.InjectText);
            this.DisPanel.Controls.Add(this.SiteText);
            this.DisPanel.Controls.Add(this.Label10);
            this.DisPanel.Location = new System.Drawing.Point(4, 19);
            this.DisPanel.Name = "DisPanel";
            this.DisPanel.Size = new System.Drawing.Size(364, 62);
            this.DisPanel.TabIndex = 21;
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(7, 36);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(73, 13);
            this.Label14.TabIndex = 29;
            this.Label14.Text = "Data to inject:";
            // 
            // InjectText
            // 
            this.InjectText.Location = new System.Drawing.Point(97, 29);
            this.InjectText.Name = "InjectText";
            this.InjectText.Size = new System.Drawing.Size(166, 20);
            this.InjectText.TabIndex = 23;
            this.InjectText.Text = "Hello world";
            // 
            // SiteText
            // 
            this.SiteText.Location = new System.Drawing.Point(97, 3);
            this.SiteText.Name = "SiteText";
            this.SiteText.Size = new System.Drawing.Size(164, 20);
            this.SiteText.TabIndex = 24;
            this.SiteText.Text = "google.co";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(7, 10);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(68, 13);
            this.Label10.TabIndex = 22;
            this.Label10.Text = "Site to inject:";
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(396, 41);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(88, 27);
            this.Button3.TabIndex = 20;
            this.Button3.Text = "Run test";
            this.Button3.UseVisualStyleBackColor = true;
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.MainList);
            this.GroupBox3.Location = new System.Drawing.Point(16, 119);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(490, 258);
            this.GroupBox3.TabIndex = 21;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Under The Hood";
            // 
            // MainList
            // 
            this.MainList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.MainList.FormattingEnabled = true;
            this.MainList.HorizontalScrollbar = true;
            this.MainList.Location = new System.Drawing.Point(6, 19);
            this.MainList.Name = "MainList";
            this.MainList.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.MainList.Size = new System.Drawing.Size(472, 234);
            this.MainList.TabIndex = 4;
            // 
            // PollTimer
            // 
            this.PollTimer.Interval = 1000;
            this.PollTimer.Tick += new System.EventHandler(this.PollTimer_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(523, 391);
            this.Controls.Add(this.GroupBox3);
            this.Controls.Add(this.RulesGroup);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Komodia\'s Redirector ad injection for C#";
            this.RulesGroup.ResumeLayout(false);
            this.DisPanel.ResumeLayout(false);
            this.DisPanel.PerformLayout();
            this.GroupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        internal System.Windows.Forms.GroupBox RulesGroup;
	    internal System.Windows.Forms.Button Button3;
		internal System.Windows.Forms.GroupBox GroupBox3;
		internal System.Windows.Forms.ListBox MainList;
        internal System.Windows.Forms.Panel DisPanel;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.TextBox InjectText;
		internal System.Windows.Forms.TextBox SiteText;
		internal System.Windows.Forms.Label Label10;
	    internal System.Windows.Forms.Timer PollTimer;
		public MainForm()
		{
			Disposed += MainForm_Disposed;
			InitializeComponent();
		}
	}
}
