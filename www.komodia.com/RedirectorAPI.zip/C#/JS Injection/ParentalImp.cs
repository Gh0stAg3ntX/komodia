using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
namespace ModifyTraffic
{

	public class ParentalImp : PCProxyLib.IParentalControl
	{


		private MainForm TheForm;
		public void SetForm(MainForm _TheForm)
		{
			TheForm = _TheForm;
		}

		public void ConnectionClosed(int lConnectionID, int lError, string bStringToStore)
		{
			string sMessage = null;
			sMessage = "Connection ID: " + lConnectionID + " closed";

			TheForm.AddItem(ref sMessage);
		}

		public PCProxyLib._DataActionType DataBeforeReceive(int lConnectionID, ref PCProxyLib.DataContainer pData, ref int lTerminateSession, int lServerClosed, ref string bStringToStore)
		{
			return PCProxyLib._DataActionType.naAllowData;
		}

		public PCProxyLib._DataActionType DataBeforeSend(int lConnectionID, ref PCProxyLib.DataContainer pData, ref int lTerminateSession, ref int lNewBufferToReceive, ref string bStringToStore)
		{
			return PCProxyLib._DataActionType.naAllowData;
		}

		public int NewConnection(int lConnectionID, int lFromEncryption, int lPID, string bProcessName, string bUsername, string bDomain, string bIPString, ref int lIP, ref int lPort, ref int lSSL,
		ref int lProxyModified, ref PCProxyLib._IProxyType lProxyType, ref int lProxyIP, ref int lProxyPort, ref string pUsername, ref string pPassword, string bDNSEntry, ref PCProxyLib._FilteringType pFilteringType, ref string bStringToStore)
		{
			int functionReturnValue = 0;
			bStringToStore = "barak";

			//Build the connection string
			string sMessage = null;
			if (lFromEncryption == 1) {
				sMessage = "New SSL connection ID: ";
			} else {
				sMessage = "New connection ID: ";
			}

			sMessage = sMessage + lConnectionID + " to: " + bIPString + ":" + lPort;

			TheForm.AddItem(ref sMessage);
			functionReturnValue = 1;

			//This same needs the parental

			//Which filtering
			pFilteringType = PCProxyLib._FilteringType.ftParentalOnly;
			return functionReturnValue;
		}

		public PCProxyLib._ActionType NewReply(int lConnectionID, string bRequestHeader, string bFullRequestURL, string bReplyHeader, string bContentType, int lReplyOnly, ref PCProxyLib.DataContainer pReplyHeader, ref PCProxyLib.DataContainer pReplyBody, ref string bRedirectTo, ref string bStringToStore)
		{
			PCProxyLib._ActionType functionReturnValue = default(PCProxyLib._ActionType);
			
            //Skip tells Redirector to do default processing (will build html but not other files)
			//We may change it ahead
			functionReturnValue = PCProxyLib._ActionType.atSkip;

			//Build the connection string
			string sMessage = null;
			sMessage = "Connection ID: " + lConnectionID + " new reply for url: " + bFullRequestURL + " with header: " + bReplyHeader;

			TheForm.AddItem(ref sMessage);

			//Can only search text
			if (bContentType.ToLower().Contains("html")) 
            {
			    //Which stage are we?
	            if (lReplyOnly==1)
                    functionReturnValue = PCProxyLib._ActionType.atNothing;
                else
                {
                    //Can we inject?
                    int iPos=pReplyBody.SearchHTMLString("</head");
                    if (iPos>-1)
                    {
                        //Inject
                        pReplyBody.InjectData(iPos,TheForm.InjectText.Text);

                        //Set we had a change
                        functionReturnValue = PCProxyLib._ActionType.atModifyBodySDKAdjustHeader;
                        
                        sMessage = "Connection ID: " + lConnectionID + " reply injected: " + bRequestHeader;
                        
                        TheForm.AddItem(ref sMessage);
                    }
				}
			}

			return functionReturnValue;
		}

		public PCProxyLib._ActionType NewRequest(int lConnectionID, ref PCProxyLib.DataContainer pHeader, string bHeaderNoPost, string bHost, string bURL, string bFullRequest, int lPartialPost, ref string bRedirectTo, ref string bStringToStore)
		{
			PCProxyLib._ActionType functionReturnValue = default(PCProxyLib._ActionType);
			//Skip tells Redirector to do default processing (will build html but not other files)
			//We may change it ahead
			
			//Build the connection string
			string sMessage = null;
			sMessage = "Connection ID: " + lConnectionID + " new request : " + bFullRequest;

			TheForm.AddItem(ref sMessage);

			//Are we in the site
            if (bHost.ToLower().Contains(TheForm.SiteText.Text.ToLower()))
                //Which phase are we?
                functionReturnValue=PCProxyLib._ActionType.atDontProcessPost;
            else
                functionReturnValue = PCProxyLib._ActionType.atDontDoParentalAndDontProcessPost;

			return functionReturnValue;
		}
	}
}
