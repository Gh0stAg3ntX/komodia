samples and files in this package:

Run this showcase first.exe - Demo to show the filtering capabilities

C++
---

Direct\API - C++ sample showing how to use the API directly with the COM interface.
Direct\Header and cookies - C++ sample showing how to use the header and cookies processing directly with the COM interface.
Direct\Import table - C++ sample showing how to load a text file into table in the SDK
Direct\Proxy - C++ sample showing how to set the proxy
Direct\Traffic handling samples - C++ sample that implements the COM framework to receive traffic.
Direct\Ad inject with HTTP Parser - C++ samples that implements the COM framework to inject an element into a webpage
Direct\Ad inject with ad injector - C++ samples that implements the COM framework to inject an element into a webpage (maybe faster on some sites then the HTTP Parser, but a little more complicated)

DLL\RedirectorControlDLL - Controlling DLL that wraps the COM API.
DLL\TestControlDLL - Shows how to use the DLL.
DLL]Compiled DLL - The compiled DLL.

VB
--

Contains the source code of PCController, all the COM controlling API are shown in this sample.

VB.Net
------

Redirector - Sample of how to use the COM control API.
Watchdog - Sample of how to configure the Watchdog.
Traffic handling samples - Source code of the demo.

C#
--

TestRedirector - Sample of how to use the COM control API.
Traffic handling samples - Source code of the demo.

Delphi
------

Traffic handling samples - Source code of the demo.