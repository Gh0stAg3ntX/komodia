#ifndef _RedirectorGlobals_H_
#define _RedirectorGlobals_H_

typedef enum _RD_ActionType
{
	atSave,
	atLoad,
	atClear
} RD_ActionType;

typedef enum _RD_ItemType
{
	itApplication,
	itApplicationInv,
	itPort,
	itPortInv,
	itIP,
	itIPInv,
	itSSLApps,
	itHardExclude = 9,
    itHardInclude,
	itApplicationUDP,
    itPortUDP,
    itIPUDP,
    itApplicationInvUDP,
    itPortInvUDP,
    itIPInvUDP,
    itApplicationTCPI,
    itPortTCPI,
    itIPTCPI,
    itApplicationInvTCPI,
    itPortInvTCPI,
    itIPInvTCPI
} RD_ItemType;

typedef enum _RD_ProxyType
{
	ptHTTP,
	ptHTTPConnect,
	ptHTTPConnectSSL,
	ptHTTPHybrid,
	ptHTTPHybridSSL,
	ptSocks4,
	ptSocks5,
	ptNone
} RD_ProxyType;

//Log types
typedef enum _RD_LogType
{
	rltNone,
	rltSingleFile,
	rltMultiFile,
	rltMultiFileStreams
} RD_LogType;

//Inv defintions
//TCP
#define APPINV L"appinv"
#define PORTINV L"portinv"
#define IPINV L"ipinv"

//UDP
#define APPINVUDP L"appinvudp"
#define PORTINVUDP L"portinvudp"
#define IPINVUDP L"ipinvudp"

//TCP Incoming
#define APPINVI L"appinvi"
#define PORTINVI L"portinvi"
#define IPINVI L"ipinvi"

//DLL filename
#define DLL_NAME L"dlltoload"

#endif
