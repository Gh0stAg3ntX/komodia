#if !defined(AFX_REDIRECTORCONTROL_H__8220E327_E660_437B_89D5_FED653257349__INCLUDED_)
#define AFX_REDIRECTORCONTROL_H__8220E327_E660_437B_89D5_FED653257349__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <string>

#include "RedirectorGlobals.h"

class CRedirectorControl  
{
public:
	//Set the log
	static std::wstring SetLog(const std::wstring& rLogPath,
						       RD_LogType aType);

	//Is the DLL locked
	static bool IsDLLLocked();

	//Set a flag
	static std::wstring SetFlag(const std::wstring& rFlagName,
								const std::wstring& rParameter);

	//Get the flag
	static std::wstring GetFlag(const std::wstring& rFlagName,
								std::wstring& rParameter);

	//Set the redirector status
	static std::wstring SetRedirectorEnabled(bool bEnabled);

	//Is the redirector enabled
	static std::wstring IsRedirectorEnabled(bool& rEnabled);

	//Set the redirector DNS status (only relevant with DNS module)
	static std::wstring SetRedirectorDNSEnabled(bool bEnabled);

	//Is the redirector enabled (only relevant with DNS module)
	static std::wstring IsRedirectorDNSEnabled(bool& rEnabled);

	//Clear the proxy
	static std::wstring ClearProxyInformation();

	//Get the proxy from the redirector
	static std::wstring GetProxyInformation(std::string& rIP,
											unsigned short& rPort,
											std::string& rUsername,
											std::string& rPassword,
											_RD_ProxyType& rType);

	//Set the proxy for the redirector
	static std::wstring SetProxyInformation(const std::string& rIP,
											unsigned short usPort,
											const std::string& rUsername,
											const std::string& rPassword,
											_RD_ProxyType aType);

	//Delete an item
	static std::wstring DeleteItem(_RD_ItemType aItem,
								   const std::wstring& rItem);

	//Get an item
	static std::wstring GetItems(_RD_ItemType aItem);

	//Add an item
	static std::wstring AddItem(_RD_ItemType aItem,
								const std::wstring& rItem);

	//Do a clear/load/save
	static std::wstring TakeAction(_RD_ActionType aType);

	//Ctor and Dtor
	CRedirectorControl();
	virtual ~CRedirectorControl();
};

#endif // !defined(AFX_REDIRECTORCONTROL_H__8220E327_E660_437B_89D5_FED653257349__INCLUDED_)
