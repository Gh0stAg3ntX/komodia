#include "stdafx.h"
#include "WatchdogControl.h"

#ifndef VS_EXPRESS

#include <atlbase.h>

#endif

#import "PCProxy.tlb" no_namespace

std::wstring StringToString(const std::string& rString);
std::string CreateCOMError(unsigned long ulError);

//Get the main controller
std::string GetWDController(IWatchDogPtr& rController)
{
	//Create the coclass
	HRESULT h;
	if (FAILED(h=rController.CreateInstance(__uuidof(WatchDog))))
		//Exit
		return "GetWDController: Failed to initialize CoClass Watchdog with error: "+CreateCOMError(h);
	else
		//OK
		return "";
}

CWatchdogControl::CWatchdogControl()
{
}

CWatchdogControl::~CWatchdogControl()
{
}

std::wstring CWatchdogControl::Install()
{
	try
	{
		//Get the main class
		IWatchDogPtr aCtrl;
		std::string sError;
		sError=GetWDController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Try to install
		HRESULT h;
		long pTmp=0;
		if (FAILED(h=aCtrl->raw_Install(&pTmp)))
			//Report it
			return StringToString("CWatchdogControl::Install: Failed to call raw_Install with error: "+CreateCOMError(h));
		else if (!pTmp)
			return L"CWatchdogControl::Install: Call return with soft error";
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CWatchdogControl::GetRunningStatus(bool& rInstalled,
												bool& rRunning)
{
	try
	{
		//Get the main class
		IWatchDogPtr aCtrl;
		std::string sError;
		sError=GetWDController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Try to install
		HRESULT h;
		long lRunning=0;
		long lInstalled=0;
		long lResult=0;
		if (FAILED(h=aCtrl->raw_GetServiceStatus(&lInstalled,
												 &lRunning,
												 &lResult)))
			//Report it
			return StringToString("CWatchdogControl::GetRunningStatus: Failed to call raw_GetServiceStatus with error: "+CreateCOMError(h));
		else if (!lResult)
			return L"CWatchdogControl::GetRunningStatus: Call return with soft error";

		//Save the data
		rInstalled=(lInstalled==1);
		rRunning=(lRunning==1);
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CWatchdogControl::AddRedirectorProtection()
{
	try
	{
		//Get the main class
		IWatchDogPtr aCtrl;
		std::string sError;
		sError=GetWDController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Try to install
		HRESULT h;
		if (FAILED(h=aCtrl->raw_AddRedirectorProtection()))
			//Report it
			return StringToString("CWatchdogControl::AddRedirectorProtection: Failed to call raw_AddRedirectorProtection with error: "+CreateCOMError(h));
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CWatchdogControl::Uninstall()
{
	try
	{
		//Get the main class
		IWatchDogPtr aCtrl;
		std::string sError;
		sError=GetWDController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Try to install
		HRESULT h;
		long pTmp=0;
		if (FAILED(h=aCtrl->raw_Uninstall(&pTmp)))
			//Report it
			return StringToString("CWatchdogControl::Uninstall: Failed to call raw_Install with error: "+CreateCOMError(h));
		else if (!pTmp)
			return L"CWatchdogControl::Uninstall: Call return with soft error";
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CWatchdogControl::AddTrustedPID(unsigned long ulPID)
{
	try
	{
		//Get the main class
		IWatchDogPtr aCtrl;
		std::string sError;
		sError=GetWDController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Try to add it
		HRESULT h;
		long pTmp=0;
		if (FAILED(h=aCtrl->raw_AddTrustedPID(ulPID,
										      &pTmp)))
			//Report it
			return StringToString("CWatchdogControl::AddTrustedPID: Failed to call raw_AddTrustedPID with error: "+CreateCOMError(h));
		else if (!pTmp)
			return L"CWatchdogControl::AddTrustedPID: Call return with soft error";
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CWatchdogControl::ApplyRules()
{
	try
	{
		//Get the main class
		IWatchDogPtr aCtrl;
		std::string sError;
		sError=GetWDController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Try to install
		HRESULT h;
		long pTmp=0;
		if (FAILED(h=aCtrl->raw_ApplyRules(&pTmp)))
			//Report it
			return StringToString("CWatchdogControl::ApplyRules: Failed to call raw_ApplyRules with error: "+CreateCOMError(h));
		else if (!pTmp)
			return L"CWatchdogControl::ApplyRules: Call return with soft error";
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CWatchdogControl::RemoveRules()
{
	try
	{
		//Get the main class
		IWatchDogPtr aCtrl;
		std::string sError;
		sError=GetWDController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Try to install
		HRESULT h;
		long pTmp=0;
		if (FAILED(h=aCtrl->raw_ClearRules(&pTmp)))
			//Report it
			return StringToString("CWatchdogControl::RemoveRules: Failed to call raw_RemoveRules with error: "+CreateCOMError(h));
		else if (!pTmp)
			return L"CWatchdogControl::RemoveRules: Call return with soft error";
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}