#ifndef _WatchdogControl_H_
#define _WatchdogControl_H_

#include <string>

#include "RedirectorGlobals.h"

class CWatchdogControl
{
public:
	//Add a PID to be trusted
	static std::wstring AddTrustedPID(unsigned long ulPID);

	//Apply the rules (will upload them to WD)
	static std::wstring ApplyRules();

	//Remove the rules from the WD
	static std::wstring RemoveRules();

	//Add redirector protection
	static std::wstring AddRedirectorProtection();

	//Get running status
	static std::wstring GetRunningStatus(bool& rInstalled,
										 bool& rRunning);

	//Install the watchdog
	static std::wstring Install();

	//Uninstall teh watchdog
	static std::wstring Uninstall();

	//Ctor and Dtor
	CWatchdogControl();
	virtual ~CWatchdogControl();
};

#endif