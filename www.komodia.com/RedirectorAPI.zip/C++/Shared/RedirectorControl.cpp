#include "stdafx.h"
#include "RedirectorControl.h"

#ifndef VS_EXPRESS

#include <atlbase.h>

#endif

#import "PCProxy.tlb" no_namespace

//Convert a string
std::wstring StringToString(const std::string& rString)
{
	//Our final string
	std::wstring sFinal;

	//Start to iterate the string
	for (int iCount=0;
		 iCount<rString.size();
		 ++iCount)
		//Take the lower portion
		sFinal+=rString[iCount];

	//Done
	return sFinal;
}

//Convert a COM error
std::string CreateCOMError(unsigned long ulError)
{
	//Create the error
	char aTmp[MAX_PATH];
	sprintf(aTmp,"%x",ulError);
	return aTmp;
}

//Get the main controller
std::string GetController(IDataControllerPtr& rController)
{
	//Create the coclass
	HRESULT h;
	if (FAILED(h=rController.CreateInstance(__uuidof(DataController))))
		//Exit
		return "GetController: Failed to initialize CoClass LSPController with error: "+CreateCOMError(h);
	else
		//OK
		return "";
}

CRedirectorControl::CRedirectorControl()
{
}

CRedirectorControl::~CRedirectorControl()
{
}

std::wstring CRedirectorControl::TakeAction(_RD_ActionType aType)
{
	try
	{
		//Get the main class
		IDataControllerPtr aCtrl;
		std::string sError;
		sError=GetController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Which action to take?
		if (aType==atSave)
		{
			//Try to save
			_bstr_t sTmp;
			sTmp=aCtrl->Save();

			//Is it OK?
			return sTmp;
		}
		else if (aType==atLoad)
		{
			//Try to load
			_bstr_t sTmp;
			sTmp=aCtrl->Load();

			//Is it OK?
			return sTmp;
		}
		else
		{
			//Try to clear
			HRESULT h;
			if (FAILED(h=aCtrl->Clear()))
				//Report it
				return StringToString("CRedirectorControl::TakeAction: Failed to call clear with error: "+CreateCOMError(h));
		}
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CRedirectorControl::AddItem(_RD_ItemType aItem,
										 const std::wstring& rItem)
{
	try
	{
		//Get the main class
		IDataControllerPtr aCtrl;
		std::string sError;
		sError=GetController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Which table are we using?
		_Tables aTableType;
		if (aItem==itIP)
			aTableType=dtIP;
		else if (aItem==itApplication)
			aTableType=dtApplication;
		else if (aItem==itPort)
			aTableType=dtPort;
		else if (aItem==itIPInv)
			aTableType=dtIPInv;
		else if (aItem==itApplicationInv)
			aTableType=dtApplicationInv;
		else if (aItem==itPortInv)
			aTableType=dtPortInv;
		else if (aItem==itIPTCPI)
			aTableType=dtIPTCPI;
		else if (aItem==itApplicationTCPI)
			aTableType=dtApplicationTCPI;
		else if (aItem==itPortTCPI)
			aTableType=dtPortTCPI;
		else if (aItem==itIPInvTCPI)
			aTableType=dtIPInvTCPI;
		else if (aItem==itApplicationInvTCPI)
			aTableType=dtApplicationInvTCPI;
		else if (aItem==itPortInvTCPI)
			aTableType=dtPortInvTCPI;
		else if (aItem==itIPUDP)
			aTableType=dtIPUDP;
		else if (aItem==itApplicationUDP)
			aTableType=dtApplicationUDP;
		else if (aItem==itPortUDP)
			aTableType=dtPortUDP;
		else if (aItem==itIPInvUDP)
			aTableType=dtIPInvUDP;
		else if (aItem==itApplicationInvUDP)
			aTableType=dtApplicationInvUDP;
		else if (aItem==itPortInvUDP)
			aTableType=dtPortInvUDP;
		else if (aItem==itSSLApps)
			aTableType=dtSSLApps;
		else
			return L"";

		//Get the proxies table
		IDataTablePtr aTable=aCtrl->GetTable(aTableType);

		//Start to set the information
		aTable->AddString(rItem.c_str());
		aTable->Commit();
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CRedirectorControl::GetItems(_RD_ItemType aItem)
{
	try
	{
		//Get the main class
		IDataControllerPtr aCtrl;
		std::string sError;
		sError=GetController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Which table are we using?
		_Tables aTableType;
		if (aItem==itIP)
			aTableType=dtIP;
		else if (aItem==itApplication)
			aTableType=dtApplication;
		else if (aItem==itPort)
			aTableType=dtPort;
		else if (aItem==itIPInv)
			aTableType=dtIPInv;
		else if (aItem==itApplicationInv)
			aTableType=dtApplicationInv;
		else if (aItem==itPortInv)
			aTableType=dtPortInv;
		else
			return L"";

		//Get the proxies table
		IDataTablePtr aTable=aCtrl->GetTable(aTableType);

		//Start to set the information
		_bstr_t sStr;
		sStr=aTable->BulkGet();
	
		//Done
		return sStr;
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CRedirectorControl::DeleteItem(_RD_ItemType aItem,
											const std::wstring& rItem)
{
	try
	{
		//Get the main class
		IDataControllerPtr aCtrl;
		std::string sError;
		sError=GetController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Which table are we using?
		_Tables aTableType;
		if (aItem==itIP)
			aTableType=dtIP;
		else if (aItem==itApplication)
			aTableType=dtApplication;
		else if (aItem==itPort)
			aTableType=dtPort;
		else if (aItem==itIPInv)
			aTableType=dtIPInv;
		else if (aItem==itApplicationInv)
			aTableType=dtApplicationInv;
		else if (aItem==itPortInv)
			aTableType=dtPortInv;
		else
			return L"";

		//Get the proxies table
		IDataTablePtr aTable=aCtrl->GetTable(aTableType);

		//Delete the item
		aTable->EraseString(rItem.c_str());
		aTable->Commit();

		//Done
		return L"";
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CRedirectorControl::SetProxyInformation(const std::string& rIP,
													 unsigned short usPort,
													 const std::string& rUsername,
													 const std::string& rPassword,
													 _RD_ProxyType aType)
{
	try
	{
		//Get the main class
		IDataControllerPtr aCtrl;
		std::string sError;
		sError=GetController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Get the proxies table
		IDataTablePtr aTable=aCtrl->GetTable(dtProxy);

		//Start to set the information
		aTable->AddStringIdx("ip",rIP.c_str());
		aTable->AddLongIdx("port",usPort);
		aTable->AddStringIdx("username",rUsername.c_str());
		aTable->AddStringIdx("password",rPassword.c_str());
		aTable->AddLongIdx("type",(long)aType);
		aTable->Commit();
	
		//Done
		return L"";
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CRedirectorControl::ClearProxyInformation()
{
	try
	{
		//Get the main class
		IDataControllerPtr aCtrl;
		std::string sError;
		sError=GetController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Get the proxies table
		IDataTablePtr aTable=aCtrl->GetTable(dtProxy);

		//Start to set the information
		aTable->Clear();
		aTable->Commit();
	
		//Done
		return L"";
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CRedirectorControl::IsRedirectorEnabled(bool& rEnabled)
{
	try
	{
		//Set status
		rEnabled=false;

		//Get the main class
		IDataControllerPtr aCtrl;
		std::string sError;
		sError=GetController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Get the status
		rEnabled=(aCtrl->IsEnabled()!=0);
	
		//Done
		return L"";
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CRedirectorControl::SetRedirectorDNSEnabled(bool bEnabled)
{
	try
	{
		//Our value
		std::wstring sValue;
		if (bEnabled)
			sValue=L"1";
		else
			sValue=L"0";

		//Try to set the flag
		return SetFlag(L"dnsenable",
					   sValue);
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CRedirectorControl::IsRedirectorDNSEnabled(bool& rEnabled)
{
	try
	{
		//Sanity
		rEnabled=false;

		//Get the flag
		std::wstring sValue;
		std::wstring sError=GetFlag(L"dnsenable",
									sValue);

		//Did we had an error
		if (!sError.empty())
			return sError;

		//What are we?
		if (sValue==L"1")
			rEnabled=true;

		//Done
		return L"";
		
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}
	
std::wstring CRedirectorControl::SetRedirectorEnabled(bool bEnabled)
{
	try
	{
		//Get the main class
		IDataControllerPtr aCtrl;
		std::string sError;
		sError=GetController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Toggle
		aCtrl->SetEnable(bEnabled);
	
		//Done
		return L"";
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CRedirectorControl::GetProxyInformation(std::string& rIP,
													 unsigned short& rPort,
													 std::string& rUsername,
													 std::string& rPassword,
												 	 _RD_ProxyType& rType)
{
	try
	{
		//Get the main class
		IDataControllerPtr aCtrl;
		std::string sError;
		sError=GetController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Get the proxies table
		IDataTablePtr aTable=aCtrl->GetTable(dtProxy);

		//Make sure we have the proxy
		if (!aTable->DoesStringExists("ip"))
		{
			//Clear the port
			rPort=0;

			//Exit
			return L"";
		}

		//Start to get the information
		_bstr_t sIP=aTable->GetString("ip");
		DWORD dwPort=aTable->GetLong("port");
		_bstr_t sUsername=aTable->GetString("username");
		_bstr_t sPassword=aTable->GetString("password");
		DWORD dwType=aTable->GetLong("type");

		//Give it to our data
		rIP=(const char*)sIP;
		rPort=dwPort;
		rUsername=(const char*)sUsername;
		rPassword=(const char*)sPassword;
		rType=(_RD_ProxyType)dwType;
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CRedirectorControl::SetFlag(const std::wstring& rFlagName,
										 const std::wstring& rParameter)
{
	try
	{
		//Get the main class
		IDataControllerPtr aCtrl;
		std::string sError;
		sError=GetController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Get the proxies table
		IDataTablePtr aTable=aCtrl->GetTable(dtFlags);

		//Start to set the information
		aTable->AddStringIdx(rFlagName.c_str(),
							 rParameter.c_str());
		aTable->Commit();
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CRedirectorControl::GetFlag(const std::wstring& rFlagName,
										 std::wstring& rParameter)
{
	try
	{
		//Get the main class
		IDataControllerPtr aCtrl;
		std::string sError;
		sError=GetController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Get the proxies table
		IDataTablePtr aTable=aCtrl->GetTable(dtFlags);

		//Start to set the information
		_bstr_t sParam;
		sParam=aTable->GetString(rFlagName.c_str());
		
		//Save it
		rParameter=sParam;
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}

std::wstring CRedirectorControl::SetLog(const std::wstring& rLogPath,
									    RD_LogType aType)
{
	try
	{
		//Get the main class
		IDataControllerPtr aCtrl;
		std::string sError;
		sError=GetController(aCtrl);

		//Do we have an error?
		if (!sError.empty())
			return StringToString(sError);

		//Set the log
		aCtrl->SetLog(rLogPath.c_str(),
					  (_LogType)aType);
	}
	catch (_com_error& rError)
	{
		return rError.Description();
	}

	//Done
	return L"";
}