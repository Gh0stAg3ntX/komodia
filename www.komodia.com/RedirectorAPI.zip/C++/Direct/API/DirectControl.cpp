// DirectControl.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <windows.h>

#include "RedirectorControl.h"

void PrintApps(_RD_ItemType pGetItemList)
{
	//Allocate the data
	std::wstring sApps=CRedirectorControl::GetItems(itApplication);

	//Show it
	printf("App list: %S\n",sApps.c_str());
}

int main(int argc, char* argv[])
{
	//First initialize COM
	if (FAILED(CoInitialize(NULL)))
		return 1;

	//This sample shows how to change various settings of the Redirector
	//Just use the one you need

	//Clear data
	//This method can be also used for save and load, just change the enum type
	CRedirectorControl::TakeAction(atClear);

	//Now lets add an application
	CRedirectorControl::AddItem(itApplication,L"iexplore.exe");
	CRedirectorControl::AddItem(itApplication,L"firefox.exe");

	//Lets print them
	PrintApps(itApplication);

	//Inverse applications
	CRedirectorControl::SetFlag(APPINV,
								L"1");

	//Uniniverse applications
	CRedirectorControl::SetFlag(APPINV,
								L"0");

	//Set custom DLL
	//Custom DLL is used mostly for parental control, or if you want to process the network traffic
	CRedirectorControl::SetFlag(DLL_NAME,
								L"c:\\mydll.dll");

	//Clear the custom DLL
	CRedirectorControl::SetFlag(DLL_NAME,
								L"");

	//We are done, save the data
	CRedirectorControl::TakeAction(atSave);

	//Set the logging (this option is debug and never saves itself)
	CRedirectorControl::SetLog(L"c:\\",rltMultiFile);

	//Uninit COM
	CoUninitialize();

	//Done
	return 0;
}
