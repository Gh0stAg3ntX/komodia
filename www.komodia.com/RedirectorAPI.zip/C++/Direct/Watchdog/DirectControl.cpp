// DirectControl.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <windows.h>

#include "RedirectorControl.h"
#include "WatchdogControl.h"

#import "PCProxy.tlb" no_namespace

//Get the main controller
std::string GetController(IDataControllerPtr& rController);

int main(int argc, char* argv[])
{
	//First initialize COM
	if (FAILED(CoInitialize(NULL)))
		return 1;

	//Check if the WD is installed
	bool bInstalled=false;
	bool bRunning=false;
	if (!CWatchdogControl::GetRunningStatus(bInstalled,
											bRunning).empty())
		return 1;

	//Are we installed?
	if (!bInstalled)
		//Try to install it
		if (!CWatchdogControl::Install().empty())
			return 1;

	{
		//Get the controller
		IDataControllerPtr aCont;
		if (!GetController(aCont).empty())
			return 2;

		//WD rules are stored in four tables
		//Lets get them all

		try
		{
			//Check if rules are applied
			std::wstring sApplied;
			if (!CRedirectorControl::GetFlag(L"wdrules",
											 sApplied).empty())
				return 3;

			//Are we applied
			if (sApplied==L"1")
				//At this stage the rules are applied, we can't change anything, we need to remove them
				//If we want to do anything
				if (!CWatchdogControl::RemoveRules().empty())
					return 4;

			//Now we have several options
			//Use the one you need

			//Clear all rules
			{	
				//First access the HTTP Filter container
				IDataTableHolderPtr aHolder=aCont->GetContainer(ctWatchdog);

				//Get the table for the read only files
				IDataTablePtr aTblRO=aHolder->GetTable("filero");

				//Get the table for the total protection files
				IDataTablePtr aTblF=aHolder->GetTable("file");

				//Get the table for the process list
				IDataTablePtr aTblP=aHolder->GetTable("process");

				//Get the table for the registry
				IDataTablePtr aTblR=aHolder->GetTable("registry");

				//Clear all rules
				aTblRO->Clear();
				aTblRO->Commit();
				
				aTblF->Clear();
				aTblF->Commit();

				aTblP->Clear();
				aTblP->Commit();

				aTblR->Clear();
				aTblR->Commit();

				//Commit the manager
				aHolder->Commit();
			}

			//Now add the Redirector rules
			if (!CWatchdogControl::AddRedirectorProtection().empty())
				return 6;

			//Now lets add some of our rules
			{	
				//First access the HTTP Filter container
				IDataTableHolderPtr aHolder=aCont->GetContainer(ctWatchdog);

				//Get the table for the read only files
				IDataTablePtr aTblRO=aHolder->GetTable("filero");

				//Get the table for the total protection files
				IDataTablePtr aTblF=aHolder->GetTable("file");

				//Get the table for the process list
				IDataTablePtr aTblP=aHolder->GetTable("process");

				//Get the table for the registry
				IDataTablePtr aTblR=aHolder->GetTable("registry");

				//Clear all rules
				aTblRO->AddString(L"c:\\test.txt");
				aTblRO->Commit();
				
				aTblF->AddString(L"c:\\test2.txt");
				aTblF->Commit();

				aTblP->AddString(L"c:\\someprocess.exe");
				aTblP->Commit();

				aTblR->AddString(L"HKEY_LOCAL_MACHINE\\omereg\\somereg*");
				aTblR->Commit();

				//Commit the manager
				aHolder->Commit();
			}

			//Now we need to save it
			CRedirectorControl::TakeAction(atSave);

			//Upload the rules to the WD
			if (!CWatchdogControl::ApplyRules().empty())
				return 4;
		}
		catch (...)
		{
		}		

		//If you want to uninstall the WD, this is the method to call
		//CWatchdogControl::Uninstall()
	}

	//Uninit COM
	CoUninitialize();

	//Done
	return 0;
}
