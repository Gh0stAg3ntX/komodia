#if !defined(AFX_PARENTALIMP_H__8BB26121_6E78_4CD4_B560_7F1EFBA5489C__INCLUDED_)
#define AFX_PARENTALIMP_H__8BB26121_6E78_4CD4_B560_7F1EFBA5489C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#import "PCProxy.tlb" no_namespace

#include <atlbase.h>

extern CComModule _Module;
#include <atlcom.h>

extern GUID LIBID_PCProxyLib;
extern GUID CLSID_ParentalImp_CoClass;

class ATL_NO_VTABLE CParentalImp : public CComObjectRootEx<CComMultiThreadModel>,
								   public CComCoClass<CParentalImp, &CLSID_ParentalImp_CoClass>,
								   public IDispatchImpl<IParentalControl, &__uuidof(IParentalControl), &LIBID_PCProxyLib>
{
public:
	//Little hack
	static HRESULT WINAPI UpdateRegistry(BOOL bRegister)
	{
		return S_OK;
	}

	DECLARE_NOT_AGGREGATABLE(CParentalImp)
	DECLARE_GET_CONTROLLING_UNKNOWN()

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	BEGIN_COM_MAP(CParentalImp)
		COM_INTERFACE_ENTRY(IParentalControl)
		COM_INTERFACE_ENTRY(IDispatch)
		COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
	END_COM_MAP()

	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

	//Methods we need to change
    virtual HRESULT __stdcall raw_NewConnection(long lConnectionID,
												long lFromEncryption,
												long lPID,
												BSTR bProcessName,
												BSTR bUsername,
												BSTR bDomain,
												BSTR bIPString,
												long* lIP,
												long* lPort,
												long* lSSL,
												long* lProxyModified,
												enum _IProxyType* lProxyType,
												long* lProxyIP,
												long* lProxyPort,
												BSTR* pUsername,
												BSTR* pPassword,
												BSTR bDNSEntry,
												enum _FilteringType* pFilteringType,
												BSTR* bStringToStore,
												long* lAllow);

	virtual HRESULT __stdcall raw_NewRequest(long lConnectionID,
											 struct IDataContainer** pHeader,
											 BSTR bHeaderNoPost,
											 BSTR bHost,
											 BSTR bURL,
											 BSTR bFullRequest,
											 long lPartialPost,
											 BSTR* bRedirectTo,
											 BSTR* bStringToStore,
											 enum _ActionType* pAction);

    virtual HRESULT __stdcall raw_NewReply(long lConnectionID,
										   BSTR bRequestHeader,
										   BSTR bFullRequestURL,
										   BSTR bReplyHeader,
										   BSTR bContentType,
										   long lReplyOnly,
										   struct IDataContainer** pReplyHeader,
										   struct IDataContainer** pReplyBody,
									       BSTR* bRedirectTo,
										   BSTR* bStringToStore,
										   enum _ActionType* pAction);

    virtual HRESULT __stdcall raw_ConnectionClosed(long lConnectionID,
												   long lError,
											       BSTR bStringToStore);

    virtual HRESULT __stdcall raw_DataBeforeReceive(long lConnectionID,
													struct IDataContainer** pData,
													long* lTerminateSession,
													long lServerClosed,
													BSTR* bStringToStore,
													enum _DataActionType* pAction);

    virtual HRESULT __stdcall raw_DataBeforeSend(long lConnectionID,
												 struct IDataContainer** pData,
												 long* lTerminateSession,
												 long* lNewBufferToReceive,
												 BSTR* bStringToStore,
												 enum _DataActionType* pAction);

	//Ctor and Dtor
	CParentalImp();
	virtual ~CParentalImp();

};

#endif // !defined(AFX_PARENTALIMP_H__8BB26121_6E78_4CD4_B560_7F1EFBA5489C__INCLUDED_)
