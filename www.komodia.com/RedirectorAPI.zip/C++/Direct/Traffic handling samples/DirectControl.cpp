// DirectControl.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#define _WIN32_WINNT 0x0501

#include <windows.h>
#include <conio.h>

#include "RedirectorControl.h"

#include "ParentalImp.h"

std::string GetController(IDataControllerPtr& rController);

CComModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
OBJECT_ENTRY(CLSID_ParentalImp_CoClass, CParentalImp)
END_OBJECT_MAP()

//Do you want COM to disconnect on error, or hard kill of the app
#define DISCONNECT_ON_ERROR

int main(int argc, char* argv[])
{
	//First initialize COM
	if (FAILED(CoInitializeEx(NULL, COINIT_MULTITHREADED)))
		return 1;

	//Clear data
	//This method can be also used for save and load, just change the enum type
	CRedirectorControl::TakeAction(atClear);

	//Now lets add an application
	CRedirectorControl::AddItem(itApplication,L"iexplore.exe");
	CRedirectorControl::AddItem(itApplication,L"firefox.exe");
	CRedirectorControl::AddItem(itApplication,L"chrome.exe");

	//Save the settings (this is needed just for WFP)
	CRedirectorControl::TakeAction(atSave);

	{
		CComObject<CParentalImp>* pMyClass = new CComObject<CParentalImp>();
		pMyClass->FinalConstruct();

		//Try to get the controller
		IDataControllerPtr aCtrl;
		std::string sResult=GetController(aCtrl);

		//Did we get it?
		if (sResult.empty())
		{
			//Get the interface
			IParentalControl* pInt=NULL;
			if (FAILED(pMyClass->QueryInterface(__uuidof(IParentalControl),(void**)&pInt)))
			{
				//Report it
				printf("Failed querying interface");

				//Exit
				return 1;
			}

			//Our disconnect status
			bool bDisconnect=false;
#ifdef DISCONNECT_ON_ERROR
			bDisconnect=true;
#endif

			//Set the interface
			aCtrl->SetParentalInterface(pInt,
										true,
										bDisconnect);

			//Show the user what to do
			printf("Demo is now running, open a browser (IE, FF, Chrome) to see the connections, press any key to stop\n");

#ifndef DISCONNECT_ON_ERROR

			//Now wait
			while (!kbhit())
				Sleep(10);
#else

			//Get the string
			std::string sData=aCtrl->GetInstaceIDRet();
			
			//Release the com
			aCtrl->Release();

			//Now wait
			while (!kbhit())
			{
				//Wait
				Sleep(1000);

				try
				{
					//Always create a new instance
					IDataControllerPtr aCtrl2;
					std::string sResult=GetController(aCtrl2);
					if (sResult.empty())
					{
						//Query the instance
						std::string sNew=aCtrl2->GetInstaceIDRet();
						if (sNew!=sData)
						{
							//Save it
							sData=sNew;

							//Reregister
							aCtrl2->SetParentalInterface(pInt,
														 true,
														 bDisconnect);
						}
					}
				}
				catch (...)
				{
				}
			}

#endif
			
		}
		else
			//Report it
			printf("Error getting the controller: %s\n",sResult.c_str());
	}

	//Clear settings
	CRedirectorControl::TakeAction(atClear);

	//Save the settings (this is needed just for WFP)
	CRedirectorControl::TakeAction(atSave);

	//Uninit COM
	CoUninitialize();

	//Done
	return 0;
}
