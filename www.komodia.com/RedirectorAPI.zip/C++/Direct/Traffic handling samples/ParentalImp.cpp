#include "stdafx.h"
#include "ParentalImp.h"

GUID LIBID_PCProxyLib = { 0xED721A76,0x8160,0x4da0, {0xA1,0x8E,0x7F,0xD7,0xC4,0x57,0x47,0x74}};
GUID CLSID_ParentalImp_CoClass = { 0x2D9DB333,0xDC4B,0x4577, {0x94,0x1C,0x5F,0x25,0x3B,0xCF,0x50,0x6B}};

CParentalImp::CParentalImp()
{
}

CParentalImp::~CParentalImp()
{
}

HRESULT __stdcall CParentalImp::raw_NewConnection(long lConnectionID,
												  long lFromEncryption,
												  long lPID,
												  BSTR bProcessName,
												  BSTR bUsername,
												  BSTR bDomain,
												  BSTR bIPString,
												  long* lIP,
												  long* lPort,
												  long* lSSL,
												  long* lProxyModified,
												  enum _IProxyType* lProxyType,
												  long* lProxyIP,
												  long* lProxyPort,
												  BSTR* pUsername,
												  BSTR* pPassword,
												  BSTR bDNSEntry,
												  enum _FilteringType* pFilteringType,
												  BSTR* bStringToStore,
												  long* lAllow)
{
	//Set what we want (in this case we will go with normal filter (data filter))
	//This can also be set to nothing, or parental control
	if (pFilteringType)
		*pFilteringType=ftDataOnly;

	//Allow the connection
	if (lAllow)
		*lAllow=true;

	//Print the info
	in_addr aTmp;
	if (lIP)
		aTmp.S_un.S_addr=*lIP;
	else
		aTmp.S_un.S_addr=0;

	//Get the port
	unsigned short usPort=0;
	if (lPort)
		usPort=*lPort;

	//Show the port
	printf("%i New connection to %s:%i (TID: %x)\n",lConnectionID,inet_ntoa(aTmp),usPort,GetCurrentThreadId());

	//Done
	return S_OK;
}

HRESULT __stdcall CParentalImp::raw_NewRequest(long lConnectionID,
											   struct IDataContainer** pHeader,
											   BSTR bHeaderNoPost,
											   BSTR bHost,
											   BSTR bURL,
											   BSTR bFullRequest,
											   long lPartialPost,
											   BSTR* bRedirectTo,
											   BSTR* bStringToStore,
											   enum _ActionType* pAction)
{
	//Set to skip
	if (pAction)
		*pAction=atSkip;

	//Done
	return S_OK;
}

HRESULT __stdcall CParentalImp::raw_NewReply(long lConnectionID,
										     BSTR bRequestHeader,
										     BSTR bFullRequestURL,
										     BSTR bReplyHeader,
										     BSTR bContentType,
										     long lReplyOnly,
										     struct IDataContainer** pReplyHeader,
										     struct IDataContainer** pReplyBody,
									         BSTR* bRedirectTo,
										     BSTR* bStringToStore,
										     enum _ActionType* pAction)
{
	//Set to skip
	if (pAction)
		*pAction=atSkip;

	//Done
	return S_OK;
}

HRESULT __stdcall CParentalImp::raw_ConnectionClosed(long lConnectionID,
												     long lError,
											         BSTR bStringToStore)
{
	//Show it
	printf("%i connection closed\n",lConnectionID);

	//Done
	return S_OK;
}

HRESULT __stdcall CParentalImp::raw_DataBeforeReceive(long lConnectionID,
													  struct IDataContainer** pData,
													  long* lTerminateSession,
													  long lServerClosed,
													  BSTR* bStringToStore,
													  enum _DataActionType* pAction)
{
	//Do nothing
	if (pAction)
		*pAction=naAllowData;

	//Get the data size
	DWORD dwSize=0;
	if (pData &&
		*pData)
		(*pData)->raw_GetSize((long*)&dwSize);

	//Show the data received
	if (dwSize)
		printf("%i New data received, bytes: %i\n",lConnectionID,dwSize);

	//Done
	return S_OK;
}

HRESULT __stdcall CParentalImp::raw_DataBeforeSend(long lConnectionID,
												   struct IDataContainer** pData,
												   long* lTerminateSession,
												   long* lNewBufferToReceive,
												   BSTR* bStringToStore,
												   enum _DataActionType* pAction)
{
	//Do nothing
	if (pAction)
		*pAction=naAllowData;

	//Get the data size
	DWORD dwSize=0;
	if (pData &&
		*pData)
		(*pData)->raw_GetSize((long*)&dwSize);

	//Show the data received
	if (dwSize)
		printf("%i New data to send, bytes: %i\n",lConnectionID,dwSize);

	//Done
	return S_OK;
}
