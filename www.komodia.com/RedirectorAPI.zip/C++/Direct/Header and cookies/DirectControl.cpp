// DirectControl.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <windows.h>

#include "RedirectorControl.h"

#import "PCProxy.tlb" no_namespace

//Get the main controller
std::string GetController(IDataControllerPtr& rController);

int main(int argc, char* argv[])
{
	//First initialize COM
	if (FAILED(CoInitialize(NULL)))
		return 1;

	//This sample shows how to change various settings of the Redirector
	//Just use the one you need

	//First we need to enable HTTP filtering
	CRedirectorControl::SetFlag(L"filterhttp",L"1");

	{
		//Get the controller
		IDataControllerPtr aCont;
		if (!GetController(aCont).empty())
			return 2;

		//This part will add a field to filter and a field to modify
		try
		{
			//First access the HTTP Filter container
			IDataTableHolderPtr aHolder=aCont->GetContainer(ctHTTPFilter);

			//Get the manager for the filter
			IDataTablePtr aTbl=aHolder->GetTable("filter");

			//Lets add refer as a string to clear
			aTbl->AddStringIdx(L"refer",L"");

			//Add a field to change the user agent
			aTbl->AddStringIdx(L"user-agent",L"Mozilla");

			//Save everything (once you are done, not per one change)
			aTbl->Commit();
			aHolder->Commit();
		}
		catch (...)
		{
		}

		//This part will add a custom field
		try
		{
			//First access the HTTP Filter container
			IDataTableHolderPtr aHolder=aCont->GetContainer(ctHTTPFilter);

			//Get the manager for the filter
			IDataTablePtr aTbl=aHolder->GetTable("custom");

			//Lets add a custom field
			aTbl->AddStringIdx(L"X-Komodia",L"Test");

			//Save everything (once you are done, not per one change)
			aTbl->Commit();
			aHolder->Commit();
		}
		catch (...)
		{
		}

		//This part adds regex domain names that the Redirector will filter cookies
		//Keep in mind that this part will work only if you have the cookie module
		try
		{
			//First access the HTTP Filter container
			IDataTableHolderPtr aHolder=aCont->GetContainer(ctHTTPFilter);

			//Get the manager for the filter
			IDataTablePtr aTbl=aHolder->GetTable("cookies");

			//Lets add a custom field
			//This is a regex domain, so make sure you add the domain name correctly
			aTbl->AddString(L"cnn.com");

			//Save everything (once you are done, not per one change)
			aTbl->Commit();
			aHolder->Commit();
		}
		catch (...)
		{
		}

		//Here we should save the data
		CRedirectorControl::TakeAction(atSave);
	}

	//Uninit COM
	CoUninitialize();

	//Done
	return 0;
}
