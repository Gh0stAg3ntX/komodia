// DirectControl.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <windows.h>

#include "RedirectorControl.h"

#import "PCProxy.tlb" no_namespace

//Get the main controller
std::string GetController(IDataControllerPtr& rController);

int main(int argc, char* argv[])
{
	//First initialize COM
	if (FAILED(CoInitialize(NULL)))
		return 1;

	//This sample shows how to change various settings of the Redirector
	//Just use the one you need

	//Clear data
	//This method can be also used for save and load, just change the enum type
	CRedirectorControl::TakeAction(atClear);

	{
		//Get the controller
		IDataControllerPtr aCont;
		if (!GetController(aCont).empty())
			return 2;

		//Get the proxies table
		IDataTablePtr aTbl=aCont->GetTable(dtProxyApps);

		//Build the proxy
		std::string sProxy;
		sProxy="12"; //This is the proxy type
		sProxy+="~127.0.0.1"; //Proxy IP
		sProxy+="~1080"; //Proxy port

		//These are optional username and password
		//sProxy+="~user";
		//sProxy+="~pass";

		//Add to the table
		aTbl->AddStringIdx("iexplore.exe",sProxy.c_str());

		//Commit the table
		aTbl->Commit();
	}

	//We are done, save the data
	CRedirectorControl::TakeAction(atSave);

	//Uninit COM
	CoUninitialize();

	//Done
	return 0;
}
