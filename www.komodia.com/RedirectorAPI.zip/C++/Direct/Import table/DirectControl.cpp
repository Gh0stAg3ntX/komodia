// DirectControl.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <windows.h>

#pragma warning(disable:4786)

#include <string>
#include <map>

#include "RedirectorControl.h"

#import "PCProxy.tlb" no_namespace

//Get the main controller
std::string GetController(IDataControllerPtr& rController);

//Our map of data
typedef std::map<std::string,std::string> DataMap;

int main(int argc, char* argv[])
{
	//First initialize COM
	if (FAILED(CoInitialize(NULL)))
		return 1;

	//Check the usage
	if (argc!=5)
	{
		//Show it
		printf("%s container table type filename\ntype is 0 for set 1 for map\n",argv[0]);

		//Exit
		return 1;
	}

	//Try to open the file
	FILE* pFile=fopen(argv[4],"rt");
	if (!pFile)
	{
		//Save the error code
		DWORD dwError=GetLastError();

		//Error it
		printf("File not found!\n");

		//Exit
		return dwError;
	}

	//What is our type?
	bool bSet=true;
	if (argv[3][0]=='1')
		bSet=false;

	//Our data
	DataMap aData;

	//Start to read
	while (!feof(pFile))
	{
		//Read a line
		char aTmp[16384];
		if (fscanf(pFile,"%[^=\n]",aTmp)==EOF)
			break;

		//And read the NULL or equal
		char aDummy[10];
		aDummy[0]=fgetc(pFile);

		//Save it
		std::string sIndex=aTmp;

		//Our data
		std::string sData;

		//Do we need to read it?
		if (!bSet)
		{
			//Read again
			if (fscanf(pFile,"%[^=\n]",aTmp)==EOF)
				break;

			//And read the NULL or equal
			aDummy[0]=fgetc(pFile);

			//Save the data
			sData=aTmp;
		}

		//Now add the data
		aData[sIndex]=sData;
	}

	//Close the file
	fclose(pFile);

	//Do we have data?
	if (aData.empty())
	{
		//Report it
		printf("No data to import!");

		//Exit
		return 0;
	}

	//This part will add a field to filter and a field to modify
	try
	{
		//Get the controller
		IDataControllerPtr aCont;
		if (!GetController(aCont).empty())
			return 2;

		//First access the HTTP Filter container
		IDataTableHolderPtr aHolder=aCont->GetContainerByString(argv[1]);

		//Get the manager for the filter
		IDataTablePtr aTbl;
		
		//What we need to get
		if (bSet)
			aTbl=aHolder->GetTableCreateSet(argv[2]);
		else
			aTbl=aHolder->GetTable(argv[2]);

		//Clear the table
		aTbl->Clear();

		//Start to add the data
		for (DataMap::iterator aIterator=aData.begin();
			 aIterator!=aData.end();
			 ++aIterator)
			//What kind of add?
			if (bSet)
				aTbl->AddString(aIterator->first.c_str());
			else
				aTbl->AddStringIdx(aIterator->first.c_str(),aIterator->second.c_str());

		//Save everything (once you are done, not per one change)
		aTbl->Commit();
		aHolder->Commit();
	}
	catch (...)
	{
		printf("COM ERROR!\n");
	}

	//Here we should save the data
	CRedirectorControl::TakeAction(atSave);

	//Uninit COM
	CoUninitialize();

	//Done
	return 0;
}
