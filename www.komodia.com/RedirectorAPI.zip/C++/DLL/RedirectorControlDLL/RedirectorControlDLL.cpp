// RedirectorControlDLL.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include <windows.h>
#include <objbase.h>

#include "RedirectorControl.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

bool _stdcall RD_ThreadInit()
{
	return !(FAILED(CoInitialize(NULL)));
}

void _stdcall RD_ThreadUninit()
{
	CoUninitialize();
}

bool _stdcall RD_AddFlag(const unsigned short* pIndex,
						 const unsigned short* pValue)
{
	//Delegate
	return CRedirectorControl::SetFlag(pIndex,
									   pValue).empty();
}

bool _stdcall RD_GetFlag(const unsigned short* pIndex,
						 unsigned short* pValue,
						 DWORD dwValueSize)
{
	//Try to get the flag
	std::wstring sVal;
	std::wstring sError=CRedirectorControl::GetFlag(pIndex,
													sVal);
	
	//Did we get it?
	if (!sVal.empty() ||
		dwValueSize<(sVal.size()+1)*2)
		return false;

	//Copy the data
	memcpy(pValue,
		   sVal.c_str(),
		   (sVal.size()+1)*2);

	//Done
	return true;
}

bool _stdcall RD_TakeAction(_RD_ActionType aType)
{
	return CRedirectorControl::TakeAction(aType).empty();
}

int _stdcall RD_GetItemList(_RD_ItemType aItem,
						    unsigned short* pList,
						    DWORD dwListSize)
{
	//Get the item list
	std::wstring sList;
	sList=CRedirectorControl::GetItems(aItem);

	//Can we save it?
	if (dwListSize>=(sList.size()+1)*2 &&
		pList)
	{
		//Copy it
		memcpy(pList,
			   sList.c_str(),
			   (sList.size()+1)*2);

		//Done
		return 0;
	}
	else
		//Send the size
		return (sList.size()+1)*2;
}

bool _stdcall RD_AddItem(_RD_ItemType aItem,
						 const unsigned short* pItem)
{
	//Sanity
	if (!pItem)
		return false;

	//Delegate
	return CRedirectorControl::AddItem(aItem,
									   pItem).empty();
}

bool _stdcall RD_DeleteItem(_RD_ItemType aItem,
						    const unsigned short* pItem)
{
	//Sanity
	if (!pItem)
		return false;

	//Delegate
	return CRedirectorControl::DeleteItem(aItem,
										  pItem).empty();
}

bool _stdcall RD_SetProxy(const char* pIP,
						  unsigned short usPort,
						  const char* pUsername,
						  const char* pPassword,
						  _RD_ProxyType aType)
{
	//Sanity
	if (!pIP ||
		!pUsername ||
		!pPassword)
		return false;

	//Delegate
	return CRedirectorControl::SetProxyInformation(pIP,
												   usPort,
												   pUsername,
												   pPassword,
												   aType).empty();
}

bool _stdcall RD_GetProxy(char* pIP,
						  DWORD dwIPSize,
						  unsigned short& rPort,
						  char* pUsername,
						  DWORD dwUsernameSize,
						  char* pPassword,
						  DWORD dwPasswordSize,
						  _RD_ProxyType& rType)
{
	//Clear the type
	rType=ptNone;

	//Try to get
	std::string sIP;
	std::string sUsername;
	std::string sPassword;

	//Delegate
	std::wstring sError=CRedirectorControl::GetProxyInformation(sIP,
															    rPort,
															    sUsername,
															    sPassword,
															    rType);


	//Did we get it?
	if (!sError.empty())
		//Exit
		return false;

	//Save the data
	if (pIP &&
		dwIPSize>=(sIP.size()+1))
		//Copy it
		memcpy(pIP,
			   sIP.c_str(),
			   (sIP.size()+1));

	if (pUsername &&
		dwUsernameSize>=(sIP.size()+1))
		//Copy it
		memcpy(pUsername,
			   sUsername.c_str(),
			   (sUsername.size()+1));

	if (pPassword &&
		dwPasswordSize>=(sIP.size()+1))
		//Copy it
		memcpy(pPassword,
			   sPassword.c_str(),
			   (sPassword.size()+1));

	//Done
	return true;
}

bool _stdcall RD_ClearProxy()
{
	return CRedirectorControl::ClearProxyInformation().empty();
}

bool _stdcall RD_GetRedirectorEnable()
{
	//Get the status
	bool bEnabled;
	std::wstring sError;
	sError=CRedirectorControl::IsRedirectorEnabled(bEnabled);

	//Done
	return bEnabled;
}

bool _stdcall RD_SetRedirectorEnabled(bool bEnable)
{
	//Delegate
	return CRedirectorControl::SetRedirectorEnabled(bEnable).empty();
}
