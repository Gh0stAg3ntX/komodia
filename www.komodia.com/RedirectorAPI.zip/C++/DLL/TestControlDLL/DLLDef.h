#ifndef _DLLDef_H_
#define _DLLDef_H_

#include "RedirectorGlobals.h"

//The functions
typedef bool (_stdcall *PR_RD_ThreadInit)();
typedef void (_stdcall *PR_RD_ThreadUninit)();
typedef bool (_stdcall *PR_RD_TakeAction)(_RD_ActionType aType);
typedef int (_stdcall *PR_RD_GetItemList)(_RD_ItemType aItem,
										  unsigned short* pList,
										  DWORD dwListSize);
typedef bool (_stdcall *PR_RD_AddItem)(_RD_ItemType aItem,
									   const unsigned short* pItem);
typedef bool (_stdcall *PR_RD_DeleteItem)(_RD_ItemType aItem,
										  const unsigned short* pItem);
typedef bool (_stdcall *PR_RD_SetProxy)(const char* pIP,
									    unsigned short usPort,
									    const char* pUsername,
									    const char* pPassword,
									    _RD_ProxyType aType);
typedef bool (_stdcall *PR_RD_GetProxy)(char* pIP,
									    DWORD dwIPSize,
									    unsigned short& rPort,
									    char* pUsername,
									    DWORD dwUsernameSize,
									    char* pPassword,
									    DWORD dwPasswordSize,
									    _RD_ProxyType& rType);
typedef bool (_stdcall *PR_RD_ClearProxy)();
typedef bool (_stdcall *PR_RD_GetRedirectorEnable)();
typedef bool (_stdcall *PR_RD_SetRedirectorEnabled)(bool bEnable);
typedef bool (_stdcall *PR_RD_AddFlag)(const unsigned short* pIndex,
									   const unsigned short* pValue);
typedef bool (_stdcall *PR_RD_GetFlag)(const unsigned short* pIndex,
									   unsigned short* pValue,
									   DWORD dwValueSize);

#endif

