// TestControlDLL.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <windows.h>
#include <stdio.h>

#include "DLLDef.h"

void PrintApps(PR_RD_GetItemList pGetItemList)
{
	//Get them
	int iList=(*pGetItemList)(itApplication,NULL,0);

	//Allocate the data
	char* pTmp;
	pTmp=new char[iList];
	iList=(*pGetItemList)(itApplication,(unsigned short*)pTmp,iList);

	//Did we got it?
	if (!iList)
		//Show it
		printf("App list: %S\n",pTmp);

	//Remove it
	delete [] pTmp;
}

int main(int argc, char* argv[])
{
	//Load the DLL
	HMODULE h=LoadLibrary("RedirectorControlDLL.dll");

	//Do we have it?
	if (!h)
		return 1;

	//Start to map the functions
	PR_RD_ThreadInit pInit=(PR_RD_ThreadInit)GetProcAddress(h,"RD_ThreadInit");
	PR_RD_ThreadUninit pUnInit=(PR_RD_ThreadUninit)GetProcAddress(h,"RD_ThreadUninit");
	PR_RD_TakeAction pTakeAction=(PR_RD_TakeAction)GetProcAddress(h,"RD_TakeAction");
	PR_RD_GetItemList pGetItemList=(PR_RD_GetItemList)GetProcAddress(h,"RD_GetItemList");
	PR_RD_AddItem pAddItem=(PR_RD_AddItem)GetProcAddress(h,"RD_AddItem");
	PR_RD_DeleteItem pDeleteItem=(PR_RD_DeleteItem)GetProcAddress(h,"RD_DeleteItem");
	PR_RD_SetProxy pSetProxy=(PR_RD_SetProxy)GetProcAddress(h,"RD_SetProxy");
	PR_RD_GetProxy pGetProxy=(PR_RD_GetProxy)GetProcAddress(h,"RD_GetProxy");
	PR_RD_ClearProxy pClearProxy=(PR_RD_ClearProxy)GetProcAddress(h,"RD_ClearProxy");
	PR_RD_GetRedirectorEnable pGetRedirectorEnable=(PR_RD_GetRedirectorEnable)GetProcAddress(h,"RD_GetRedirectorEnable");
	PR_RD_SetRedirectorEnabled pSetRedirectorEnabled=(PR_RD_SetRedirectorEnabled)GetProcAddress(h,"RD_SetRedirectorEnabled");
	PR_RD_AddFlag pAddFlag=(PR_RD_AddFlag)GetProcAddress(h,"RD_AddFlag");
	PR_RD_GetFlag pGetFlag=(PR_RD_GetFlag)GetProcAddress(h,"RD_GetFlag");

	//Sanity
	if (!pInit ||
		!pUnInit ||
		!pTakeAction ||
		!pGetItemList ||
		!pAddItem ||
		!pDeleteItem ||
		!pSetProxy ||
		!pGetProxy ||
		!pClearProxy ||
		!pGetRedirectorEnable ||
		!pSetRedirectorEnabled ||
		!pAddFlag ||
		!pGetFlag)
	{
		//Close the DLL
		FreeLibrary(h);

		//Done
		return 2;
	}

	//Caller must handle COM
	//Init COM
	if (!(*pInit)())
	{
		//Close the DLL
		FreeLibrary(h);

		//Done
		return 3;
	}
	
	//Clear the data
	(*pTakeAction)(atClear);

	//Do some stuff
	//Add items
	(*pAddItem)(itApplication,(const unsigned short*)L"iexplore.exe");
	(*pAddItem)(itApplication,(const unsigned short*)L"firefox.exe");

	//Print the apps
	PrintApps(pGetItemList);

	//Remove an app
	(*pDeleteItem)(itApplication,(const unsigned short*)L"iexplore.exe");

	//Inv the app list
	(*pAddFlag)(APPINV,
				L"1");

	//Inv it to normal
	(*pAddFlag)(APPINV,
				L"0");

	//Print the apps
	PrintApps(pGetItemList);

	//Clear the data
	(*pTakeAction)(atClear);

	//Print it again
	PrintApps(pGetItemList);

	//Set a proxy
	(*pSetProxy)("127.0.0.1",
				 1080,
				 "",
				 "",
				 ptHTTPHybrid);

	//Get the proxy
	char aIP[MAX_PATH];
	unsigned short usPort;
	_RD_ProxyType aType;
	(*pGetProxy)(aIP,
				 sizeof(aIP),
				 usPort,
				 NULL,
				 0,
				 NULL,
				 0,
				 aType);

	//Print it
	printf("Proxy information, IP: %s, Port: %i, Type: %i\n",aIP,usPort,aType);

	//Clear the proxy
	(*pClearProxy)();

	(*pGetProxy)(aIP,
				 sizeof(aIP),
				 usPort,
				 NULL,
				 0,
				 NULL,
				 0,
				 aType);

	//Print it
	printf("Proxy information, IP: %s, Port: %i, Type: %i\n",aIP,usPort,aType);

	//Disable the redirector
	(*pSetRedirectorEnabled)(false);

	//Show the result
	bool bEnabled;
	bEnabled=(*pGetRedirectorEnable)();
	printf("Redirector enable status: %i\n",bEnabled);

	//Enable the redirector
	(*pSetRedirectorEnabled)(false);

	//Show the result
	bEnabled=(*pGetRedirectorEnable)();
	printf("Redirector enable status: %i\n",bEnabled);

	//Set our DLL
	(*pAddFlag)(DLL_NAME,
				L"theDLL");

	//Save the data
	(*pTakeAction)(atSave);

	//Uninit COM
	(*pUnInit)();

	//Close the DLL
	FreeLibrary(h);

	//Done
	return 0;
}
