﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BSave = New System.Windows.Forms.Button
        Me.BLoad = New System.Windows.Forms.Button
        Me.BClear = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.CustomCommand = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'BSave
        '
        Me.BSave.Location = New System.Drawing.Point(320, 22)
        Me.BSave.Name = "BSave"
        Me.BSave.Size = New System.Drawing.Size(127, 38)
        Me.BSave.TabIndex = 5
        Me.BSave.Text = "Save"
        Me.BSave.UseVisualStyleBackColor = False
        '
        'BLoad
        '
        Me.BLoad.Location = New System.Drawing.Point(177, 22)
        Me.BLoad.Name = "BLoad"
        Me.BLoad.Size = New System.Drawing.Size(127, 38)
        Me.BLoad.TabIndex = 4
        Me.BLoad.Text = "Load"
        Me.BLoad.UseVisualStyleBackColor = True
        '
        'BClear
        '
        Me.BClear.Location = New System.Drawing.Point(32, 22)
        Me.BClear.Name = "BClear"
        Me.BClear.Size = New System.Drawing.Size(127, 38)
        Me.BClear.TabIndex = 3
        Me.BClear.Text = "Clear"
        Me.BClear.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(32, 78)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(127, 38)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Add ports"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(177, 78)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(127, 38)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Set proxy"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(320, 78)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(127, 38)
        Me.Button3.TabIndex = 8
        Me.Button3.Text = "Clear proxy"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'CustomCommand
        '
        Me.CustomCommand.Location = New System.Drawing.Point(32, 136)
        Me.CustomCommand.Name = "CustomCommand"
        Me.CustomCommand.Size = New System.Drawing.Size(127, 38)
        Me.CustomCommand.TabIndex = 9
        Me.CustomCommand.Text = "Save custom data"
        Me.CustomCommand.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(177, 136)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(127, 38)
        Me.Button4.TabIndex = 10
        Me.Button4.Text = "Connect to SSH"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(320, 136)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(127, 38)
        Me.Button5.TabIndex = 11
        Me.Button5.Text = "Kill SSH"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(177, 193)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(127, 38)
        Me.Button6.TabIndex = 12
        Me.Button6.Text = "Set DLL"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(476, 243)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.CustomCommand)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.BSave)
        Me.Controls.Add(Me.BLoad)
        Me.Controls.Add(Me.BClear)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BSave As System.Windows.Forms.Button
    Friend WithEvents BLoad As System.Windows.Forms.Button
    Friend WithEvents BClear As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents CustomCommand As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button

End Class
