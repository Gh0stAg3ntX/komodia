﻿Public Class Form1

    Private Sub SetCustomData(ByVal sUsername As String, ByVal sPassword As String, ByVal sServer As String)
        'Get the controller
        Dim dc As PCProxyLib.DataController
        dc = GetDataController()

        'Get the ports table
        Dim tbl As PCProxyLib.DataTable
        tbl = dc.GetTable(PCProxyLib._Tables.dtFlags)

        'Save the flags
        tbl.AddStringIdx("cst_username", sUsername)
        tbl.AddStringIdx("cst_password", sPassword)
        tbl.AddStringIdx("cst_server", sServer)
        tbl.Commit()
    End Sub

    Private Sub GetCustomData(ByRef sUsername As String, ByRef sPassword As String, ByRef sServer As String)
        'Get the controller
        Dim dc As PCProxyLib.DataController
        dc = GetDataController()

        'Get the ports table
        Dim tbl As PCProxyLib.DataTable
        tbl = dc.GetTable(PCProxyLib._Tables.dtFlags)

        'Save the flags
        sUsername = tbl.GetString("cst_username")
        sPassword = tbl.GetString("cst_password")
        sServer = tbl.GetString("cst_server")
    End Sub

    Private Function CreateSSH(ByVal sUsername As String, ByVal sPassword As String, ByVal sServer As String, ByVal Port As String, ByVal TimeOut As Long, ByVal SSH1 As Boolean) As Boolean
        'Build the string
        Dim sConnect As String
        sConnect = ""

        'Start
        If (SSH1) Then
            sConnect = "-1 "
        End If

        sConnect = sConnect & "-D " & Port & " -pw " & sPassword & " " & sUsername & "@" & sServer

        Dim cSSH As New PCProxyLib.SSHController
        Dim lResult As Long
        lResult = cSSH.CreateSSHSession(sConnect, TimeOut)

        'What is our result?
        If lResult = 0 Then
            CreateSSH = True
        Else
            CreateSSH = False
        End If
    End Function

    Private Function KillSSH(ByVal TimeOut As Long) As Boolean
        Dim cSSH As New PCProxyLib.SSHController
        Dim lResult As Long
        lResult = cSSH.StopSSHSession(TimeOut)

        'What is our result?
        If lResult = 0 Then
            KillSSH = True
        Else
            KillSSH = False
        End If
    End Function

    Private Sub BClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BClear.Click
        'Get the controller
        Dim dc As PCProxyLib.DataController
        dc = GetDataController()

        'Call the actual command
        dc.Clear()
    End Sub

    Private Sub BLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BLoad.Click
        'Get the controller
        Dim dc As PCProxyLib.DataController
        dc = GetDataController()

        'Call the actual command
        dc.Load()
    End Sub

    Private Sub BSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BSave.Click
        'Get the controller
        Dim dc As PCProxyLib.DataController
        dc = GetDataController()

        'Call the actual command
        dc.Save()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Get the controller
        Dim dc As PCProxyLib.DataController
        dc = GetDataController()

        'Get the ports table
        Dim tbl As PCProxyLib.DataTable
        tbl = dc.GetTable(PCProxyLib._Tables.dtPort)
        tbl.AddLong(80)
        tbl.AddLong(443)
        tbl.Commit()
    End Sub

    Private Sub SetProxy(ByVal IP As String, ByVal Port As String, ByVal PType As String)
        'Get the controller
        Dim dc As PCProxyLib.DataController
        dc = GetDataController()

        'Get the flags
        Dim flg As PCProxyLib.DataTable
        flg = dc.GetTable(PCProxyLib._Tables.dtProxy)

        'Set the data
        flg.AddStringIdx("ip", IP)
        flg.AddStringIdx("port", Port)
        flg.AddStringIdx("type", PType)
        flg.Commit()
        dc.Save()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        SetProxy("127.0.0.1", 1080, 6)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        SetProxy("", 0, 0)
    End Sub

    Private Sub CustomCommand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomCommand.Click
        SetCustomData("123", "321", "69.147.236.42")
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        'Get the custom data
        Dim sUsername As String
        Dim sPassword As String
        Dim sServer As String
        GetCustomData(sUsername, sPassword, sServer)

        'Do we have it?
        If sUsername <> "" And sPassword <> "" And sServer <> "" Then
            If CreateSSH(sUsername, sPassword, sServer, "1080", 10000, True) = False Then
                MsgBox("Failed creating session!")
            End If
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If KillSSH(10000) = False Then
            MsgBox("Failed stopping session")
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        'Get the controller
        Dim dc As PCProxyLib.DataController
        dc = GetDataController()

        'Get the ports table
        Dim tbl As PCProxyLib.DataTable
        tbl = dc.GetTable(PCProxyLib._Tables.dtFlags)

        'Save the dll (replace with the path of your dll)
        tbl.AddStringIdx("dlltoload", "c:\mydll.dll")
        tbl.Commit()
    End Sub
End Class
