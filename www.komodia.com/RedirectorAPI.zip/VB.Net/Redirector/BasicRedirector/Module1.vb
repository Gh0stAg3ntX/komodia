﻿Module Module1
    Public Function GetDataController() As PCProxyLib.DataController
        Dim dt As New PCProxyLib.DataController
        'Save it
        GetDataController = dt
    End Function


End Module
