﻿Module Module1
    Public Function GetDataController() As PCProxyLib.DataController
        Dim dt As New PCProxyLib.DataController
        'Save it
        GetDataController = dt
    End Function

    Public Function GetWD() As PCProxyLib.WatchDog
        Dim wd As New PCProxyLib.WatchDog

        'Save it
        GetWD = wd
    End Function
End Module
