﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim wd As PCProxyLib.WatchDog
        wd = GetWD()

        Dim bRunning As Long
        Dim bInstalled As Long
        If wd.GetServiceStatus(bInstalled, bRunning) = 0 Then
            MsgBox("Failed getting WD status!")
        Else
            MsgBox("Installed: " & bInstalled & " Running: " & bRunning)
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim wd As PCProxyLib.WatchDog
        wd = GetWD()

        MsgBox("WD Install status: " & wd.Install)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim wd As PCProxyLib.WatchDog
        wd = GetWD()

        MsgBox("WD uninstall status: " & wd.Uninstall)
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim wd As PCProxyLib.WatchDog
        wd = GetWD()

        Dim dt As PCProxyLib.DataController
        dt = GetDataController()

        Dim co As PCProxyLib.DataTableHolder
        co = dt.GetContainer(PCProxyLib._Container.ctWatchdog)

        'Get the tables
        Dim tbl As PCProxyLib.DataTable
        tbl = co.GetTableCreateSet("filero")
        tbl.Clear()
        tbl.Commit()

        tbl = co.GetTableCreateSet("file")
        tbl.Clear()
        tbl.Commit()

        tbl = co.GetTableCreateSet("process")
        tbl.Clear()
        tbl.Commit()

        tbl = co.GetTableCreateSet("registry")
        tbl.Clear()
        tbl.Commit()

        co.Commit()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim wd As PCProxyLib.WatchDog
        wd = GetWD()

        wd.AddRedirectorProtection()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim wd As PCProxyLib.WatchDog
        wd = GetWD()

        wd.ApplyRules()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim wd As PCProxyLib.WatchDog
        wd = GetWD()

        wd.ClearRules()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Dim dt As PCProxyLib.DataController
        dt = GetDataController()
        dt.Save()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        If RText.Text = "" Then
            MsgBox("Please enter rule!")
        ElseIf Not FRO.Checked And Not FFP.Checked And Not Re.Checked And Not Pr.Checked Then
            MsgBox("Please choose rule type")
        Else
            Dim wd As PCProxyLib.WatchDog
            wd = GetWD()

            Dim dt As PCProxyLib.DataController
            dt = GetDataController()

            Dim co As PCProxyLib.DataTableHolder
            co = dt.GetContainer(PCProxyLib._Container.ctWatchdog)

            'Get the tables
            Dim tbl As PCProxyLib.DataTable

            'Which type
            Dim aTable As String
            If FRO.Checked Then
                aTable = "filero"
            ElseIf FFP.Checked Then
                aTable = "file"
            ElseIf Re.Checked Then
                aTable = "registry"
            Else
                aTable = "process"
            End If

            'Get the table
            tbl = co.GetTableCreateSet(aTable)
            tbl.AddString(RText.Text)
            tbl.Commit()
            co.Commit()
        End If
    End Sub
End Class
