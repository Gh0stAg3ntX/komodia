﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.RT = New System.Windows.Forms.GroupBox
        Me.FRO = New System.Windows.Forms.RadioButton
        Me.FFP = New System.Windows.Forms.RadioButton
        Me.Re = New System.Windows.Forms.RadioButton
        Me.Pr = New System.Windows.Forms.RadioButton
        Me.RText = New System.Windows.Forms.TextBox
        Me.Button8 = New System.Windows.Forms.Button
        Me.Button9 = New System.Windows.Forms.Button
        Me.RT.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(29, 30)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(127, 32)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Is installed"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(171, 30)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(127, 32)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Install"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(316, 30)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(127, 32)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Uninstall"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(29, 79)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(127, 32)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Clear rules"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(171, 79)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(127, 32)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Set redirector rules"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(29, 131)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(127, 32)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "Upload rules"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(171, 131)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(127, 32)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "Remove rules"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'RT
        '
        Me.RT.Controls.Add(Me.Pr)
        Me.RT.Controls.Add(Me.Re)
        Me.RT.Controls.Add(Me.FFP)
        Me.RT.Controls.Add(Me.FRO)
        Me.RT.Location = New System.Drawing.Point(29, 185)
        Me.RT.Name = "RT"
        Me.RT.Size = New System.Drawing.Size(141, 118)
        Me.RT.TabIndex = 7
        Me.RT.TabStop = False
        Me.RT.Text = "Rule type"
        '
        'FRO
        '
        Me.FRO.AutoSize = True
        Me.FRO.Location = New System.Drawing.Point(12, 22)
        Me.FRO.Name = "FRO"
        Me.FRO.Size = New System.Drawing.Size(93, 17)
        Me.FRO.TabIndex = 0
        Me.FRO.TabStop = True
        Me.FRO.Text = "File (read only)"
        Me.FRO.UseVisualStyleBackColor = True
        '
        'FFP
        '
        Me.FFP.AutoSize = True
        Me.FFP.Location = New System.Drawing.Point(12, 45)
        Me.FFP.Name = "FFP"
        Me.FFP.Size = New System.Drawing.Size(113, 17)
        Me.FFP.TabIndex = 1
        Me.FFP.TabStop = True
        Me.FFP.Text = "File (full protection)"
        Me.FFP.UseVisualStyleBackColor = True
        '
        'Re
        '
        Me.Re.AutoSize = True
        Me.Re.Location = New System.Drawing.Point(12, 68)
        Me.Re.Name = "Re"
        Me.Re.Size = New System.Drawing.Size(63, 17)
        Me.Re.TabIndex = 2
        Me.Re.TabStop = True
        Me.Re.Text = "Registry"
        Me.Re.UseVisualStyleBackColor = True
        '
        'Pr
        '
        Me.Pr.AutoSize = True
        Me.Pr.Location = New System.Drawing.Point(12, 91)
        Me.Pr.Name = "Pr"
        Me.Pr.Size = New System.Drawing.Size(63, 17)
        Me.Pr.TabIndex = 3
        Me.Pr.TabStop = True
        Me.Pr.Text = "Process"
        Me.Pr.UseVisualStyleBackColor = True
        '
        'RText
        '
        Me.RText.Location = New System.Drawing.Point(191, 194)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(155, 20)
        Me.RText.TabIndex = 8
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(206, 230)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(127, 32)
        Me.Button8.TabIndex = 9
        Me.Button8.Text = "Add rule"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(316, 79)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(127, 32)
        Me.Button9.TabIndex = 10
        Me.Button9.Text = "Save"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(476, 328)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.RText)
        Me.Controls.Add(Me.RT)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.RT.ResumeLayout(False)
        Me.RT.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents RT As System.Windows.Forms.GroupBox
    Friend WithEvents Re As System.Windows.Forms.RadioButton
    Friend WithEvents FFP As System.Windows.Forms.RadioButton
    Friend WithEvents FRO As System.Windows.Forms.RadioButton
    Friend WithEvents Pr As System.Windows.Forms.RadioButton
    Friend WithEvents RText As System.Windows.Forms.TextBox
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button

End Class
