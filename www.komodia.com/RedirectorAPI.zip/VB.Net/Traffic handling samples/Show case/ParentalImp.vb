Public Class ParentalImp

    Implements PCProxyLib.IParentalControl

    Private TheForm As MainForm

    Public Sub SetForm(ByRef _TheForm As MainForm)
        TheForm = _TheForm
    End Sub

    Public Sub ConnectionClosed(ByVal lConnectionID As Integer, ByVal lError As Integer, ByVal bStringToStore As String) Implements PCProxyLib.IParentalControl.ConnectionClosed
        Dim sMessage As String
        sMessage = "Connection ID: " & lConnectionID & " closed"

        TheForm.AddItem(sMessage)
    End Sub

    Public Function DataBeforeReceive(ByVal lConnectionID As Integer, ByRef pData As PCProxyLib.DataContainer, ByRef lTerminateSession As Integer, ByVal lServerClosed As Integer, ByRef bStringToStore As String) As PCProxyLib._DataActionType Implements PCProxyLib.IParentalControl.DataBeforeReceive
        Dim sMessage As String

        If lServerClosed = 0 Then
            'Build the connection string
            sMessage = "Connection ID: " & lConnectionID & " received " & pData.GetSize() & " bytes, showing first 128 bytes: "

            'Build the data
            Dim iSize As Integer
            If (pData.GetSize() < 128) Then
                iSize = pData.GetSize()
            Else
                iSize = 128
            End If

            Dim iCount As Integer

            'Get the string to a tmp one becaues every call goes to the main process
            Dim bTmpString As String
            bTmpString = pData.RequestString(0, iSize)

            For iCount = 1 To iSize
                If Mid(bTmpString, iCount, 1) <> Chr(7) Then
                    sMessage = sMessage & Mid(bTmpString, iCount, 1)
                End If
            Next
        Else
            'Build the connection string
            sMessage = "Connection ID: " & lConnectionID & " server close"
        End If

        TheForm.AddItem(sMessage)

        DataBeforeReceive = PCProxyLib._DataActionType.naAllowData
    End Function

    Public Function DataBeforeSend(ByVal lConnectionID As Integer, ByRef pData As PCProxyLib.DataContainer, ByRef lTerminateSession As Integer, ByRef lNewBufferToReceive As Integer, ByRef bStringToStore As String) As PCProxyLib._DataActionType Implements PCProxyLib.IParentalControl.DataBeforeSend
        'Build the connection string
        Dim sMessage As String
        sMessage = "Connection ID: " & " sent " & pData.GetSize() & " bytes, showing first 128 bytes: "

        'Build the data
        Dim iSize As Integer
        If (pData.GetSize() < 128) Then
            iSize = pData.GetSize()
        Else
            iSize = 128
        End If

        Dim iCount As Integer

        'Get the string to a tmp one becuase every call goes to the main process
        Dim bTmpString As String
        bTmpString = pData.RequestString(0, iSize)

        For iCount = 1 To iSize
            If Mid(bTmpString, iCount, 1) <> Chr(7) Then
                sMessage = sMessage & Mid(bTmpString, iCount, 1)
            End If
        Next

        TheForm.AddItem(sMessage)

        DataBeforeSend = PCProxyLib._DataActionType.naAllowData
    End Function

    Public Function NewConnection(ByVal lConnectionID As Integer, ByVal lFromEncryption As Integer, ByVal lPID As Integer, ByVal bProcessName As String, ByVal bUsername As String, ByVal bDomain As String, ByVal bIPString As String, ByRef lIP As Integer, ByRef lPort As Integer, ByRef lSSL As Integer, ByRef lProxyModified As Integer, ByRef lProxyType As PCProxyLib._IProxyType, ByRef lProxyIP As Integer, ByRef lProxyPort As Integer, ByRef pUsername As String, ByRef pPassword As String, ByVal bDNSEntry As String, ByRef pFilteringType As PCProxyLib._FilteringType, ByRef bStringToStore As String) As Integer Implements PCProxyLib.IParentalControl.NewConnection
        bStringToStore = "barak"

        'Build the connection string
        Dim sMessage As String
        If lFromEncryption = 1 Then
            sMessage = "New SSL connection ID: "
        Else
            sMessage = "New connection ID: "
        End If

        sMessage = sMessage & lConnectionID & " to: " & bIPString & ":" & lPort

        TheForm.AddItem(sMessage)
        NewConnection = True

        'This same needs the parental

        'Which filtering
        If TheForm.MonitorRadio.Checked = True Then
            pFilteringType = PCProxyLib._FilteringType.ftDataOnly
        Else
            pFilteringType = PCProxyLib._FilteringType.ftParentalOnly
        End If
    End Function

    Public Function NewReply(ByVal lConnectionID As Integer, ByVal bRequestHeader As String, ByVal bFullRequestURL As String, ByVal bReplyHeader As String, ByVal bContentType As String, ByVal lReplyOnly As Integer, ByRef pReplyHeader As PCProxyLib.DataContainer, ByRef pReplyBody As PCProxyLib.DataContainer, ByRef bRedirectTo As String, ByRef bStringToStore As String) As PCProxyLib._ActionType Implements PCProxyLib.IParentalControl.NewReply
        'Skip tells Redirector to do default processing (will build html but not other files)
        'We may change it ahead
        NewReply = PCProxyLib._ActionType.atSkip

        'Build the connection string
        Dim sMessage As String
        sMessage = "Connection ID: " & lConnectionID & " new reply for url: " & bFullRequestURL & " with header: " & bReplyHeader

        TheForm.AddItem(sMessage)

        'Can only search text
        If LCase(bContentType).IndexOf("text") <> -1 Then
            'Get the string
            Dim sData As String
            sData = pReplyBody.RequestString(0, pReplyBody.GetSize())

            'Search it
            Dim sTmp As String
            sTmp = TheForm.KeywordText.Text

            'Are we porn
            Dim bPorn As Boolean

            'Do we skip
            Dim bSkip As Boolean

            'Do we have a category?
            If bRedirectTo <> 0 Then
                Dim sTmp2 As String()
                sTmp2 = Split(bRedirectTo, ",")

                'Check if it has porn
                Dim t As String
                For Each t In sTmp2
                    If t = "3" Or t = "4" Or t = "16" Or t = "39" Or t = "49" Or t = "50" Or t = "56" Or t = "58" Or t = "80" Then
                        bPorn = True
                    ElseIf (t = "65" Or t = "43" Or t = "45" Or t = "91") And TheForm.ForteenBox.Checked Then
                        bPorn = True
                    ElseIf (t = 15) And TheForm.DatingBox.Checked Then
                        bPorn = True
                    End If
                Next
            ElseIf TheForm.ClassRadio.Checked And lReplyOnly = 1 Then
                'Set to skip
                bSkip = True

                'Set return value to wait for result
                NewReply = PCProxyLib._ActionType.atWaitForCategory
            End If

            If (sData.IndexOf(TheForm.KeywordText.Text) <> -1 And TheForm.ClassRadio.Checked = False) Or bPorn Then
                'Need to redirect it
                'We can query the redirector to get data about a connection
                Dim dt As PCProxyLib.DataController
                dt = TheForm.GetController()

                'All the info we can get
                Dim lPID As Long
                Dim bApplication As String
                Dim bUsername As String
                Dim bDomain As String
                Dim lIP As Long
                Dim bStringIP As String
                Dim lPort As Long
                Dim lSSL As Long

                dt.GetConnectionInfo(lConnectionID, lPID, bApplication, bUsername, bDomain, lIP, bStringIP, lPort, lSSL)

                'Which prefix
                Dim sPrefix As String
                If lSSL Then
                    sPrefix = "https://"
                Else
                    sPrefix = "http://"
                End If

                'Check if we need to add HTTP?
                If Left(TheForm.RedirectTo.Text, sPrefix.Length) <> sPrefix Then
                    bRedirectTo = sPrefix & TheForm.RedirectTo.Text
                Else
                    bRedirectTo = TheForm.RedirectTo.Text
                End If

                NewReply = PCProxyLib._ActionType.atRedirect

                sMessage = "Connection ID: " & lConnectionID & " reply redirected: " & bRequestHeader

                TheForm.AddItem(sMessage)
            End If
        End If
    End Function

    Public Function NewRequest(ByVal lConnectionID As Integer, ByRef pHeader As PCProxyLib.DataContainer, ByVal bHeaderNoPost As String, ByVal bHost As String, ByVal bURL As String, ByVal bFullRequest As String, ByVal lPartialPost As Integer, ByRef bRedirectTo As String, ByRef bStringToStore As String) As PCProxyLib._ActionType Implements PCProxyLib.IParentalControl.NewRequest
        'Skip tells Redirector to do default processing (will build html but not other files)
        'We may change it ahead
        NewRequest = PCProxyLib._ActionType.atSkip

        'Build the connection string
        Dim sMessage As String
        sMessage = "Connection ID: " & lConnectionID & " new request : " & bFullRequest

        TheForm.AddItem(sMessage)

        'Check the request
        'Which string to inspect
        Dim sData As String
        If TheForm.HTTPRadio.Checked Then
            sData = bHeaderNoPost
        Else
            sData = bFullRequest
        End If

        Dim bPorn As Boolean

        'Do we have a category?
        If bRedirectTo <> 0 Then
            Dim sTmp2 As String()
            sTmp2 = Split(bRedirectTo, ",")

            'Check if it has porn
            Dim t As String
            For Each t In sTmp2
                If t = "3" Or t = "4" Or t = "16" Or t = "39" Or t = "49" Or t = "50" Or t = "56" Or t = "58" Or t = "80" Then
                    bPorn = True
                ElseIf (t = "65" Or t = "43" Or t = "45" Or t = "91") And TheForm.ForteenBox.Checked Then
                    bPorn = True
                ElseIf (t = 15) And TheForm.DatingBox.Checked Then
                    bPorn = True
                End If
            Next
        End If

        If (LCase(sData).IndexOf(LCase(TheForm.KeywordText.Text)) <> -1 And TheForm.ClassRadio.Checked = False) Or bPorn Then
            'Need to redirect it
            'We can query the redirector to get data about a connection
            Dim dt As PCProxyLib.DataController
            dt = TheForm.GetController()

            'All the info we can get
            Dim lPID As Long
            Dim bApplication As String
            Dim bUsername As String
            Dim bDomain As String
            Dim lIP As Long
            Dim bStringIP As String
            Dim lPort As Long
            Dim lSSL As Long

            dt.GetConnectionInfo(lConnectionID, lPID, bApplication, bUsername, bDomain, lIP, bStringIP, lPort, lSSL)

            'Which prefix
            Dim sPrefix As String
            If lSSL Then
                sPrefix = "https://"
            Else
                sPrefix = "http://"
            End If

            'Check if we need to add HTTP?
            If Left(TheForm.RedirectTo.Text, sPrefix.Length) <> sPrefix Then
                bRedirectTo = sPrefix & TheForm.RedirectTo.Text
            Else
                bRedirectTo = TheForm.RedirectTo.Text
            End If

            NewRequest = PCProxyLib._ActionType.atRedirect

            sMessage = "Connection ID: " & lConnectionID & " request redirected: " & bFullRequest

            TheForm.AddItem(sMessage)
        End If
    End Function
End Class
