Public Class MainForm
    Private ParentalClass As ParentalImp

    Public Delegate Sub addItemDelegate(ByVal item As String)

    Private bStop As Boolean = False

    Private sPollString As String

    Public Function GetController() As PCProxyLib.DataController
        GetController = New PCProxyLib.DataController
    End Function

    Private Sub AddItemToList(ByVal s As String)
        MainList.Items.Add(s)
    End Sub

    Public Sub AddItem(ByRef s As String)
        If MainList.InvokeRequired Then
            Dim del As New addItemDelegate(AddressOf AddItemToList)
            MainList.Invoke(del, New Object() {s})
        Else
            MainList.Items.Add(s)
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If Not bStop Then
            'Get the controller
            Dim dt As PCProxyLib.DataController = GetController()

            'Check if we are WFP
            Dim bWFP As Boolean
            bWFP = dt.DoesSupportWFP

            'Clear all the rules
            dt.Clear()

            'Check the interception rules
            If BrowsersRadio.Checked Then
                'Get the application table
                Dim tb As PCProxyLib.DataTable
                tb = dt.GetTable(PCProxyLib._Tables.dtApplication)

                tb.AddString("iexplore.exe")
                tb.AddString("firefox.exe")
                tb.AddString("chrome.exe")
                tb.AddString("safari.exe")
                tb.AddString("opera.exe")

                'Commit it
                tb.Commit()
            Else
                'All traffic
                Dim tb As PCProxyLib.DataTable
                tb = dt.GetTable(PCProxyLib._Tables.dtFlags)

                'Will inverse the applications flag, this will get all applications
                tb.AddStringIdx("appinv", "1")

                'Commit it
                tb.Commit()
            End If

            'Check if we are WFP
            If bWFP Then
                dt.Save()
            Else
                'Propagate rules immediately
                dt.BroadcastChange(2)
            End If

            'Now connect our filter
            ParentalClass = New ParentalImp
            ParentalClass.SetForm(Me)

            'The two boolean flags are important to understand
            'First one means you will only get new connections and not existing ones
            'Second one means that the SDK will remove your interface in case of an error
            dt.SetParentalInterface(ParentalClass, True, False)

            'Which mode are we?
            If ContentInspectionRadio.Checked Then
                'Alert user
                MsgBox("Will now open your browser and search for porn on google", , "Content inspection")

                'Open the browser
                If Not LaunchNewBrowser("http://www.google.com/search?q=porn") Then
                    MsgBox("Failed to open your default browser, please open it and browse to: http://www.google.com/search?q=porn", , "Content inspection")
                End If
            ElseIf ClassRadio.Checked Then
                'Disable box
                ForteenBox.Enabled = False
                DatingBox.Enabled = False

                'Alert user
                MsgBox("Will now open your browser and visit a porn site, you can visit other porn sites as well", , "Classification server")

                'Open the browser
                If Not LaunchNewBrowser("http://www.playboy.com") Then
                    MsgBox("Failed to open your default browser, please open it and browse to: http://www.google.com/search?q=porn", , "Content inspection")
                End If
            ElseIf SSLRadio.Checked Then
                'Alert user
                MsgBox("Will now open your browser and search for porn on google encrypted with SSL", , "Inspect SSL")

                'Open the browser
                If Not LaunchNewBrowser("https://encrypted.google.com/search?q=porn") Then
                    MsgBox("Failed to open your default browser, please open it and browse to: https://encrypted.google.com/search?q=porn", , "Inspect SSL")
                End If
            ElseIf URLRRadio.Checked Then
                'Alert user
                MsgBox("Will now open your browser and goto CNN.com", , "URL Redirection")

                'Open the browser
                If Not LaunchNewBrowser("http://www.cnn.com") Then
                    MsgBox("Failed to open your default browser, please open it and browse to: http://www.cnn.com", , "URL Redirection")
                End If
            ElseIf MonitorRadio.Checked Then
                'Alert user
                MsgBox("Now all traffic is intercepted", , "Monitor traffic")
            Else
                'Alert the user
                MsgBox("You can now play with the rules, make sure you open a browser or other network application", , "Test it yourself")
            End If
        Else
            'Clear the rules
            'Get the controller
            Dim dt As PCProxyLib.DataController = GetController()

            'Check if we are WFP
            Dim bWFP As Boolean
            bWFP = dt.DoesSupportWFP

            'Clear all the rules
            dt.Clear()

            'Propagate rules immediately
            If bWFP Then
                dt.Save()
            Else
                dt.BroadcastChange(2)
            End If

            'Remove the interface
            dt.SetParentalInterface(Nothing, True, True)
            ParentalClass = Nothing
        End If

        If bStop Then
            'Stop the timer
            PollTimer.Enabled = False

            'Reset the string
            sPollString = ""

            ScenarioBox.Enabled = True
            Button3.Text = "Run test"

            'Enable box
            ForteenBox.Enabled = True
            DatingBox.Enabled = True

            If Not TestRadio.Checked Then
                DisPanel.Enabled = True
            End If
        Else
            'Start the timer
            PollTimer.Enabled = True

            ScenarioBox.Enabled = False
            Button3.Text = "Stop test"

            If Not TestRadio.Checked Then
                DisPanel.Enabled = False
            End If
        End If

        bStop = Not bStop
    End Sub

    Private Sub MonitorRadio_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MonitorRadio.CheckedChanged
        If MonitorRadio.Checked Then
            TrafficAllRadio.Checked = True
        End If

        DisPanel.Enabled = Not MonitorRadio.Checked
    End Sub

    Private Sub ContentInspectionRadio_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ContentInspectionRadio.CheckedChanged
        If ContentInspectionRadio.Checked Then
            KeywordText.Text = "porn"
            BrowsersRadio.Checked = True
            HTTPRadio.Checked = True
            RedirectTo.Text = "www.disney.com"
        End If
    End Sub

    Private Sub SSLRadio_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SSLRadio.CheckedChanged
        If SSLRadio.Checked Then
            KeywordText.Text = "porn"
            BrowsersRadio.Checked = True
            HTTPRadio.Checked = True
            RedirectTo.Text = "www.wellsfargo.com"
        End If
    End Sub

    Private Sub URLRRadio_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles URLRRadio.CheckedChanged
        If URLRRadio.Checked Then
            KeywordText.Text = "cnn"
            BrowsersRadio.Checked = True
            URLRadio.Checked = True
            RedirectTo.Text = "www.foxnews.com"
        End If
    End Sub

    Private Sub MainForm_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        If bStop Then
            Button3_Click(sender, e)
        End If
    End Sub

    Private Sub PollTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PollTimer.Tick
        'With the com object
        Dim dt As PCProxyLib.DataController
        dt = New PCProxyLib.DataController

        'Get the com string
        Dim sTmp As String
        dt.GetInstaceID(sTmp)

        'Do we need to store it
        If sPollString = "" Then
            sPollString = sTmp
        ElseIf sPollString <> sTmp Then
            'Save the new string
            sPollString = sTmp

            'Create new interface (this will be relevant in retail product)
            dt = GetController()

            'Need to reregister ourselves
            'The two boolean flags are important to understand
            'First one means you will only get new connections and not existing ones
            'Second one means that the SDK will remove your interface in case of an error
            dt.SetParentalInterface(ParentalClass, True, True)
        End If
    End Sub
End Class
