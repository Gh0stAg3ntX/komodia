Module General
    Public Function IPConvert(ByVal IPAddress As Object) As Object
        Dim x As Integer
        Dim Pos As Integer
        Dim PrevPos As Integer
        Dim Num As Integer

        If IsNumeric(IPAddress) Then
            IPConvert = "0.0.0.0"
            For x = 1 To 4
                Num = Int(IPAddress / 256 ^ (x - 1))
                IPAddress = IPAddress - (Num * 256 ^ (x - 1))
                If Num > 255 Then
                    IPConvert = "0.0.0.0"
                    Exit Function
                End If

                If x = 1 Then
                    IPConvert = Num
                Else
                    IPConvert = Num & "." & IPConvert
                End If
            Next
        ElseIf UBound(Split(IPAddress, ".")) = 3 Then
            IPConvert = 0
            '        On Error Resume Next
            For x = 1 To 4
                Pos = InStr(PrevPos + 1, IPAddress, ".", 1)
                If x = 4 Then Pos = Len(IPAddress) + 1
                Num = Int(Mid(IPAddress, PrevPos + 1, Pos - PrevPos - 1))
                If Num > 255 Then
                    IPConvert = "0"
                    Exit Function
                End If
                PrevPos = Pos
                IPConvert = ((Num Mod 256) * (256 ^ (x - 1))) + IPConvert
            Next
        Else
            IPConvert = ""
        End If

    End Function

    Public Function FromBase64(ByVal base64 As String) As Byte()
        If base64 Is Nothing Then Throw New ArgumentNullException("base64")
        Return Convert.FromBase64String(base64)
    End Function
End Module
