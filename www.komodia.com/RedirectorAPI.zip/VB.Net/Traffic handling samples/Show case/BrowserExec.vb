'kleinma
'www.vbforums.com
'2005
'this code will launch a URL that is passed to the function
'and open a new browser window each time

Imports System.IO

Module BrowserExec

    Declare Function FindExecutable Lib "shell32.dll" Alias "FindExecutableA" (ByVal lpFile As String, ByVal lpDirectory As String, ByVal lpResult As String) As Integer

    Public Function LaunchNewBrowser(ByVal strUrl As String) As Boolean

        Try
            'CREATE SOME VARIABLES
            Dim BrowserExec As String = New String(" "c, 255)
            Dim FileName As String
            Dim RetVal As Long
            Dim FileNumber As Integer
            Dim SWriter As StreamWriter
            'CREATE A TEMP HTM FILE SO WE CAN FIND OUT WHAT BROWSER IS
            'THE DEFAULT ONE ON THE SYSTEM
            FileName = Application.StartupPath & "\temp.htm"
            SWriter = File.CreateText(FileName)
            SWriter.Write("<html></html>")
            SWriter.Close()
            'CALL THE API TO FIND THE EXE ASSOCIATED WITH HTM FILES
            RetVal = FindExecutable(FileName, vbNullString, BrowserExec)
            BrowserExec = BrowserExec.Trim
            'IF WE GET ONE, LAUNCH THE URL IN THE NEW INSTANCE OF THE BROWSER
            If RetVal <= 32 Or BrowserExec = String.Empty Then
                LaunchNewBrowser = False
            Else
                Process.Start(BrowserExec, strUrl)
            End If
            'DELETE THAT PESKY TEMP FILE
            File.Delete(FileName)
            LaunchNewBrowser = True
        Catch ex As Exception
            'IF ANYTHING GOES WRONG, LET PEOPLE KNOW WHO'S FAULT IT IS
            LaunchNewBrowser = False
        End Try

    End Function
End Module
