<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.ScenarioBox = New System.Windows.Forms.GroupBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.MonitorRadio = New System.Windows.Forms.RadioButton
        Me.Label9 = New System.Windows.Forms.Label
        Me.TestRadio = New System.Windows.Forms.RadioButton
        Me.Label8 = New System.Windows.Forms.Label
        Me.URLRRadio = New System.Windows.Forms.RadioButton
        Me.Label7 = New System.Windows.Forms.Label
        Me.SSLRadio = New System.Windows.Forms.RadioButton
        Me.Label1 = New System.Windows.Forms.Label
        Me.ContentInspectionRadio = New System.Windows.Forms.RadioButton
        Me.RulesGroup = New System.Windows.Forms.GroupBox
        Me.DisPanel = New System.Windows.Forms.Panel
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.URLRadio = New System.Windows.Forms.RadioButton
        Me.HTTPRadio = New System.Windows.Forms.RadioButton
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.BrowsersRadio = New System.Windows.Forms.RadioButton
        Me.RedirectTo = New System.Windows.Forms.TextBox
        Me.TrafficAllRadio = New System.Windows.Forms.RadioButton
        Me.Label11 = New System.Windows.Forms.Label
        Me.KeywordText = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Button3 = New System.Windows.Forms.Button
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.MainList = New System.Windows.Forms.ListBox
        Me.PollTimer = New System.Windows.Forms.Timer(Me.components)
        Me.Label2 = New System.Windows.Forms.Label
        Me.ClassRadio = New System.Windows.Forms.RadioButton
        Me.ForteenBox = New System.Windows.Forms.CheckBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.DatingBox = New System.Windows.Forms.CheckBox
        Me.ScenarioBox.SuspendLayout()
        Me.RulesGroup.SuspendLayout()
        Me.DisPanel.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'ScenarioBox
        '
        Me.ScenarioBox.Controls.Add(Me.DatingBox)
        Me.ScenarioBox.Controls.Add(Me.Label3)
        Me.ScenarioBox.Controls.Add(Me.ForteenBox)
        Me.ScenarioBox.Controls.Add(Me.Label2)
        Me.ScenarioBox.Controls.Add(Me.ClassRadio)
        Me.ScenarioBox.Controls.Add(Me.Label13)
        Me.ScenarioBox.Controls.Add(Me.MonitorRadio)
        Me.ScenarioBox.Controls.Add(Me.Label9)
        Me.ScenarioBox.Controls.Add(Me.TestRadio)
        Me.ScenarioBox.Controls.Add(Me.Label8)
        Me.ScenarioBox.Controls.Add(Me.URLRRadio)
        Me.ScenarioBox.Controls.Add(Me.Label7)
        Me.ScenarioBox.Controls.Add(Me.SSLRadio)
        Me.ScenarioBox.Controls.Add(Me.Label1)
        Me.ScenarioBox.Controls.Add(Me.ContentInspectionRadio)
        Me.ScenarioBox.Location = New System.Drawing.Point(16, 19)
        Me.ScenarioBox.Name = "ScenarioBox"
        Me.ScenarioBox.Size = New System.Drawing.Size(492, 238)
        Me.ScenarioBox.TabIndex = 18
        Me.ScenarioBox.TabStop = False
        Me.ScenarioBox.Text = "Scenarios"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(177, Byte))
        Me.Label13.Location = New System.Drawing.Point(149, 110)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(116, 14)
        Me.Label13.TabIndex = 9
        Me.Label13.Text = "View HTTP traffic only"
        '
        'MonitorRadio
        '
        Me.MonitorRadio.AutoSize = True
        Me.MonitorRadio.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(177, Byte))
        Me.MonitorRadio.Location = New System.Drawing.Point(15, 104)
        Me.MonitorRadio.Name = "MonitorRadio"
        Me.MonitorRadio.Size = New System.Drawing.Size(138, 23)
        Me.MonitorRadio.TabIndex = 6
        Me.MonitorRadio.Text = "Monitor traffic:"
        Me.MonitorRadio.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(177, Byte))
        Me.Label9.Location = New System.Drawing.Point(163, 139)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(131, 14)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Set the rules as you wish"
        '
        'TestRadio
        '
        Me.TestRadio.AutoSize = True
        Me.TestRadio.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(177, Byte))
        Me.TestRadio.Location = New System.Drawing.Point(15, 133)
        Me.TestRadio.Name = "TestRadio"
        Me.TestRadio.Size = New System.Drawing.Size(145, 23)
        Me.TestRadio.TabIndex = 8
        Me.TestRadio.Text = "Test it yourself:"
        Me.TestRadio.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(177, Byte))
        Me.Label8.Location = New System.Drawing.Point(163, 81)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(287, 14)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "Site prevention ame Send all visitors at *CNN* to FoxNews"
        '
        'URLRRadio
        '
        Me.URLRRadio.AutoSize = True
        Me.URLRRadio.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(177, Byte))
        Me.URLRRadio.Location = New System.Drawing.Point(15, 75)
        Me.URLRRadio.Name = "URLRRadio"
        Me.URLRRadio.Size = New System.Drawing.Size(151, 23)
        Me.URLRRadio.TabIndex = 4
        Me.URLRRadio.Text = "URL Redirector:"
        Me.URLRRadio.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(177, Byte))
        Me.Label7.Location = New System.Drawing.Point(136, 54)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(294, 14)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "Find Confidential inside encrypted SSL stream and intercept"
        '
        'SSLRadio
        '
        Me.SSLRadio.AutoSize = True
        Me.SSLRadio.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(177, Byte))
        Me.SSLRadio.Location = New System.Drawing.Point(15, 48)
        Me.SSLRadio.Name = "SSLRadio"
        Me.SSLRadio.Size = New System.Drawing.Size(125, 23)
        Me.SSLRadio.TabIndex = 2
        Me.SSLRadio.Text = "Inspect SSL:"
        Me.SSLRadio.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(177, Byte))
        Me.Label1.Location = New System.Drawing.Point(188, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(281, 14)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Prevent access to any content that has the word PORN  "
        '
        'ContentInspectionRadio
        '
        Me.ContentInspectionRadio.AutoSize = True
        Me.ContentInspectionRadio.Checked = True
        Me.ContentInspectionRadio.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(177, Byte))
        Me.ContentInspectionRadio.Location = New System.Drawing.Point(15, 22)
        Me.ContentInspectionRadio.Name = "ContentInspectionRadio"
        Me.ContentInspectionRadio.Size = New System.Drawing.Size(182, 23)
        Me.ContentInspectionRadio.TabIndex = 0
        Me.ContentInspectionRadio.TabStop = True
        Me.ContentInspectionRadio.Text = "Content Inspection: "
        Me.ContentInspectionRadio.UseVisualStyleBackColor = True
        '
        'RulesGroup
        '
        Me.RulesGroup.Controls.Add(Me.DisPanel)
        Me.RulesGroup.Controls.Add(Me.Button3)
        Me.RulesGroup.Location = New System.Drawing.Point(18, 272)
        Me.RulesGroup.Name = "RulesGroup"
        Me.RulesGroup.Size = New System.Drawing.Size(490, 151)
        Me.RulesGroup.TabIndex = 19
        Me.RulesGroup.TabStop = False
        Me.RulesGroup.Text = "Rules"
        '
        'DisPanel
        '
        Me.DisPanel.Controls.Add(Me.Panel2)
        Me.DisPanel.Controls.Add(Me.Label14)
        Me.DisPanel.Controls.Add(Me.Label12)
        Me.DisPanel.Controls.Add(Me.BrowsersRadio)
        Me.DisPanel.Controls.Add(Me.RedirectTo)
        Me.DisPanel.Controls.Add(Me.TrafficAllRadio)
        Me.DisPanel.Controls.Add(Me.Label11)
        Me.DisPanel.Controls.Add(Me.KeywordText)
        Me.DisPanel.Controls.Add(Me.Label10)
        Me.DisPanel.Location = New System.Drawing.Point(4, 19)
        Me.DisPanel.Name = "DisPanel"
        Me.DisPanel.Size = New System.Drawing.Size(364, 123)
        Me.DisPanel.TabIndex = 21
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.URLRadio)
        Me.Panel2.Controls.Add(Me.HTTPRadio)
        Me.Panel2.Location = New System.Drawing.Point(71, 45)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(186, 27)
        Me.Panel2.TabIndex = 30
        '
        'URLRadio
        '
        Me.URLRadio.AutoSize = True
        Me.URLRadio.Location = New System.Drawing.Point(102, 7)
        Me.URLRadio.Name = "URLRadio"
        Me.URLRadio.Size = New System.Drawing.Size(69, 17)
        Me.URLRadio.TabIndex = 21
        Me.URLRadio.Text = "URL only"
        Me.URLRadio.UseVisualStyleBackColor = True
        '
        'HTTPRadio
        '
        Me.HTTPRadio.AutoSize = True
        Me.HTTPRadio.Checked = True
        Me.HTTPRadio.Location = New System.Drawing.Point(3, 7)
        Me.HTTPRadio.Name = "HTTPRadio"
        Me.HTTPRadio.Size = New System.Drawing.Size(93, 17)
        Me.HTTPRadio.TabIndex = 20
        Me.HTTPRadio.TabStop = True
        Me.HTTPRadio.Text = "HTTP streams"
        Me.HTTPRadio.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(7, 84)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(62, 13)
        Me.Label14.TabIndex = 29
        Me.Label14.Text = "Redirect to:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(7, 56)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(20, 13)
        Me.Label12.TabIndex = 28
        Me.Label12.Text = "At:"
        '
        'BrowsersRadio
        '
        Me.BrowsersRadio.AutoSize = True
        Me.BrowsersRadio.Checked = True
        Me.BrowsersRadio.Location = New System.Drawing.Point(74, 29)
        Me.BrowsersRadio.Name = "BrowsersRadio"
        Me.BrowsersRadio.Size = New System.Drawing.Size(90, 17)
        Me.BrowsersRadio.TabIndex = 27
        Me.BrowsersRadio.TabStop = True
        Me.BrowsersRadio.Text = "Browsers only"
        Me.BrowsersRadio.UseVisualStyleBackColor = True
        '
        'RedirectTo
        '
        Me.RedirectTo.Location = New System.Drawing.Point(75, 77)
        Me.RedirectTo.Name = "RedirectTo"
        Me.RedirectTo.Size = New System.Drawing.Size(166, 20)
        Me.RedirectTo.TabIndex = 23
        Me.RedirectTo.Text = "www.disney.com"
        '
        'TrafficAllRadio
        '
        Me.TrafficAllRadio.AutoSize = True
        Me.TrafficAllRadio.Location = New System.Drawing.Point(173, 29)
        Me.TrafficAllRadio.Name = "TrafficAllRadio"
        Me.TrafficAllRadio.Size = New System.Drawing.Size(184, 17)
        Me.TrafficAllRadio.TabIndex = 26
        Me.TrafficAllRadio.Text = "All traffic (all network applications)"
        Me.TrafficAllRadio.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(7, 33)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(46, 13)
        Me.Label11.TabIndex = 25
        Me.Label11.Text = "Used in:"
        '
        'KeywordText
        '
        Me.KeywordText.Location = New System.Drawing.Point(75, 3)
        Me.KeywordText.Name = "KeywordText"
        Me.KeywordText.Size = New System.Drawing.Size(164, 20)
        Me.KeywordText.TabIndex = 24
        Me.KeywordText.Text = "porn"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(7, 10)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(30, 13)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "Find:"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(395, 116)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(88, 27)
        Me.Button3.TabIndex = 20
        Me.Button3.Text = "Run test"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.MainList)
        Me.GroupBox3.Location = New System.Drawing.Point(18, 429)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(490, 188)
        Me.GroupBox3.TabIndex = 21
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Under The Hood"
        '
        'MainList
        '
        Me.MainList.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.MainList.FormattingEnabled = True
        Me.MainList.HorizontalScrollbar = True
        Me.MainList.Location = New System.Drawing.Point(6, 19)
        Me.MainList.Name = "MainList"
        Me.MainList.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.MainList.Size = New System.Drawing.Size(478, 156)
        Me.MainList.TabIndex = 4
        '
        'PollTimer
        '
        Me.PollTimer.Interval = 1000
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(177, Byte))
        Me.Label2.Location = New System.Drawing.Point(200, 197)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(266, 14)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Block porn sites using Komodia's classification server"
        '
        'ClassRadio
        '
        Me.ClassRadio.AutoSize = True
        Me.ClassRadio.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(177, Byte))
        Me.ClassRadio.Location = New System.Drawing.Point(15, 191)
        Me.ClassRadio.Name = "ClassRadio"
        Me.ClassRadio.Size = New System.Drawing.Size(188, 23)
        Me.ClassRadio.TabIndex = 11
        Me.ClassRadio.Text = "Classification server:"
        Me.ClassRadio.UseVisualStyleBackColor = True
        '
        'ForteenBox
        '
        Me.ForteenBox.AutoSize = True
        Me.ForteenBox.Location = New System.Drawing.Point(114, 217)
        Me.ForteenBox.Name = "ForteenBox"
        Me.ForteenBox.Size = New System.Drawing.Size(208, 17)
        Me.ForteenBox.TabIndex = 12
        Me.ForteenBox.Text = "Semi nude (not porn but not child safe)"
        Me.ForteenBox.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(49, 217)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Also block:"
        '
        'DatingBox
        '
        Me.DatingBox.AutoSize = True
        Me.DatingBox.Location = New System.Drawing.Point(328, 217)
        Me.DatingBox.Name = "DatingBox"
        Me.DatingBox.Size = New System.Drawing.Size(81, 17)
        Me.DatingBox.TabIndex = 14
        Me.DatingBox.Text = "Dating sites"
        Me.DatingBox.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(523, 629)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.RulesGroup)
        Me.Controls.Add(Me.ScenarioBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MainForm"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Komodia's Redirector Showcase for VB.Net"
        Me.ScenarioBox.ResumeLayout(False)
        Me.ScenarioBox.PerformLayout()
        Me.RulesGroup.ResumeLayout(False)
        Me.DisPanel.ResumeLayout(False)
        Me.DisPanel.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ScenarioBox As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ContentInspectionRadio As System.Windows.Forms.RadioButton
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents SSLRadio As System.Windows.Forms.RadioButton
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents URLRRadio As System.Windows.Forms.RadioButton
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TestRadio As System.Windows.Forms.RadioButton
    Friend WithEvents RulesGroup As System.Windows.Forms.GroupBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents MonitorRadio As System.Windows.Forms.RadioButton
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents MainList As System.Windows.Forms.ListBox
    Friend WithEvents DisPanel As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents URLRadio As System.Windows.Forms.RadioButton
    Friend WithEvents HTTPRadio As System.Windows.Forms.RadioButton
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents BrowsersRadio As System.Windows.Forms.RadioButton
    Friend WithEvents RedirectTo As System.Windows.Forms.TextBox
    Friend WithEvents TrafficAllRadio As System.Windows.Forms.RadioButton
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents KeywordText As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents PollTimer As System.Windows.Forms.Timer
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ClassRadio As System.Windows.Forms.RadioButton
    Friend WithEvents ForteenBox As System.Windows.Forms.CheckBox
    Friend WithEvents DatingBox As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label

End Class
